const encoder = new TextEncoder();

function toBase64Url(bytes) {
  let binary = '';
  for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary).replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
}

function fromBase64Url(value) {
  const base64 = value.replace(/-/g, '+').replace(/_/g, '/') + '='.repeat((4 - value.length % 4) % 4);
  const binary = atob(base64);
  return Uint8Array.from(binary, char => char.charCodeAt(0));
}

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store, max-age=0' },
  });
}

export function jsonResponse(data, status = 200) { return json(data, status); }

export function serviceUnavailable(message = 'الخدمة غير مهيأة في Cloudflare بعد.') {
  return json({ error: message, code: 'SERVICE_NOT_CONFIGURED' }, 503);
}

export async function signAdminToken(secret) {
  const payload = toBase64Url(encoder.encode(JSON.stringify({ scope: 'admin', exp: Date.now() + 8 * 60 * 60 * 1000 })));
  const key = await crypto.subtle.importKey('raw', encoder.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const signature = new Uint8Array(await crypto.subtle.sign('HMAC', key, encoder.encode(payload)));
  return `${payload}.${toBase64Url(signature)}`;
}

export async function isValidAdminToken(request, env) {
  const secret = env?.ADMIN_TOKEN_SECRET;
  if (typeof secret !== 'string' || secret.length < 32) return false;
  const token = (request.headers.get('authorization') || '').replace(/^Bearer\s+/i, '').trim();
  const parts = token.split('.');
  if (parts.length !== 2) return false;
  try {
    const key = await crypto.subtle.importKey('raw', encoder.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['verify']);
    const valid = await crypto.subtle.verify('HMAC', key, fromBase64Url(parts[1]), encoder.encode(parts[0]));
    if (!valid) return false;
    const payload = JSON.parse(new TextDecoder().decode(fromBase64Url(parts[0])));
    return payload?.scope === 'admin' && Number(payload.exp) > Date.now();
  } catch { return false; }
}

export async function requireAdmin(request, env) {
  if (typeof env?.ADMIN_PASSWORD !== 'string' || !env.ADMIN_PASSWORD || typeof env?.ADMIN_TOKEN_SECRET !== 'string' || env.ADMIN_TOKEN_SECRET.length < 32) {
    return serviceUnavailable('اضبط ADMIN_PASSWORD وADMIN_TOKEN_SECRET في إعدادات Cloudflare أولاً.');
  }
  if (!(await isValidAdminToken(request, env))) return json({ error: 'انتهت جلسة الإدارة أو أنها غير صالحة. سجّل الدخول مجدداً.' }, 401);
  return null;
}

let initializedDatabase = null;
let schemaPromise = null;

export async function getDatabase(env) {
  if (!env?.NAFIAHAN_DB) throw new Error('D1_NOT_CONFIGURED');
  const db = env.NAFIAHAN_DB;
  if (initializedDatabase !== db || !schemaPromise) {
    initializedDatabase = db;
    schemaPromise = (async () => {
      await db.prepare(`CREATE TABLE IF NOT EXISTS plus_codes (
        code TEXT PRIMARY KEY,
        created_at INTEGER NOT NULL,
        expires_at INTEGER NOT NULL,
        duration_minutes INTEGER NOT NULL,
        note TEXT NOT NULL DEFAULT '',
        used_by TEXT,
        used_at INTEGER
      )`).run();
      await db.prepare(`CREATE TABLE IF NOT EXISTS app_announcements (
        id INTEGER PRIMARY KEY CHECK (id = 1),
        message TEXT NOT NULL DEFAULT '',
        active INTEGER NOT NULL DEFAULT 0,
        updated_at INTEGER NOT NULL
      )`).run();
    })();
  }
  try { await schemaPromise; }
  catch (error) { schemaPromise = null; throw error; }
  return db;
}

export function dbUnavailable(error) {
  if (error?.message === 'D1_NOT_CONFIGURED') return serviceUnavailable('اربط قاعدة D1 باسم NAFIAHAN_DB في إعدادات Cloudflare ثم أعد النشر.');
  return json({ error: 'حدث خطأ أثناء الاتصال بقاعدة البيانات المشتركة.' }, 500);
}

export function plusCodeRecord(row) {
  return {
    id: row.code,
    code: row.code,
    created_date: new Date(row.created_at).toISOString(),
    expires_at: new Date(row.expires_at).toISOString(),
    duration_minutes: row.duration_minutes,
    note: row.note || '',
    ...(row.used_by ? { used_by: row.used_by, used_at: new Date(row.used_at).toISOString() } : {}),
  };
}
