import { dbUnavailable, getDatabase, isValidAdminToken, jsonResponse, plusCodeRecord, requireAdmin } from '../_lib/security.js';

const CHARSET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
function makeCode() {
  const bytes = crypto.getRandomValues(new Uint8Array(6));
  return Array.from(bytes, byte => CHARSET[byte % CHARSET.length]).join('');
}

export async function onRequestGet({ request, env }) {
  const denied = await requireAdmin(request, env);
  if (denied) return denied;
  try {
    const db = await getDatabase(env);
    const now = Date.now();
    const { results = [] } = await db.prepare('SELECT * FROM plus_codes WHERE used_by IS NULL AND expires_at > ? ORDER BY created_at DESC LIMIT 100').bind(now).all();
    const { total = results.length } = await db.prepare('SELECT COUNT(*) AS total FROM plus_codes WHERE used_by IS NULL AND expires_at > ?').bind(now).first() || {};
    return jsonResponse({ items: results.map(plusCodeRecord), total, has_more: false, next_cursor: null });
  } catch (error) { return dbUnavailable(error); }
}

export async function onRequestPost({ request, env }) {
  const denied = await requireAdmin(request, env);
  if (denied) return denied;
  let body;
  try { body = await request.json(); } catch { return jsonResponse({ error: 'طلب غير صالح.' }, 400); }
  const duration = Number(body?.duration_minutes);
  const allowed = [20, 60, 180, 1440];
  if (!allowed.includes(duration)) return jsonResponse({ error: 'مدة صلاحية الكود غير صالحة.' }, 400);
  const note = typeof body?.note === 'string' ? body.note.trim().slice(0, 200) : '';
  const now = Date.now();
  try {
    const db = await getDatabase(env);
    for (let attempt = 0; attempt < 8; attempt++) {
      const code = makeCode();
      try {
        await db.prepare('INSERT INTO plus_codes (code, created_at, expires_at, duration_minutes, note, used_by, used_at) VALUES (?, ?, ?, ?, ?, NULL, NULL)')
          .bind(code, now, now + duration * 60000, duration, note).run();
        const row = await db.prepare('SELECT * FROM plus_codes WHERE code = ?').bind(code).first();
        return jsonResponse({ record: plusCodeRecord(row) }, 201);
      } catch (error) {
        const message = String(error?.message || '');
        if (!/unique|constraint/i.test(message)) throw error;
      }
    }
    return jsonResponse({ error: 'تعذّر توليد كود جديد، أعد المحاولة.' }, 500);
  } catch (error) { return dbUnavailable(error); }
}
