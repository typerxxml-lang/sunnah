import { dbUnavailable, getDatabase, jsonResponse, requireAdmin } from '../../_lib/security.js';

export async function onRequestDelete({ request, env, params }) {
  const denied = await requireAdmin(request, env);
  if (denied) return denied;
  const code = String(params?.code || '').toUpperCase();
  try {
    const db = await getDatabase(env);
    const result = await db.prepare('DELETE FROM plus_codes WHERE code = ? AND used_by IS NULL').bind(code).run();
    return jsonResponse({ success: true, deleted: Number(result?.meta?.changes || 0) > 0 });
  } catch (error) { return dbUnavailable(error); }
}
