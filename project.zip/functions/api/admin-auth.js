import { jsonResponse, serviceUnavailable, signAdminToken } from '../_lib/security.js';

export async function onRequestPost({ request, env }) {
  if (typeof env?.ADMIN_PASSWORD !== 'string' || !env.ADMIN_PASSWORD || typeof env?.ADMIN_TOKEN_SECRET !== 'string' || env.ADMIN_TOKEN_SECRET.length < 32) {
    return serviceUnavailable('يحتاج المطور إلى ضبط ADMIN_PASSWORD وADMIN_TOKEN_SECRET في Cloudflare.');
  }
  let body;
  try { body = await request.json(); } catch { return jsonResponse({ error: 'طلب غير صالح.' }, 400); }
  const candidate = typeof body?.password === 'string' ? body.password : '';
  if (!candidate || candidate !== env.ADMIN_PASSWORD) return jsonResponse({ error: 'كلمة المرور غير صحيحة.' }, 401);
  const token = await signAdminToken(env.ADMIN_TOKEN_SECRET);
  return jsonResponse({ token, expires_in: 8 * 60 * 60 });
}
