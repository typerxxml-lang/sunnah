import { dbUnavailable, getDatabase, jsonResponse, requireAdmin } from '../_lib/security.js';

export async function onRequestGet({ env }) {
  try {
    const db = await getDatabase(env);
    const row = await db.prepare('SELECT message, active, updated_at FROM app_announcements WHERE id = 1').first();
    return jsonResponse({ message: row?.message || '', active: Number(row?.active || 0) === 1, updated_at: row?.updated_at || null });
  } catch (error) { return dbUnavailable(error); }
}

export async function onRequestPost({ request, env }) {
  const denied = await requireAdmin(request, env);
  if (denied) return denied;
  let body;
  try { body = await request.json(); } catch { return jsonResponse({ error: 'طلب غير صالح.' }, 400); }
  const message = typeof body?.message === 'string' ? body.message.trim().slice(0, 1500) : '';
  const active = Boolean(body?.active) && !!message;
  try {
    const db = await getDatabase(env);
    const now = Date.now();
    await db.prepare(`INSERT INTO app_announcements (id, message, active, updated_at) VALUES (1, ?, ?, ?)
      ON CONFLICT(id) DO UPDATE SET message = excluded.message, active = excluded.active, updated_at = excluded.updated_at`)
      .bind(message, active ? 1 : 0, now).run();
    return jsonResponse({ message, active, updated_at: now });
  } catch (error) { return dbUnavailable(error); }
}
