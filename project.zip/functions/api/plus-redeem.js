import { dbUnavailable, getDatabase, jsonResponse, plusCodeRecord } from '../_lib/security.js';

export async function onRequestGet({ request, env }) {
  const url = new URL(request.url);
  const code = (url.searchParams.get('code') || '').trim().toUpperCase();
  if (!/^[A-HJ-KM-NP-Z2-9]{6}$/.test(code)) return jsonResponse({ valid: false, reason: 'اكتب كوداً صحيحاً من 6 خانات.' });
  try {
    const db = await getDatabase(env);
    const row = await db.prepare('SELECT * FROM plus_codes WHERE code = ?').bind(code).first();
    if (!row) return jsonResponse({ valid: false, reason: 'الكود غير موجود.' });
    if (row.used_by) return jsonResponse({ valid: false, reason: 'الكود مستخدم بالفعل.' });
    if (Number(row.expires_at) <= Date.now()) return jsonResponse({ valid: false, reason: 'الكود منتهي الصلاحية.' });
    return jsonResponse({ valid: true, record: plusCodeRecord(row) });
  } catch (error) { return dbUnavailable(error); }
}

export async function onRequestPost({ request, env }) {
  let body;
  try { body = await request.json(); } catch { return jsonResponse({ error: 'طلب غير صالح.' }, 400); }
  const code = typeof body?.code === 'string' ? body.code.trim().toUpperCase() : '';
  const userId = typeof body?.user_id === 'string' ? body.user_id.slice(0, 128) : '';
  if (!/^[A-HJ-KM-NP-Z2-9]{6}$/.test(code) || !userId) return jsonResponse({ error: 'أدخل الكود الصحيح أولاً.' }, 400);
  try {
    const db = await getDatabase(env);
    const now = Date.now();
    const result = await db.prepare('UPDATE plus_codes SET used_by = ?, used_at = ? WHERE code = ? AND used_by IS NULL AND expires_at > ?')
      .bind(userId, now, code, now).run();
    if (Number(result?.meta?.changes || 0) !== 1) {
      const row = await db.prepare('SELECT * FROM plus_codes WHERE code = ?').bind(code).first();
      if (!row) return jsonResponse({ error: 'الكود غير موجود.' }, 404);
      if (row.used_by) return jsonResponse({ error: 'الكود مستخدم بالفعل.' }, 409);
      return jsonResponse({ error: 'الكود منتهي الصلاحية.' }, 410);
    }
    const row = await db.prepare('SELECT * FROM plus_codes WHERE code = ?').bind(code).first();
    return jsonResponse({ success: true, record: plusCodeRecord(row) });
  } catch (error) { return dbUnavailable(error); }
}
