import { useState } from 'react';
import { adhkar, adhkarCategories } from '@/data/adhkar';
import TasbeehCounter from './TasbeehCounter';
import { useGlassEffect } from '@/hooks/useGlassEffect';
import { Sun, Moon, Sparkles } from 'lucide-react';

const CATEGORY_ICONS = {
  morning: Sun,
  evening: Moon,
  after_prayer: Sparkles,
};

export default function AdhkarView() {
  const [category, setCategory] = useState('morning');
  const [counts, setCounts] = useState({});
  const glassRef = useGlassEffect(30, 24, 42);

  const filtered = adhkar.filter(a => a.category === category);
  const activeCat = adhkarCategories.find(c => c.id === category);

  const increment = (id) => {
    setCounts(prev => ({ ...prev, [id]: (prev[id] || 0) + 1 }));
  };

  const reset = (id) => {
    setCounts(prev => ({ ...prev, [id]: 0 }));
  };

  return (
    <div className="space-y-5">
      <div>
        <h2 className="font-heading text-xl font-bold text-foreground mb-1">الأذكار اليومية</h2>
        <p className="text-sm text-muted-foreground">أذكار الصباح والمساء وبعد الصلاة</p>
      </div>

      {/* Category selector */}
      <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
        {adhkarCategories.map(c => {
          const Icon = CATEGORY_ICONS[c.id];
          return (
            <button
              key={c.id}
              onClick={() => setCategory(c.id)}
              className={`shrink-0 flex items-center gap-2 px-4 py-2.5 rounded-full text-sm font-medium transition-all whitespace-nowrap ${
                category === c.id
                  ? 'bg-emerald-600 dark:bg-emerald-500 text-white'
                  : 'glass-blur text-muted-foreground hover:text-foreground'
              }`}
            >
              <Icon size={16} />
              {c.name}
            </button>
          );
        })}
      </div>

      {/* Adhkar list */}
      <div className="space-y-3">
        {filtered.map(dhikr => {
          const current = counts[dhikr.id] || 0;
          const done = current >= dhikr.count;
          return (
            <div
              key={dhikr.id}
              ref={glassRef}
              className={`glass-blur p-5 transition-all ${done ? 'opacity-70' : ''}`}
            >
              <p className="font-quran text-lg text-foreground leading-loose mb-3" dir="rtl">
                {dhikr.text}
              </p>

              {dhikr.virtue && (
                <p className="text-xs text-emerald-600 dark:text-emerald-400 mb-3 leading-relaxed">
                  ✦ {dhikr.virtue}
                </p>
              )}

              <div className="flex items-center justify-between gap-3">
                <button
                  onClick={() => increment(dhikr.id)}
                  disabled={done}
                  className={`flex items-center gap-2 px-5 py-2.5 rounded-full font-bold text-sm transition-all active:scale-95 disabled:opacity-50 ${
                    done
                      ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400'
                      : 'bg-emerald-600 dark:bg-emerald-500 text-white'
                  }`}
                >
                  {done ? 'تم بحمد الله' : `${current} / ${dhikr.count}`}
                </button>
                {current > 0 && !done && (
                  <button
                    onClick={() => reset(dhikr.id)}
                    className="text-xs text-muted-foreground hover:text-foreground transition-colors"
                  >
                    إعادة
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Tasbeeh counter */}
      <div className="pt-3">
        <TasbeehCounter />
      </div>
    </div>
  );
}