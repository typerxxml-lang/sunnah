import { X } from 'lucide-react';

export default function ManagementModal({ title, Icon, onClose, children }) {
  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-foreground/30 backdrop-blur-sm p-4 flex" role="dialog" aria-modal="true" aria-label={title} dir="rtl">
      <div className="glass bg-card/90 max-w-lg w-full p-5 sm:p-6 m-auto">
        <div className="flex items-center justify-between gap-3 mb-5">
          <div className="flex items-center gap-2"><Icon size={23} className="text-primary" /><h2 className="font-heading text-xl font-bold text-foreground">{title}</h2></div>
          <button type="button" onClick={onClose} aria-label="إغلاق" className="rounded-full p-2 text-muted-foreground hover:bg-muted"><X size={20} /></button>
        </div>
        {children}
      </div>
    </div>
  );
}