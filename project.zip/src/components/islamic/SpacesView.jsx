import { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { Plus, Trash2, ChevronLeft, FolderPlus, Folder, BookOpen, ScrollText, FileText, Search, X } from 'lucide-react';
import { sunan } from '@/data/sunan';
import { hadiths } from '@/data/hadiths';
import { quranVerses } from '@/data/quran';

export default function SpacesView({ onClose }) {
  const [spaces, setSpaces] = useState([]);
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeSpace, setActiveSpace] = useState(null);
  const [newSpaceName, setNewSpaceName] = useState('');
  const [picker, setPicker] = useState(null);
  const [pickerSearch, setPickerSearch] = useState('');
  const [textForm, setTextForm] = useState({ title: '', text: '' });

  const loadSpaces = useCallback(async () => {
    try {
      const { items: s } = await base44.entities.UserSpace.filter({}, { sort: 'order', limit: 100 });
      setSpaces(s);
    } catch {} finally { setLoading(false); }
  }, []);

  const loadItems = useCallback(async (spaceId) => {
    try {
      const { items: i } = await base44.entities.SpaceItem.filter({ space_id: spaceId }, { sort: 'order', limit: 100 });
      setItems(i);
    } catch {}
  }, []);

  useEffect(() => { loadSpaces(); }, [loadSpaces]);
  useEffect(() => { if (activeSpace) loadItems(activeSpace.id); }, [activeSpace, loadItems]);

  const addSpace = async () => {
    if (!newSpaceName.trim()) return;
    try {
      await base44.entities.UserSpace.create({ name: newSpaceName.trim(), order: spaces.length });
      setNewSpaceName('');
      await loadSpaces();
    } catch {}
  };

  const removeSpace = async (id) => {
    try { await base44.entities.UserSpace.delete(id); if (activeSpace?.id === id) setActiveSpace(null); await loadSpaces(); } catch {}
  };

  const addItem = async (contentType, title, text, reference = '') => {
    if (!activeSpace) return;
    try {
      await base44.entities.SpaceItem.create({ space_id: activeSpace.id, content_type: contentType, title, text, reference, order: items.length });
      setPicker(null); setPickerSearch(''); setTextForm({ title: '', text: '' });
      await loadItems(activeSpace.id);
    } catch {}
  };

  const removeItem = async (id) => {
    try { await base44.entities.SpaceItem.delete(id); await loadItems(activeSpace.id); } catch {}
  };

  const pickerData = picker === 'sunnah' ? sunan : picker === 'hadith' ? hadiths : picker === 'quran' ? quranVerses : [];
  const filteredPicker = pickerData.filter(item => !pickerSearch || (item.title || '').includes(pickerSearch));

  if (loading) return <div className="text-center py-8 text-sm text-muted-foreground">جارٍ التحميل...</div>;

  return (
    <div className="space-y-4">
      {!activeSpace ? (
        <>
          <div className="flex gap-2">
            <input value={newSpaceName} onChange={e => setNewSpaceName(e.target.value)} onKeyDown={e => e.key === 'Enter' && addSpace()}
              placeholder="اسم مساحة جديدة..." maxLength={50}
              className="flex-1 rounded-xl border border-input bg-background/50 px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
            <button onClick={addSpace} disabled={!newSpaceName.trim()} className="rounded-xl bg-primary text-primary-foreground p-2.5 disabled:opacity-50">
              <FolderPlus size={18} />
            </button>
          </div>
          <div className="space-y-2">
            {spaces.map(s => (
              <button key={s.id} onClick={() => setActiveSpace(s)} className="w-full flex items-center gap-3 rounded-2xl bg-foreground/5 p-3 hover:bg-foreground/10 transition-colors text-right">
                <Folder size={18} className="text-primary shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="font-bold text-sm text-foreground truncate">{s.name}</p>
                </div>
                <span onClick={e => { e.stopPropagation(); removeSpace(s.id); }} className="p-1.5 rounded-full hover:bg-destructive/10">
                  <Trash2 size={15} className="text-destructive" />
                </span>
              </button>
            ))}
            {!spaces.length && <p className="text-sm text-muted-foreground text-center py-6">لا توجد مساحات بعد</p>}
          </div>
        </>
      ) : (
        <>
          <div className="flex items-center gap-2">
            <button onClick={() => setActiveSpace(null)} className="p-1.5 rounded-full hover:bg-foreground/10"><ChevronLeft size={20} className="text-muted-foreground" /></button>
            <h3 className="font-heading text-lg font-bold text-foreground flex-1">{activeSpace.name}</h3>
            <button onClick={onClose} className="p-1.5 rounded-full hover:bg-foreground/10"><X size={20} className="text-muted-foreground" /></button>
          </div>

          <div className="grid grid-cols-4 gap-2">
            <button onClick={() => setPicker('sunnah')} className="flex flex-col items-center gap-1 py-2.5 rounded-xl bg-primary/10 text-primary text-xs"><ScrollText size={18} />سنة</button>
            <button onClick={() => setPicker('hadith')} className="flex flex-col items-center gap-1 py-2.5 rounded-xl bg-primary/10 text-primary text-xs"><BookOpen size={18} />حديث</button>
            <button onClick={() => setPicker('quran')} className="flex flex-col items-center gap-1 py-2.5 rounded-xl bg-primary/10 text-primary text-xs"><BookOpen size={18} />آية</button>
            <button onClick={() => setPicker('text')} className="flex flex-col items-center gap-1 py-2.5 rounded-xl bg-primary/10 text-primary text-xs"><FileText size={18} />نص</button>
          </div>

          {picker && (
            <div className="rounded-2xl bg-muted/40 border border-border p-3 space-y-2">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-bold">{picker === 'sunnah' ? 'اختر سنة' : picker === 'hadith' ? 'اختر حديث' : picker === 'quran' ? 'اختر آية' : 'نص مخصص'}</h4>
                <button onClick={() => setPicker(null)} className="p-1 rounded-full hover:bg-foreground/10"><X size={16} /></button>
              </div>
              {picker === 'text' ? (
                <div className="space-y-2">
                  <input value={textForm.title} onChange={e => setTextForm(f => ({ ...f, title: e.target.value }))} placeholder="العنوان" maxLength={200}
                    className="w-full rounded-xl border border-input bg-background/50 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
                  <textarea value={textForm.text} onChange={e => setTextForm(f => ({ ...f, text: e.target.value }))} placeholder="النص" rows={3} maxLength={2000}
                    className="w-full rounded-xl border border-input bg-background/50 px-3 py-2 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-ring" />
                  <button onClick={() => addItem('text', textForm.title, textForm.text)} disabled={!textForm.title.trim() || !textForm.text.trim()}
                    className="w-full rounded-xl bg-primary text-primary-foreground py-2 text-sm font-bold disabled:opacity-50">إضافة</button>
                </div>
              ) : (
                <>
                  <div className="relative">
                    <Search size={15} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
                    <input value={pickerSearch} onChange={e => setPickerSearch(e.target.value)} placeholder="بحث..." maxLength={50}
                      className="w-full rounded-lg border border-input bg-background/50 pr-8 pl-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
                  </div>
                  <div className="max-h-48 overflow-y-auto space-y-1 scrollbar-hide">
                    {filteredPicker.slice(0, 30).map(item => (
                      <button key={item.id} onClick={() => addItem(picker, item.title, item.text, item.reference || '')}
                        className="w-full text-right rounded-lg bg-foreground/5 p-2 hover:bg-foreground/10 transition-colors">
                        <p className="text-xs font-bold text-foreground truncate">{item.title}</p>
                        <p className="text-[10px] text-muted-foreground line-clamp-1">{item.text}</p>
                      </button>
                    ))}
                  </div>
                </>
              )}
            </div>
          )}

          <div className="space-y-2 max-h-60 overflow-y-auto">
            {items.map(item => (
              <div key={item.id} className="rounded-2xl bg-foreground/5 p-3">
                <div className="flex items-start gap-2">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-bold text-foreground">{item.title}</p>
                    <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{item.text}</p>
                    {item.reference && <p className="text-[10px] text-muted-foreground mt-1">{item.reference}</p>}
                  </div>
                  <button onClick={() => removeItem(item.id)} className="p-1 rounded-full hover:bg-destructive/10 shrink-0"><Trash2 size={14} className="text-destructive" /></button>
                </div>
              </div>
            ))}
            {!items.length && <p className="text-sm text-muted-foreground text-center py-4">لا توجد عناصر بعد</p>}
          </div>
        </>
      )}
    </div>
  );
}