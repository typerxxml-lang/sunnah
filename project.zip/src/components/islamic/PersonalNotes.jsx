import { useState } from 'react';
import { useGlassEffect } from '@/hooks/useGlassEffect';
import { loadJSON, saveJSON } from '@/lib/storage';
import { Plus, Trash2, NotebookPen, FolderPlus, Folder, ChevronLeft } from 'lucide-react';

const NOTES_KEY = 'iq-personal-notes';

function loadNotes() {
  return loadJSON(NOTES_KEY, { spaces: [{ id: 'default', name: 'ملاحظاتي', items: [] }] });
}

export default function PersonalNotes({ onClose }) {
  const glassRef = useGlassEffect(34, 26, 48);
  const [data, setData] = useState(() => loadNotes());
  const [activeSpace, setActiveSpace] = useState(null);
  const [newSpace, setNewSpace] = useState('');
  const [newNote, setNewNote] = useState('');
  const [editId, setEditId] = useState(null);
  const [editText, setEditText] = useState('');

  const persist = (next) => {
    setData(next);
    saveJSON(NOTES_KEY, next);
  };

  const addSpace = () => {
    if (!newSpace.trim()) return;
    persist({ spaces: [...data.spaces, { id: Date.now().toString(), name: newSpace.trim(), items: [] }] });
    setNewSpace('');
  };

  const removeSpace = (id) => {
    persist({ spaces: data.spaces.filter(s => s.id !== id) });
    if (activeSpace === id) setActiveSpace(null);
  };

  const addNote = () => {
    if (!newNote.trim() || !activeSpace) return;
    const note = { id: Date.now().toString(), text: newNote.trim(), created: new Date().toISOString() };
    persist({
      spaces: data.spaces.map(s => s.id === activeSpace ? { ...s, items: [note, ...s.items] } : s),
    });
    setNewNote('');
  };

  const removeNote = (spaceId, noteId) => {
    persist({
      spaces: data.spaces.map(s => s.id === spaceId ? { ...s, items: s.items.filter(n => n.id !== noteId) } : s),
    });
  };

  const saveEdit = (spaceId) => {
    persist({
      spaces: data.spaces.map(s => s.id === spaceId
        ? { ...s, items: s.items.map(n => n.id === editId ? { ...n, text: editText } : n) }
        : s),
    });
    setEditId(null);
    setEditText('');
  };

  const current = data.spaces.find(s => s.id === activeSpace);

  return (
    <div className="fixed inset-0 z-50 flex p-4 bg-black/50 overflow-y-auto">
      <div ref={glassRef} className="glass max-w-lg w-full p-6 m-auto">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            {activeSpace && (
              <button onClick={() => setActiveSpace(null)} className="p-1 rounded-full hover:bg-foreground/10">
                <ChevronLeft size={20} className="text-muted-foreground" />
              </button>
            )}
            <NotebookPen size={22} className="text-emerald-500" />
            <h2 className="font-heading text-xl font-bold text-foreground">
              {current ? current.name : 'الملاحظات'}
            </h2>
          </div>
          <button onClick={onClose} className="p-2 rounded-full hover:bg-foreground/10 text-muted-foreground">✕</button>
        </div>

        {!activeSpace ? (
          /* قائمة المساحات */
          <>
            <div className="flex gap-2 mb-4">
              <input
                value={newSpace}
                onChange={(e) => setNewSpace(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && addSpace()}
                placeholder="اسم مساحة جديدة..."
                className="flex-1 px-3 py-2 bg-foreground/5 text-sm outline-none focus:bg-foreground/10"
                style={{ borderRadius: 14 }}
              />
              <button onClick={addSpace} disabled={!newSpace.trim()} className="p-2.5 bg-emerald-600 dark:bg-emerald-500 text-white disabled:opacity-40" style={{ borderRadius: 14 }}>
                <FolderPlus size={18} />
              </button>
            </div>
            <div className="space-y-2">
              {data.spaces.map(s => (
                <button
                  key={s.id}
                  onClick={() => setActiveSpace(s.id)}
                  className="w-full flex items-center gap-3 bg-foreground/5 p-3 hover:bg-foreground/10 transition-colors text-right"
                  style={{ borderRadius: 16 }}
                >
                  <Folder size={18} className="text-emerald-500 shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="font-heading text-sm font-bold text-foreground truncate">{s.name}</p>
                    <p className="text-[10px] text-muted-foreground">{s.items.length} ملاحظة</p>
                  </div>
                  {data.spaces.length > 1 && (
                    <span
                      onClick={(e) => { e.stopPropagation(); removeSpace(s.id); }}
                      className="p-1.5 rounded-full hover:bg-red-500/10"
                    >
                      <Trash2 size={15} className="text-red-500" />
                    </span>
                  )}
                </button>
              ))}
            </div>
          </>
        ) : (
          /* داخل مساحة */
          <>
            <div className="flex gap-2 mb-4">
              <input
                value={newNote}
                onChange={(e) => setNewNote(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && addNote()}
                placeholder="اكتب ملاحظة..."
                className="flex-1 px-3 py-2 bg-foreground/5 text-sm outline-none focus:bg-foreground/10"
                style={{ borderRadius: 14 }}
              />
              <button onClick={addNote} disabled={!newNote.trim()} className="p-2.5 bg-emerald-600 dark:bg-emerald-500 text-white disabled:opacity-40" style={{ borderRadius: 14 }}>
                <Plus size={18} />
              </button>
            </div>
            {current.items.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-8">لا توجد ملاحظات بعد</p>
            ) : (
              <div className="space-y-2 max-h-80 overflow-y-auto">
                {current.items.map(n => (
                  <div key={n.id} className="bg-foreground/5 p-3" style={{ borderRadius: 16 }}>
                    {editId === n.id ? (
                      <div>
                        <textarea
                          value={editText}
                          onChange={(e) => setEditText(e.target.value)}
                          className="w-full bg-background/50 p-2 text-sm outline-none resize-none"
                          style={{ borderRadius: 10 }}
                          rows={3}
                          autoFocus
                        />
                        <div className="flex gap-2 mt-2">
                          <button onClick={() => saveEdit(current.id)} className="flex-1 py-1.5 bg-emerald-600 text-white text-xs" style={{ borderRadius: 10 }}>حفظ</button>
                          <button onClick={() => setEditId(null)} className="flex-1 py-1.5 bg-foreground/5 text-xs" style={{ borderRadius: 10 }}>إلغاء</button>
                        </div>
                      </div>
                    ) : (
                      <div className="flex items-start gap-2">
                        <p
                          className="flex-1 text-sm text-foreground whitespace-pre-wrap cursor-pointer"
                          onClick={() => { setEditId(n.id); setEditText(n.text); }}
                        >
                          {n.text}
                        </p>
                        <button onClick={() => removeNote(current.id, n.id)} className="p-1 rounded-full hover:bg-red-500/10 shrink-0">
                          <Trash2 size={14} className="text-red-500" />
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}