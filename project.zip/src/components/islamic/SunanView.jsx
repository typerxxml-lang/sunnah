import { useState, useEffect } from 'react';
import { sunan, sunanCategories } from '@/data/sunan';
import SunnahCard from './SunnahCard';

export default function SunanView({ onSelectSunnah, isFavorite, onToggleFavorite }) {
  const [category, setCategory] = useState('all');
  const [visibleCount, setVisibleCount] = useState(20);

  const filtered = category === 'all'
    ? sunan
    : sunan.filter(s => s.category === category);

  useEffect(() => setVisibleCount(20), [category]);

  const activeCat = sunanCategories.find(c => c.id === category);
  const visible = filtered.slice(0, visibleCount);

  return (
    <div>
      <div className="mb-4">
        <h2 className="font-heading text-xl font-bold text-foreground mb-1">السنن النبوية</h2>
        <p className="text-sm text-muted-foreground">
          {filtered.length} سنة {activeCat && activeCat.id !== 'all' ? `في ${activeCat.name}` : 'في جميع الأبواب'}
        </p>
      </div>

      <div className="flex gap-2 overflow-x-auto pb-3 -mx-4 px-4 scrollbar-hide mb-2">
        {sunanCategories.map(c => (
          <button
            key={c.id}
            onClick={() => setCategory(c.id)}
            className={`shrink-0 px-4 py-2 rounded-full text-sm font-medium transition-all whitespace-nowrap ${
              category === c.id
                ? 'bg-emerald-600 dark:bg-emerald-500 text-white'
                : 'glass-blur text-muted-foreground hover:text-foreground'
            }`}
          >
            {c.name}
          </button>
        ))}
      </div>

      <div className="space-y-3">
        {visible.map(s => (
          <SunnahCard
            key={s.id}
            sunnah={s}
            onClick={() => onSelectSunnah(s)}
            isFavorite={isFavorite(s.id)}
            onToggleFavorite={() => onToggleFavorite(s.id)}
          />
        ))}
      </div>

      {filtered.length > visibleCount && (
        <button
          onClick={() => setVisibleCount(c => c + 20)}
          className="glass-blur w-full py-3 mt-3 text-sm font-medium text-emerald-600 dark:text-emerald-400 hover:scale-[1.01] transition-transform"
          style={{ borderRadius: 24 }}
        >
          عرض المزيد ({filtered.length - visibleCount} متبقٍ)
        </button>
      )}
    </div>
  );
}