import { useState } from 'react';
import { quranVerses } from '@/data/quran';
import QuranCard from './QuranCard';
import MemorizationView from './MemorizationView';
import QuranSurahFilter from '@/components/islamic/QuranSurahFilter';

export default function QuranView() {
  const [subTab, setSubTab] = useState('verses');
  const [visibleCount, setVisibleCount] = useState(20);
  const [surah, setSurah] = useState('all');
  const filtered = surah === 'all' ? quranVerses : quranVerses.filter(verse => verse.surahNumber === Number(surah));
  const visible = filtered.slice(0, visibleCount);
  const selectSurah = value => {
    setSurah(value);
    setVisibleCount(20);
  };

  return (
    <div>
      <div className="mb-4">
        <h2 className="font-heading text-xl font-bold text-foreground mb-1">القرآن الكريم</h2>
        <p className="text-sm text-muted-foreground">
          {subTab === 'verses' ? `${filtered.length} آية مع المعنى • جزء عمّ كاملاً متاح` : 'تتبع حفظك للقرآن الكريم'}
        </p>
      </div>

      {/* Sub-tab toggle */}
      <div className="flex gap-2 mb-4">
        <button
          onClick={() => setSubTab('verses')}
          className={`flex-1 py-2.5 rounded-full text-sm font-medium transition-all ${
            subTab === 'verses'
              ? 'bg-emerald-600 dark:bg-emerald-500 text-white'
              : 'glass-blur text-muted-foreground'
          }`}
        >
          آيات مختارة
        </button>
        <button
          onClick={() => setSubTab('memorization')}
          className={`flex-1 py-2.5 rounded-full text-sm font-medium transition-all ${
            subTab === 'memorization'
              ? 'bg-emerald-600 dark:bg-emerald-500 text-white'
              : 'glass-blur text-muted-foreground'
          }`}
        >
          نظام التحفيظ
        </button>
      </div>

      {subTab === 'verses' && (
        <>
          <QuranSurahFilter value={surah} onChange={selectSurah} verses={quranVerses} />
          <div className="space-y-3">
            {visible.map(v => (
              <QuranCard key={v.id} verse={v} />
            ))}
          </div>

          {filtered.length > visibleCount && (
            <button
              onClick={() => setVisibleCount(c => c + 20)}
              className="glass-blur w-full py-3 mt-3 text-sm font-medium text-emerald-600 dark:text-emerald-400 hover:scale-[1.01] transition-transform"
              style={{ borderRadius: 24 }}
            >
              عرض المزيد ({filtered.length - visibleCount} متبقٍ)
            </button>
          )}
        </>
      )}

      {subTab === 'memorization' && <MemorizationView />}
    </div>
  );
}