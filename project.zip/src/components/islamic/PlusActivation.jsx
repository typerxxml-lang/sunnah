import { Crown, CheckCircle2, Infinity as InfinityIcon } from 'lucide-react';
import { usePlus } from '@/hooks/usePlus';
import ManagementModal from '@/components/islamic/ManagementModal';
import AccountRequired from '@/components/islamic/AccountRequired';
import PlusActivationForm from '@/components/islamic/PlusActivationForm';
import { useLaunchPromo, daysLeftText } from '@/hooks/useLaunchPromo';

export default function PlusActivation({ onClose, user }) {
  const { isPlusActive, activatePlus, plusRecord } = usePlus();
  const promo = useLaunchPromo();
  const promoOnly = promo.active && !plusRecord;
  return (
    <ManagementModal title="اشتراك PLUS" Icon={Crown} onClose={onClose}>
      {promoOnly ? (
        <div className="space-y-5">
          <div className="text-center py-4" role="status">
            <CheckCircle2 size={48} className="text-primary mx-auto mb-3" />
            <p className="text-lg font-bold text-foreground">🎉 مبروك! PLUS مفتوح لك مجاناً</p>
            <p className="mt-2 text-sm text-muted-foreground leading-7">احتفالاً بافتتاح نافعاً، كل مميزات PLUS مفتوحة لجميع المستخدمين لمدة 7 أيام.</p>
            <p className="mt-1 text-sm font-bold text-primary">{daysLeftText(promo.daysLeft)}</p>
          </div>
          {user?.isReal && (
            <div>
              <p className="text-xs text-muted-foreground mb-2 text-center">عندك كود PLUS؟ فعّله الحين ويبقى PLUS معك دائماً بعد انتهاء الاحتفال.</p>
              <PlusActivationForm user={user} onActivate={activatePlus} />
            </div>
          )}
        </div>
      ) : isPlusActive ? (
        <div className="text-center py-6" role="status">
          <CheckCircle2 size={48} className="text-primary mx-auto mb-3" />
          <p className="text-lg font-bold text-foreground">PLUS مفعّل دائماً</p>
          <p className="flex items-center justify-center gap-1.5 mt-2 text-sm text-muted-foreground">
            <InfinityIcon size={15} /> دائم حتى إلغاء المطور
          </p>
        </div>
      ) : !user?.isReal ? (
        <AccountRequired message="سجّل الدخول باسمك لتفعيل كود PLUS." />
      ) : (
        <PlusActivationForm user={user} onActivate={activatePlus} />
      )}
    </ManagementModal>
  );
}