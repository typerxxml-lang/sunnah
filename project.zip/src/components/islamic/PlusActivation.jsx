import { Crown, CheckCircle2, Infinity as InfinityIcon } from 'lucide-react';
import { usePlus } from '@/hooks/usePlus';
import ManagementModal from '@/components/islamic/ManagementModal';
import AccountRequired from '@/components/islamic/AccountRequired';
import PlusActivationForm from '@/components/islamic/PlusActivationForm';

export default function PlusActivation({ onClose, user }) {
  const { isPlusActive, activatePlus } = usePlus();
  return (
    <ManagementModal title="اشتراك PLUS" Icon={Crown} onClose={onClose}>
      {isPlusActive ? (
        <div className="text-center py-6" role="status">
          <CheckCircle2 size={48} className="text-primary mx-auto mb-3" />
          <p className="text-lg font-bold text-foreground">PLUS مفعّل دائماً</p>
          <p className="flex items-center justify-center gap-1.5 mt-2 text-sm text-muted-foreground">
            <InfinityIcon size={15} /> دائم حتى إلغاء المطور
          </p>
        </div>
      ) : !user?.isReal ? (
        <AccountRequired message="سجّل الدخول باسمك لتفعيل كود PLUS." />
      ) : (
        <PlusActivationForm user={user} onActivate={activatePlus} />
      )}
    </ManagementModal>
  );
}