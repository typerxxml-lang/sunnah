import { useState } from 'react';
import { Sparkles, Loader2 } from 'lucide-react';
import { validatePlusCode, consumePlusCode, plusCodeError } from '@/lib/plusCodes';

export default function PlusActivationForm({ user, onActivate }) {
  const [code, setCode] = useState(''), [error, setError] = useState(''), [loading, setLoading] = useState(false);
  const submit = async event => {
    event.preventDefault();
    if (loading) return;
    setError(''); setLoading(true);
    try {
      const result = await validatePlusCode(code);
      if (!result.valid) { setError(result.reason); return; }
      await consumePlusCode(result.record.id, user.id);
      await onActivate(result.record.expires_at, result.record.code);
    } catch (failure) { setError(plusCodeError(failure, 'تعذّر تفعيل الكود. حاول مجدداً.')); }
    finally { setLoading(false); }
  };
  return (
    <form onSubmit={submit} className="space-y-3">
      <p className="text-sm text-muted-foreground text-center">أدخل كود التفعيل للاستمتاع بالثيمات الحصرية والمميزات الإضافية</p>
      <input value={code} onChange={event => { setCode(event.target.value.toUpperCase().replace(/\s/g, '')); setError(''); }} dir="ltr"
        placeholder="XXXXXX" maxLength={6} minLength={6} required disabled={loading} autoComplete="off" aria-label="كود تفعيل PLUS"
        className="w-full rounded-2xl border border-input bg-muted/50 px-4 py-3 text-center text-2xl font-mono tracking-widest text-foreground focus:outline-none focus:ring-2 focus:ring-ring" />
      <button type="submit" disabled={code.length !== 6 || loading} className="w-full rounded-2xl bg-primary text-primary-foreground py-3 font-bold flex items-center justify-center gap-2 disabled:opacity-50">
        {loading ? <Loader2 size={17} className="animate-spin" /> : <Sparkles size={17} />}{loading ? 'جارٍ التحقق...' : 'تفعيل'}
      </button>
      {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
    </form>
  );
}