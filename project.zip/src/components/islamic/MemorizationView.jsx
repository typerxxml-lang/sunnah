import { useState, useEffect } from 'react';
import { useGlassEffect } from '@/hooks/useGlassEffect';
import { loadJSON, saveJSON } from '@/lib/storage';
import { Check, BookOpen, Award } from 'lucide-react';
import { SURAHS } from '@/data/surahs';

export default function MemorizationView() {
  const [memorized, setMemorized] = useState(() => loadJSON('iq-memorized', []));
  const [filter, setFilter] = useState('all');
  const glassRef = useGlassEffect(34, 26, 46);

  useEffect(() => {
    saveJSON('iq-memorized', memorized);
  }, [memorized]);

  const toggle = (number) => {
    setMemorized(prev =>
      prev.includes(number) ? prev.filter(n => n !== number) : [...prev, number]
    );
  };

  const totalAyahs = SURAHS.reduce((sum, s) => sum + s.ayahs, 0);
  const memorizedAyahs = SURAHS
    .filter(s => memorized.includes(s.number))
    .reduce((sum, s) => sum + s.ayahs, 0);
  const progress = Math.round((memorizedAyahs / totalAyahs) * 100);

  const filtered = filter === 'all'
    ? SURAHS
    : filter === 'memorized'
    ? SURAHS.filter(s => memorized.includes(s.number))
    : SURAHS.filter(s => !memorized.includes(s.number));

  return (
    <div className="space-y-5">
      <div>
        <h2 className="font-heading text-xl font-bold text-foreground mb-1">نظام التحفيظ</h2>
        <p className="text-sm text-muted-foreground">تتبع حفظك للقرآن الكريم</p>
      </div>

      {/* Progress card */}
      <div ref={glassRef} className="glass p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Award size={20} className="text-emerald-600 dark:text-emerald-400" />
            <h3 className="font-heading text-base font-bold text-foreground">تقدمك في الحفظ</h3>
          </div>
          <span className="text-2xl font-bold text-emerald-600 dark:text-emerald-400">{progress}%</span>
        </div>

        {/* Progress bar */}
        <div className="h-3 rounded-full bg-foreground/10 overflow-hidden mb-4">
          <div
            className="h-full rounded-full bg-emerald-600 dark:bg-emerald-500 transition-all duration-500"
            style={{ width: `${progress}%` }}
          />
        </div>

        <div className="grid grid-cols-3 gap-3 text-center">
          <div>
            <p className="font-heading text-xl font-bold text-foreground">{memorized.length}</p>
            <p className="text-[11px] text-muted-foreground">سورة محفوظة</p>
          </div>
          <div>
            <p className="font-heading text-xl font-bold text-foreground">{memorizedAyahs}</p>
            <p className="text-[11px] text-muted-foreground">آية محفوظة</p>
          </div>
          <div>
            <p className="font-heading text-xl font-bold text-foreground">{SURAHS.length - memorized.length}</p>
            <p className="text-[11px] text-muted-foreground">سورة متبقية</p>
          </div>
        </div>
      </div>

      {/* Filter */}
      <div className="flex gap-2">
        {[
          { id: 'all', label: 'الكل' },
          { id: 'memorized', label: 'محفوظة' },
          { id: 'remaining', label: 'متبقية' },
        ].map(f => (
          <button
            key={f.id}
            onClick={() => setFilter(f.id)}
            className={`flex-1 py-2 rounded-full text-sm font-medium transition-all ${
              filter === f.id
                ? 'bg-emerald-600 dark:bg-emerald-500 text-white'
                : 'glass-blur text-muted-foreground'
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* Surah list */}
      <div className="space-y-2">
        {filtered.map(surah => {
          const isMemorized = memorized.includes(surah.number);
          return (
            <button
              key={surah.number}
              onClick={() => toggle(surah.number)}
              className={`glass-blur w-full p-4 flex items-center gap-3 transition-all active:scale-[0.98] ${
                isMemorized ? 'opacity-60' : ''
              }`}
            >
              <div
                className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 transition-all ${
                  isMemorized
                    ? 'bg-emerald-600 dark:bg-emerald-500'
                    : 'bg-foreground/10'
                }`}
              >
                {isMemorized ? (
                  <Check size={20} className="text-white" />
                ) : (
                  <span className="text-sm font-bold text-muted-foreground">{surah.number}</span>
                )}
              </div>

              <div className="flex-1 text-right">
                <p className={`font-heading font-bold ${isMemorized ? 'text-emerald-600 dark:text-emerald-400' : 'text-foreground'}`}>
                  {surah.name}
                </p>
                <p className="text-xs text-muted-foreground">
                  {surah.ayahs} آية • {surah.type}
                </p>
              </div>

              <BookOpen
                size={18}
                className={isMemorized ? 'text-emerald-600 dark:text-emerald-400' : 'text-muted-foreground/40'}
              />
            </button>
          );
        })}
      </div>
    </div>
  );
}