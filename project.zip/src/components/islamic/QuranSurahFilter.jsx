import { SURAHS } from '@/data/surahs';

export default function QuranSurahFilter({ value, onChange, verses }) {
  const available = new Set(verses.map(verse => verse.surahNumber));
  return (
    <div className="mb-4 space-y-2">
      <label htmlFor="quran-surah" className="text-sm text-muted-foreground">اختر السورة</label>
      <select
        id="quran-surah"
        value={value}
        onChange={event => onChange(event.target.value)}
        className="w-full rounded-2xl bg-secondary px-4 py-3 text-sm text-foreground outline-none focus:ring-2 focus:ring-primary"
      >
        <option value="all">جميع الآيات</option>
        {SURAHS.filter(surah => available.has(surah.number)).map(surah => (
          <option key={surah.number} value={String(surah.number)}>{surah.name}</option>
        ))}
      </select>
    </div>
  );
}