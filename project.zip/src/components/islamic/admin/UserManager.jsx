import { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { Ban, ShieldCheck, Crown, Trash2, Loader2, Search } from 'lucide-react';

export default function UserManager() {
  const [users, setUsers] = useState([]);
  const [plusMap, setPlusMap] = useState({});
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const { items: userItems } = await base44.entities.User.list({ limit: 100 });
      const { items: plusRecords } = await base44.entities.UserPlus.filter({ active: true }, { limit: 100 });
      const map = {};
      plusRecords.forEach(p => { map[p.user_id] = p; });
      setPlusMap(map);
      setUsers(userItems);
    } catch {} finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const toggleBan = async (user) => {
    try { await base44.entities.User.update(user.id, { banned: !user.banned }); await load(); }
    catch {}
  };

  const removePlus = async (userId) => {
    const plus = plusMap[userId];
    if (!plus) return;
    try { await base44.entities.UserPlus.delete(plus.id); await load(); } catch {}
  };

  const filtered = users.filter(u => !search || (u.email || '').includes(search) || (u.full_name || '').includes(search));

  return (
    <div className="space-y-3">
      <div className="relative">
        <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="بحث بالبريد أو الاسم..."
          className="w-full rounded-xl border border-input bg-background/50 pr-10 pl-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
      </div>
      {loading ? <div className="flex justify-center py-4"><Loader2 className="animate-spin text-muted-foreground" size={24} /></div> : (
        <div className="space-y-2 max-h-80 overflow-y-auto">
          {filtered.map(u => (
            <div key={u.id} className="rounded-2xl bg-muted/40 border border-border p-3 flex items-center gap-2">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5">
                  <p className="text-sm font-bold text-foreground truncate">{u.full_name || u.email || 'مستخدم'}</p>
                  {plusMap[u.id] && <Crown size={13} className="text-amber-500 shrink-0" />}
                  {u.banned && <span className="text-[10px] bg-destructive/15 text-destructive px-2 py-0.5 rounded-full shrink-0">محظور</span>}
                </div>
                <p className="text-xs text-muted-foreground truncate">{u.email}</p>
              </div>
              <div className="flex shrink-0 gap-1">
                {plusMap[u.id] && (
                  <button onClick={() => removePlus(u.id)} title="إزالة PLUS" className="p-1.5 rounded-lg hover:bg-amber-500/10">
                    <Trash2 size={15} className="text-amber-500" />
                  </button>
                )}
                <button onClick={() => toggleBan(u)} title={u.banned ? 'إلغاء الحظر' : 'حظر'}
                  className={`p-1.5 rounded-lg ${u.banned ? 'hover:bg-primary/10' : 'hover:bg-destructive/10'}`}>
                  {u.banned ? <ShieldCheck size={15} className="text-primary" /> : <Ban size={15} className="text-destructive" />}
                </button>
              </div>
            </div>
          ))}
          {!filtered.length && <p className="text-sm text-muted-foreground text-center py-6">لا يوجد مستخدمون</p>}
        </div>
      )}
    </div>
  );
}