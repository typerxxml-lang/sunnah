import { useState } from 'react';
import { KeyRound, Loader2 } from 'lucide-react';
import PlusCodeItem from '@/components/islamic/admin/PlusCodeItem';

export default function PlusCodeForm({ onCreate, busy }) {
  const [duration, setDuration] = useState(20), [note, setNote] = useState(''), [created, setCreated] = useState(null);
  const submit = async event => {
    event.preventDefault();
    if (busy) return;
    const record = await onCreate(duration, note);
    if (record) { setNote(''); setCreated(record); }
  };
  return (
    <form onSubmit={submit} className="rounded-3xl bg-muted/40 border border-border p-4 space-y-3">
      <h3 className="flex items-center gap-2 text-sm font-bold"><KeyRound size={18} className="text-primary" /> توليد كود PLUS</h3>
      <fieldset disabled={busy}>
        <legend className="text-xs text-muted-foreground mb-2">مدة الصلاحية (دقيقة)</legend>
        <div className="grid grid-cols-4 gap-2">
          {[20, 60, 180, 1440].map(minutes => <button type="button" key={minutes} onClick={() => setDuration(minutes)} aria-pressed={duration === minutes}
            className={`rounded-xl py-2 text-xs ${duration === minutes ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'}`}>{minutes < 60 ? `${minutes}د` : minutes < 1440 ? `${minutes / 60}س` : 'يوم'}</button>)}
        </div>
      </fieldset>
      <input value={note} onChange={event => setNote(event.target.value)} placeholder="ملاحظة (اختياري)" aria-label="ملاحظة الكود" maxLength={200} disabled={busy}
        className="w-full rounded-xl border border-input bg-background/50 px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring" />
      <button type="submit" disabled={busy} className="w-full rounded-2xl bg-primary text-primary-foreground py-3 text-sm font-bold flex items-center justify-center gap-2 disabled:opacity-50">
        {busy ? <Loader2 size={16} className="animate-spin" /> : <KeyRound size={16} />}{busy ? 'جارٍ التنفيذ...' : 'توليد كود'}
      </button>
      {created && <div><p role="status" className="text-xs text-primary mb-2">تم إنشاء الكود وحفظه بنجاح</p><PlusCodeItem record={created} /></div>}
    </form>
  );
}