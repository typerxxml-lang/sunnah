import { useRef, useState } from 'react';
import { Download, Upload } from 'lucide-react';

// نسخة احتياطية لبيانات التطبيق المحفوظة على هذا الجهاز (إعدادات، مفضلات، أكواد، محتوى...).
export default function BackupExport() {
  const fileRef = useRef(null);
  const [msg, setMsg] = useState('');

  const exportData = () => {
    const data = {};
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && k.startsWith('iq-')) data[k] = localStorage.getItem(k);
    }
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `nafiahan-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(a.href);
    setMsg('تم تنزيل النسخة الاحتياطية.');
  };

  const importData = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const data = JSON.parse(await file.text());
      Object.entries(data).forEach(([k, v]) => { if (k.startsWith('iq-') && typeof v === 'string') localStorage.setItem(k, v); });
      setMsg('تمت الاستعادة، جارٍ إعادة التحميل...');
      setTimeout(() => window.location.reload(), 800);
    } catch { setMsg('الملف غير صالح.'); }
  };

  return (
    <div className="space-y-3">
      <p className="text-sm leading-relaxed text-muted-foreground">بيانات التطبيق محفوظة على هذا الجهاز فقط. نزّل نسخة احتياطية لنقلها أو حفظها، واستعدها وقت ما تحتاج.</p>
      <button type="button" onClick={exportData} className="w-full flex items-center justify-center gap-2 rounded-2xl bg-primary text-primary-foreground py-3 text-sm font-bold"><Download size={17} /> تنزيل نسخة احتياطية</button>
      <button type="button" onClick={() => fileRef.current?.click()} className="w-full flex items-center justify-center gap-2 rounded-2xl bg-muted text-foreground py-3 text-sm font-bold"><Upload size={17} /> استعادة من ملف</button>
      <input ref={fileRef} type="file" accept="application/json,.json" className="hidden" onChange={importData} />
      {msg && <p role="status" className="text-sm text-center text-muted-foreground">{msg}</p>}
    </div>
  );
}
