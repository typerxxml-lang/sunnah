import { RefreshCw, Loader2 } from 'lucide-react';
import PlusCodeItem from '@/components/islamic/admin/PlusCodeItem';

export default function PlusCodeList({ page, loading, pending, onRefresh, onLoadMore, onRemove }) {
  return (
    <div className="rounded-3xl border border-border bg-muted/40 p-4 space-y-3">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-bold">الأكواد النشطة ({page.total})</h3>
        <button type="button" onClick={onRefresh} disabled={loading || !!pending} aria-label="تحديث الأكواد" className="rounded-full p-2 hover:bg-muted disabled:opacity-50"><RefreshCw size={16} className={loading ? 'animate-spin' : ''} /></button>
      </div>
      {loading && !page.items.length ? <div className="flex items-center justify-center gap-2 py-4 text-sm text-muted-foreground"><Loader2 size={18} className="animate-spin" /> جارٍ تحميل الأكواد...</div>
        : !page.items.length ? <p className="text-xs text-muted-foreground text-center py-4">لا توجد أكواد نشطة</p>
        : <div className="max-h-64 overflow-y-auto space-y-2">{page.items.map(record => <PlusCodeItem key={record.id} record={record} onRemove={onRemove} disabled={loading || !!pending} />)}</div>}
      {page.has_more && <button type="button" onClick={onLoadMore} disabled={loading || !!pending} className="w-full rounded-xl bg-muted py-2 text-sm text-primary disabled:opacity-50">{loading ? 'جارٍ التحميل...' : 'تحميل المزيد'}</button>}
    </div>
  );
}