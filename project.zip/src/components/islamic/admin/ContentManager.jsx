import { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { Plus, Trash2, Pencil, BookOpen, ScrollText, FileText, Eye, EyeOff, Loader2 } from 'lucide-react';

const TYPES = [
  { id: 'sunnah', label: 'سنة', icon: ScrollText },
  { id: 'hadith', label: 'حديث', icon: BookOpen },
  { id: 'quran', label: 'آية', icon: BookOpen },
  { id: 'note', label: 'تنويه', icon: FileText },
];

export default function ContentManager() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ type: 'note', title: '', text: '', category: '', narrator: '', authenticity: '', reference: '', show_on_home: false, active: true });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const { items: records } = await base44.entities.CustomContent.filter({}, { sort: '-created_date', limit: 100 });
      setItems(records);
    } catch {} finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const save = async () => {
    if (!form.title.trim() || !form.text.trim()) return;
    try {
      if (editing) await base44.entities.CustomContent.update(editing, form);
      else await base44.entities.CustomContent.create(form);
      setForm({ type: 'note', title: '', text: '', category: '', narrator: '', authenticity: '', reference: '', show_on_home: false, active: true });
      setEditing(null);
      await load();
    } catch {}
  };

  const edit = (item) => {
    setEditing(item.id);
    setForm({ type: item.type, title: item.title, text: item.text, category: item.category || '', narrator: item.narrator || '', authenticity: item.authenticity || '', reference: item.reference || '', show_on_home: item.show_on_home, active: item.active });
  };

  const remove = async (id) => { await base44.entities.CustomContent.delete(id); await load(); };
  const toggleField = async (item, field) => { await base44.entities.CustomContent.update(item.id, { [field]: !item[field] }); await load(); };

  return (
    <div className="space-y-4">
      <div className="rounded-2xl bg-muted/40 border border-border p-4 space-y-3">
        <h3 className="text-sm font-bold flex items-center gap-2"><Plus size={16} className="text-primary" />{editing ? 'تعديل محتوى' : 'إضافة محتوى'}</h3>
        <div className="grid grid-cols-4 gap-2">
          {TYPES.map(({ id, label, icon: Icon }) => (
            <button key={id} onClick={() => setForm(f => ({ ...f, type: id }))} aria-pressed={form.type === id}
              className={`flex flex-col items-center gap-1 py-2 text-xs ${form.type === id ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'}`} style={{ borderRadius: 12 }}>
              <Icon size={16} />{label}
            </button>
          ))}
        </div>
        <input value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} placeholder="العنوان" maxLength={200}
          className="w-full rounded-xl border border-input bg-background/50 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
        <textarea value={form.text} onChange={e => setForm(f => ({ ...f, text: e.target.value }))} placeholder="النص" rows={3} maxLength={2000}
          className="w-full rounded-xl border border-input bg-background/50 px-3 py-2 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-ring" />
        {form.type !== 'note' && (
          <div className="grid grid-cols-2 gap-2">
            <input value={form.narrator} onChange={e => setForm(f => ({ ...f, narrator: e.target.value }))} placeholder="الراوي" maxLength={100}
              className="rounded-xl border border-input bg-background/50 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
            <input value={form.reference} onChange={e => setForm(f => ({ ...f, reference: e.target.value }))} placeholder="المرجع" maxLength={100}
              className="rounded-xl border border-input bg-background/50 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
            <input value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value }))} placeholder="التصنيف" maxLength={50}
              className="rounded-xl border border-input bg-background/50 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
            <input value={form.authenticity} onChange={e => setForm(f => ({ ...f, authenticity: e.target.value }))} placeholder="درجة الصحة" maxLength={30}
              className="rounded-xl border border-input bg-background/50 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
          </div>
        )}
        {form.type === 'note' && (
          <label className="flex items-center gap-2 text-sm text-muted-foreground">
            <input type="checkbox" checked={form.show_on_home} onChange={e => setForm(f => ({ ...f, show_on_home: e.target.checked }))} className="accent-primary w-4 h-4" />
            إظهار في الرئيسية كتنويه من الإدارة
          </label>
        )}
        <div className="flex gap-2">
          <button onClick={save} disabled={!form.title.trim() || !form.text.trim()} className="flex-1 rounded-xl bg-primary text-primary-foreground py-2.5 text-sm font-bold disabled:opacity-50">حفظ</button>
          {editing && <button onClick={() => { setEditing(null); setForm({ type: 'note', title: '', text: '', category: '', narrator: '', authenticity: '', reference: '', show_on_home: false, active: true }); }} className="rounded-xl bg-muted px-4 py-2.5 text-sm">إلغاء</button>}
        </div>
      </div>

      {loading ? <div className="flex justify-center py-4"><Loader2 className="animate-spin text-muted-foreground" size={24} /></div> : (
        <div className="space-y-2 max-h-80 overflow-y-auto">
          {items.map(item => {
            const typeInfo = TYPES.find(t => t.id === item.type);
            return (
              <div key={item.id} className="rounded-2xl bg-muted/40 border border-border p-3">
                <div className="flex items-start gap-2">
                  <span className="shrink-0 rounded-lg bg-primary/10 p-1.5">{typeInfo && <typeInfo.icon size={15} className="text-primary" />}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-bold text-foreground truncate">{item.title}</p>
                    <p className="text-xs text-muted-foreground line-clamp-2 mt-0.5">{item.text}</p>
                    <div className="flex items-center gap-2 mt-1.5">
                      {item.type === 'note' && item.show_on_home && <span className="text-[10px] bg-amber-500/15 text-amber-600 dark:text-amber-400 px-2 py-0.5 rounded-full">في الرئيسية</span>}
                      {!item.active && <span className="text-[10px] bg-foreground/10 text-muted-foreground px-2 py-0.5 rounded-full">مخفي</span>}
                    </div>
                  </div>
                  <div className="flex shrink-0 gap-1">
                    <button onClick={() => toggleField(item, 'active')} className="p-1.5 rounded-lg hover:bg-foreground/10">{item.active ? <Eye size={15} className="text-primary" /> : <EyeOff size={15} className="text-muted-foreground" />}</button>
                    <button onClick={() => edit(item)} className="p-1.5 rounded-lg hover:bg-foreground/10"><Pencil size={15} className="text-muted-foreground" /></button>
                    <button onClick={() => remove(item.id)} className="p-1.5 rounded-lg hover:bg-destructive/10"><Trash2 size={15} className="text-destructive" /></button>
                  </div>
                </div>
              </div>
            );
          })}
          {!items.length && <p className="text-sm text-muted-foreground text-center py-6">لا يوجد محتوى مخصص بعد</p>}
        </div>
      )}
    </div>
  );
}