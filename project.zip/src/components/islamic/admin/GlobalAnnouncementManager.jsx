import { useCallback, useEffect, useState } from 'react';
import { BellRing, Loader2, Save, Eye, EyeOff } from 'lucide-react';
import { adminRequest } from '@/lib/adminApi';

export default function GlobalAnnouncementManager() {
  const [message, setMessage] = useState('');
  const [active, setActive] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const load = useCallback(async () => {
    setLoading(true); setError('');
    try {
      const response = await fetch('/api/announcement', { cache: 'no-store' });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || 'تعذّر تحميل التنبيه العام.');
      setMessage(data.message || ''); setActive(!!data.active);
    } catch (failure) { setError(failure?.message || 'تعذّر تحميل التنبيه.'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const save = async () => {
    if (saving) return;
    setSaving(true); setError(''); setSuccess('');
    try {
      await adminRequest('/api/announcement', { method: 'POST', body: { message, active } });
      setSuccess(active && message.trim() ? 'تم نشر التنبيه لجميع زوار الموقع.' : 'تم حفظ التغيير وإخفاء التنبيه عن الجميع.');
    } catch (failure) { setError(failure?.message || 'تعذّر حفظ التنبيه.'); }
    finally { setSaving(false); }
  };

  return (
    <div className="space-y-4 rounded-3xl border border-border bg-muted/40 p-4">
      <div className="flex items-center gap-2"><BellRing size={18} className="text-primary" /><h3 className="text-sm font-bold">تنبيه عام من المطور</h3></div>
      <p className="text-xs leading-relaxed text-muted-foreground">هذا التنبيه محفوظ على قاعدة مشتركة ويظهر في الصفحة الرئيسية لكل زوار نافعاً، مهما اختلفت الدولة أو الجهاز.</p>
      {loading ? <div className="flex items-center justify-center gap-2 py-5 text-sm text-muted-foreground"><Loader2 size={18} className="animate-spin" /> جارٍ تحميل التنبيه...</div> : <>
        <textarea value={message} onChange={event => { setMessage(event.target.value); setSuccess(''); }} maxLength={1500} rows={5} placeholder="اكتب التنبيه الذي تريد إظهاره للجميع..." className="w-full resize-y rounded-2xl border border-input bg-background/60 p-3 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring" />
        <div className="flex items-center justify-between gap-3 rounded-2xl bg-background/50 p-3">
          <div className="flex items-center gap-2 text-sm"><span className="text-foreground">عرض التنبيه في الرئيسية</span>{active ? <Eye size={16} className="text-primary" /> : <EyeOff size={16} className="text-muted-foreground" />}</div>
          <button type="button" onClick={() => { setActive(value => !value); setSuccess(''); }} aria-pressed={active} className={`relative h-7 w-12 rounded-full p-1 transition-colors ${active ? 'bg-primary' : 'bg-foreground/20'}`}><span className={`block h-5 w-5 rounded-full bg-white shadow transition-transform ${active ? '-translate-x-5' : 'translate-x-0'}`} /></button>
        </div>
        <p className="text-left text-[10px] text-muted-foreground">{message.length}/1500</p>
        <button type="button" onClick={save} disabled={saving || loading} className="flex w-full items-center justify-center gap-2 rounded-2xl bg-primary py-3 text-sm font-bold text-primary-foreground disabled:opacity-50">{saving ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />}{saving ? 'جارٍ الحفظ...' : 'حفظ ونشر للجميع'}</button>
      </>}
      {error && <p role="alert" className="rounded-xl bg-destructive/10 p-3 text-xs text-destructive">{error}</p>}
      {success && <p role="status" className="rounded-xl bg-primary/10 p-3 text-xs text-primary">{success}</p>}
    </div>
  );
}
