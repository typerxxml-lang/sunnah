import { useState } from 'react';

export default function AdminUnlock({ onUnlock }) {
  const [password, setPassword] = useState('');
  const [error, setError] = useState(false);
  const submit = event => {
    event.preventDefault();
    if (!onUnlock(password)) setError(true);
  };
  return (
    <form onSubmit={submit} className="space-y-3">
      <label htmlFor="admin-password" className="text-sm text-muted-foreground block">أدخل كلمة المرور للوصول إلى لوحة الإدارة</label>
      <input id="admin-password" type="password" value={password} autoComplete="current-password" autoFocus required dir="ltr"
        onChange={event => { setPassword(event.target.value); setError(false); }}
        className="w-full rounded-2xl border border-input bg-muted/50 px-4 py-3 text-center text-foreground focus:outline-none focus:ring-2 focus:ring-ring" />
      {error && <p role="alert" className="text-sm text-destructive">كلمة المرور غير صحيحة</p>}
      <button type="submit" disabled={!password} className="w-full rounded-2xl bg-primary text-primary-foreground py-3 font-bold disabled:opacity-50">دخول</button>
    </form>
  );
}