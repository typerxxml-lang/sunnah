import { useState } from 'react';

export default function AdminUnlock({ onUnlock }) {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const submit = async event => {
    event.preventDefault();
    if (busy) return;
    setBusy(true); setError('');
    try {
      const ok = await onUnlock(password);
      if (!ok) setError('كلمة المرور غير صحيحة.');
    } catch (failure) {
      setError(failure?.message || 'تعذّر تسجيل دخول المطور.');
    } finally { setBusy(false); }
  };
  return (
    <form onSubmit={submit} className="space-y-3">
      <label htmlFor="admin-password" className="text-sm text-muted-foreground block">أدخل كلمة المرور للوصول إلى لوحة الإدارة</label>
      <input id="admin-password" type="password" value={password} autoComplete="current-password" autoFocus required dir="ltr"
        onChange={event => { setPassword(event.target.value); setError(''); }}
        className="w-full rounded-2xl border border-input bg-muted/50 px-4 py-3 text-center text-foreground focus:outline-none focus:ring-2 focus:ring-ring" />
      {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
      <button type="submit" disabled={!password || busy} className="w-full rounded-2xl bg-primary text-primary-foreground py-3 font-bold disabled:opacity-50">{busy ? 'جارٍ التحقق...' : 'دخول'}</button>
    </form>
  );
}
