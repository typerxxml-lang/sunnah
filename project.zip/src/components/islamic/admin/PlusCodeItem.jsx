import { useState } from 'react';
import { Check, Copy, Trash2, Clock } from 'lucide-react';

export default function PlusCodeItem({ record, onRemove, disabled }) {
  const [copied, setCopied] = useState(false), [error, setError] = useState('');
  const minutes = Math.max(0, Math.ceil((new Date(record.expires_at).getTime() - Date.now()) / 60000));
  const copy = async () => {
    setError('');
    try { await navigator.clipboard.writeText(record.code); setCopied(true); }
    catch { setError('تعذّر النسخ؛ يمكنك تحديد الكود ونسخه يدوياً.'); }
  };
  return (
    <div className="rounded-2xl bg-muted/70 p-3">
      <div className="flex items-center gap-2">
        <div className="flex-1 min-w-0">
          <p dir="ltr" className="text-right font-mono font-bold tracking-widest text-foreground select-all">{record.code}</p>
          <p className="flex items-center gap-1 text-xs text-muted-foreground mt-1"><Clock size={12} />{minutes} دقيقة</p>
          {record.note && <p className="truncate text-xs text-muted-foreground mt-1">{record.note}</p>}
        </div>
        <button type="button" onClick={copy} aria-label="نسخ الكود" className="rounded-xl p-2 hover:bg-background">{copied ? <Check size={17} className="text-primary" /> : <Copy size={17} />}</button>
        {onRemove && <button type="button" disabled={disabled} onClick={() => onRemove(record.id)} aria-label="حذف الكود" className="rounded-xl p-2 text-destructive hover:bg-destructive/10 disabled:opacity-50"><Trash2 size={17} /></button>}
      </div>
      {error && <p role="alert" className="text-xs text-destructive mt-2">{error}</p>}
    </div>
  );
}