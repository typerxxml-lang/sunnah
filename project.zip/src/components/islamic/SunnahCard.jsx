import { Star } from 'lucide-react';
import { getClassificationColor, getAuthenticityColor } from '@/lib/badges';

export default function SunnahCard({ sunnah, onClick, isFavorite, onToggleFavorite }) {
  return (
    <div
      onClick={onClick}
      className="glass-blur p-4 cursor-pointer transition-transform duration-300 hover:scale-[1.02] active:scale-[0.98] anim-fade-up"
    >
      <div className="flex items-start justify-between gap-3">
        <h3 className="font-heading text-base font-bold text-foreground leading-snug flex-1">
          {sunnah.title}
        </h3>
        <button
          onClick={(e) => { e.stopPropagation(); onToggleFavorite?.(); }}
          className="shrink-0 p-1.5 rounded-full hover:bg-foreground/10 transition-colors"
          aria-label="إضافة للمفضلة"
        >
          <Star
            size={18}
            className={isFavorite ? 'fill-amber-400 text-amber-400' : 'text-muted-foreground'}
          />
        </button>
      </div>

      <p className="mt-2 text-sm text-muted-foreground leading-relaxed line-clamp-2">
        {sunnah.text}
      </p>

      <div className="mt-3 flex flex-wrap gap-1.5">
        <span className={`badge ${getClassificationColor(sunnah.classification)}`}>
          {sunnah.classification}
        </span>
        <span className={`badge ${getAuthenticityColor(sunnah.authenticity)}`}>
          {sunnah.authenticity}
        </span>
      </div>

      <p className="mt-2 text-xs text-muted-foreground/80">{sunnah.reference}</p>
    </div>
  );
}