import { LogIn } from 'lucide-react';
import { saveJSON } from '@/lib/storage';

export default function AccountRequired({ message }) {
  const signIn = () => { saveJSON('iq-user', null); window.location.reload(); };
  return (
    <div className="space-y-4 text-center">
      <p className="text-sm leading-relaxed text-muted-foreground">{message}</p>
      <button type="button" onClick={signIn} className="w-full flex items-center justify-center gap-2 rounded-2xl bg-primary text-primary-foreground py-3 text-sm font-bold"><LogIn size={17} /> تسجيل الدخول باسمك</button>
    </div>
  );
}
