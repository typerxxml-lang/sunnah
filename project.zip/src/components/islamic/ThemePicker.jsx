import { Check, Crown, Lock } from 'lucide-react';
import { THEMES } from '@/data/themes';

export default function ThemePicker({ theme, themeId, isPlusActive, onChange, onOpenPlus }) {
  return (
    <div>
      <div className="grid grid-cols-3 sm:grid-cols-4 gap-2" role="group" aria-label="اختيار الثيم">
        {THEMES.map(item => {
          const locked = !isPlusActive && item.id !== 'emerald';
          const selected = (themeId || 'emerald') === item.id;
          const palette = theme === 'dark' ? item.dark : item.light;
          return (
            <button key={item.id} type="button" aria-pressed={selected}
              aria-label={`${item.name}${locked ? ' — يتطلب PLUS' : ''}`}
              onClick={() => locked ? onOpenPlus() : onChange(item.id)}
              className={`min-w-0 rounded-2xl border p-2.5 text-center focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${selected ? 'border-primary bg-primary/10' : 'border-border bg-card/40 hover:bg-muted'}`}>
              <div className="h-8 rounded-xl flex items-center justify-end px-1.5"
                style={{ background: `linear-gradient(120deg, hsl(${palette.primary}), hsl(${palette.accent}))` }}>
                {selected ? <Check size={17} className="text-primary-foreground" /> : locked ? <Lock size={13} className="text-primary-foreground" /> : null}
              </div>
              <span className="mt-2 block min-h-[2.5em] text-xs leading-snug text-foreground break-words">{item.name}</span>
            </button>
          );
        })}
      </div>
      {!isPlusActive && <button type="button" onClick={onOpenPlus} className="mt-4 w-full flex items-center justify-center gap-1.5 text-xs text-primary"><Crown size={15} /> فعّل PLUS لفتح كل الثيمات</button>}
    </div>
  );
}