import { useGlassEffect } from '@/hooks/useGlassEffect';
import { useDockPill } from '@/hooks/useDockPill';
import { useSquircleClip } from '@/hooks/useSquircleClip';
import { Home, BookOpen, ScrollText, Sparkles, Settings, Quote } from 'lucide-react';

const TABS = [
  { id: 'home', label: 'الرئيسية', Icon: Home },
  { id: 'sunan', label: 'السنن', Icon: ScrollText },
  { id: 'quran', label: 'القرآن', Icon: BookOpen },
  { id: 'hadiths', label: 'الأحاديث', Icon: Quote },
  { id: 'adhkar', label: 'الأذكار', Icon: Sparkles },
  { id: 'settings', label: 'الإعدادات', Icon: Settings },
];

const MAIN_IDS = TABS.map(t => t.id);

export default function BottomNav({ activeTab, onTabChange }) {
  const activeId = MAIN_IDS.includes(activeTab) ? activeTab : 'settings';
  const { dockRef, pillRef } = useDockPill(activeId, onTabChange);
  const bgGlass = useGlassEffect(35, 24, 54);
  const pillGlass = useGlassEffect(29, 22, 72, 'blur(0.5px) saturate(1.6) brightness(1.08)');
  useSquircleClip(bgGlass);
  useSquircleClip(pillGlass);

  return (
    <nav
      ref={dockRef}
      id="dock"
      className="dock bottom-4 left-3 right-3 mx-auto max-w-md"
      aria-label="التنقل الرئيسي"
    >
      <div ref={bgGlass} className="dock-bg" aria-hidden="true" />
      <div
        id="pill"
        ref={(el) => { pillRef.current = el; pillGlass.current = el; }}
        aria-hidden="true"
      />
      {TABS.map(({ id, label, Icon }) => {
        const active = id === activeId;
        return (
          <button
            key={id}
            data-v={id}
            className={`flex flex-col items-center justify-center gap-1 ${active ? 'on' : ''}`}
            aria-label={label}
            aria-current={active ? 'page' : undefined}
          >
            <Icon size={21} />
            <span className="text-[9px] font-medium">{label}</span>
          </button>
        );
      })}
    </nav>
  );
}