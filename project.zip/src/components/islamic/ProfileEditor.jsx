import { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { User, Camera, Loader2, Check } from 'lucide-react';

export default function ProfileEditor({ user, onUpdated }) {
  const [name, setName] = useState(user?.name || '');
  const [avatarUrl, setAvatarUrl] = useState(null);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef(null);

  useEffect(() => {
    if (user?.avatar_uri) {
      base44.integrations.Core.CreateFileSignedUrl({ file_uri: user.avatar_uri, expires_in: 3600 })
        .then(res => setAvatarUrl(res.signed_url))
        .catch(() => {});
    }
  }, [user?.avatar_uri]);

  const handleAvatar = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const { file_uri } = await base44.integrations.Core.UploadPrivateFile({ file });
      await base44.auth.updateMe({ avatar_uri: file_uri });
      const res = await base44.integrations.Core.CreateFileSignedUrl({ file_uri, expires_in: 3600 });
      setAvatarUrl(res.signed_url);
      onUpdated?.({ ...user, avatar_uri: file_uri });
    } catch (err) { /* ignore */ }
    finally { setUploading(false); }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await base44.auth.updateMe({ display_name: name });
      onUpdated?.({ ...user, name });
    } catch (err) { /* ignore */ }
    finally { setSaving(false); }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col items-center gap-3">
        <button
          onClick={() => fileRef.current?.click()}
          className="relative w-24 h-24 rounded-full bg-primary/15 flex items-center justify-center overflow-hidden active:scale-95 transition-transform"
          aria-label="تغيير الصورة"
        >
          {avatarUrl ? (
            <img src={avatarUrl} alt="صورة المستخدم" className="w-full h-full object-cover" />
          ) : (
            <User size={40} className="text-primary" />
          )}
          <div className="absolute bottom-0 right-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center shadow-lg">
            {uploading ? <Loader2 size={14} className="animate-spin" /> : <Camera size={14} />}
          </div>
        </button>
        <input ref={fileRef} type="file" accept="image/*" onChange={handleAvatar} className="hidden" />
        <p className="text-xs text-muted-foreground">اضغط على الصورة لتغييرها (stored privately)</p>
      </div>

      <div>
        <label htmlFor="display-name" className="text-sm text-muted-foreground block mb-2">الاسم المعروض</label>
        <input
          id="display-name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          maxLength={50}
          className="w-full rounded-2xl border border-input bg-muted/50 px-4 py-3 text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
        />
      </div>

      <button
        onClick={handleSave}
        disabled={saving || name === (user?.name || '')}
        className="w-full rounded-2xl bg-primary text-primary-foreground py-3 font-bold flex items-center justify-center gap-2 disabled:opacity-50"
      >
        {saving ? <Loader2 size={17} className="animate-spin" /> : <Check size={17} />}
        {saving ? 'جارٍ الحفظ...' : 'حفظ'}
      </button>
    </div>
  );
}