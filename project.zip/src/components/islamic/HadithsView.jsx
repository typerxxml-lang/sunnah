import { useState, useMemo, useEffect } from 'react';
import { hadiths } from '@/data/hadiths';
import HadithCard from './HadithCard';

export default function HadithsView() {
  const [topic, setTopic] = useState('all');
  const [visibleCount, setVisibleCount] = useState(20);

  const topics = useMemo(() => {
    const set = new Set(hadiths.map(h => h.topic));
    return ['all', ...Array.from(set)];
  }, []);

  const filtered = topic === 'all'
    ? hadiths
    : hadiths.filter(h => h.topic === topic);

  useEffect(() => setVisibleCount(20), [topic]);

  const visible = filtered.slice(0, visibleCount);

  return (
    <div>
      <div className="mb-4">
        <h2 className="font-heading text-xl font-bold text-foreground mb-1">الأحاديث النبوية</h2>
        <p className="text-sm text-muted-foreground">{filtered.length} حديث شريف</p>
      </div>

      <div className="flex gap-2 overflow-x-auto pb-3 -mx-4 px-4 scrollbar-hide mb-2">
        {topics.map(t => (
          <button
            key={t}
            onClick={() => setTopic(t)}
            className={`shrink-0 px-4 py-2 rounded-full text-sm font-medium transition-all whitespace-nowrap ${
              topic === t
                ? 'bg-emerald-600 dark:bg-emerald-500 text-white'
                : 'glass-blur text-muted-foreground hover:text-foreground'
            }`}
          >
            {t === 'all' ? 'كل الأبواب' : t}
          </button>
        ))}
      </div>

      <div className="space-y-3">
        {visible.map(h => (
          <HadithCard key={h.id} hadith={h} />
        ))}
      </div>

      {filtered.length > visibleCount && (
        <button
          onClick={() => setVisibleCount(c => c + 20)}
          className="glass-blur w-full py-3 mt-3 text-sm font-medium text-emerald-600 dark:text-emerald-400 hover:scale-[1.01] transition-transform"
          style={{ borderRadius: 24 }}
        >
          عرض المزيد ({filtered.length - visibleCount} متبقٍ)
        </button>
      )}
    </div>
  );
}