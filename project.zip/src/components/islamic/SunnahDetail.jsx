import { Star, X, Share2 } from 'lucide-react';
import { useGlassEffect } from '@/hooks/useGlassEffect';
import { getClassificationColor, getAuthenticityColor, getEmphasisColor } from '@/lib/badges';
import { shareContent } from '@/lib/share';

export default function SunnahDetail({ sunnah, onClose, isFavorite, onToggleFavorite }) {
  const glassRef = useGlassEffect(34, 26, 48);

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/50"
      onClick={onClose}
    >
      <div
        ref={glassRef}
        onClick={(e) => e.stopPropagation()}
        className="glass max-w-2xl w-full max-h-[85vh] overflow-y-auto p-6 sm:p-8 rounded-b-none sm:rounded-[42px]"
      >
        <div className="flex items-start justify-between gap-4 mb-4">
          <h2 className="font-heading text-xl sm:text-2xl font-bold text-foreground leading-snug flex-1">
            {sunnah.title}
          </h2>
          <div className="flex gap-2 shrink-0">
            <button
              onClick={() => shareContent(sunnah.title, sunnah.text)}
              className="p-2 rounded-full hover:bg-foreground/10 transition-colors"
              aria-label="مشاركة"
            >
              <Share2 size={20} className="text-muted-foreground" />
            </button>
            <button
              onClick={onToggleFavorite}
              className="p-2 rounded-full hover:bg-foreground/10 transition-colors"
              aria-label="المفضلة"
            >
              <Star size={20} className={isFavorite ? 'fill-amber-400 text-amber-400' : 'text-muted-foreground'} />
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-full hover:bg-foreground/10 transition-colors"
              aria-label="إغلاق"
            >
              <X size={20} className="text-muted-foreground" />
            </button>
          </div>
        </div>

        <div className="relative">
          <p className="font-heading text-lg sm:text-xl text-foreground leading-loose">
            {sunnah.text}
          </p>
        </div>

        <div className="mt-5 space-y-4">
          <div className="flex flex-wrap gap-2">
            <span className={`badge ${getClassificationColor(sunnah.classification)}`}>
              التصنيف: {sunnah.classification}
            </span>
            <span className={`badge ${getAuthenticityColor(sunnah.authenticity)}`}>
              الصحة: {sunnah.authenticity}
            </span>
            <span className={`badge ${getEmphasisColor(sunnah.emphasis)}`}>
              التأكيد: {sunnah.emphasis}
            </span>
          </div>

          <div className="space-y-2 text-sm">
            <InfoRow label="الراوي" value={sunnah.narrator} />
            <InfoRow label="المصدر" value={sunnah.reference} />
          </div>
        </div>
      </div>
    </div>
  );
}

function InfoRow({ label, value }) {
  return (
    <div className="flex gap-2">
      <span className="text-muted-foreground shrink-0">{label}:</span>
      <span className="text-foreground font-medium">{value}</span>
    </div>
  );
}