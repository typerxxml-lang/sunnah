import { useState } from 'react';
import { Shield, KeyRound, FileText, Users, Archive, Megaphone } from 'lucide-react';
import BackupExport from '@/components/islamic/admin/BackupExport';
import { usePlus } from '@/hooks/usePlus';
import { useAdminCodes } from '@/hooks/useAdminCodes';
import ManagementModal from '@/components/islamic/ManagementModal';
import AccountRequired from '@/components/islamic/AccountRequired';
import AdminUnlock from '@/components/islamic/admin/AdminUnlock';
import PlusCodeForm from '@/components/islamic/admin/PlusCodeForm';
import PlusCodeList from '@/components/islamic/admin/PlusCodeList';
import ContentManager from '@/components/islamic/admin/ContentManager';
import UserManager from '@/components/islamic/admin/UserManager';
import GlobalAnnouncementManager from '@/components/islamic/admin/GlobalAnnouncementManager';

const TABS = [
  { id: 'codes', label: 'أكواد PLUS', icon: KeyRound },
  { id: 'content', label: 'المحتوى', icon: FileText },
  { id: 'users', label: 'المستخدمون', icon: Users },
  { id: 'backup', label: 'ملف التطبيق الاحتياطي', icon: Archive },
  { id: 'notice', label: 'تنبيه عام', icon: Megaphone },
];

export default function AdminPanel({ onClose, user }) {
  const { unlockAdmin, lockAdmin, adminUnlocked } = usePlus();
  const codes = useAdminCodes(!!user?.isReal && adminUnlocked);
  const [tab, setTab] = useState('codes');

  return (
    <ManagementModal title={adminUnlocked ? 'لوحة الإدارة' : 'دخول المشرف/المطور'} Icon={Shield} onClose={onClose}>
      {!user?.isReal ? <AccountRequired message="إدارة التطبيق تحتاج إلى تسجيل الدخول باسمك؛ وضع الضيف لا يكفي." />
        : !adminUnlocked ? <AdminUnlock onUnlock={unlockAdmin} />
        : <div className="space-y-4">
          <div className="grid grid-cols-2 gap-2">
            {TABS.map(({ id, label, icon: Icon }) => (
              <button key={id} onClick={() => setTab(id)} aria-pressed={tab === id}
                className={`flex flex-col items-center gap-1.5 py-2.5 text-xs transition-all ${tab === id ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'}`} style={{ borderRadius: 14 }}>
                <Icon size={18} />{label}
              </button>
            ))}
          </div>

          {tab === 'codes' && (
            <>
              {codes.error && <p role="alert" className="rounded-2xl bg-destructive/10 p-3 text-sm text-destructive">{codes.error}</p>}
              <PlusCodeForm onCreate={codes.create} busy={codes.loading || !!codes.pending} />
              <PlusCodeList page={codes.page} loading={codes.loading} pending={codes.pending} onRefresh={() => codes.refresh()} onLoadMore={() => codes.refresh(codes.page.next_cursor)} onRemove={codes.remove} />
            </>
          )}
          {tab === 'content' && <ContentManager />}
          {tab === 'users' && <UserManager />}
          {tab === 'backup' && <BackupExport />}
          {tab === 'notice' && <GlobalAnnouncementManager />}

          <button type="button" onClick={() => { lockAdmin(); onClose(); }} className="w-full rounded-2xl bg-muted py-3 text-sm text-muted-foreground">قفل لوحة الإدارة</button>
        </div>}
    </ManagementModal>
  );
}