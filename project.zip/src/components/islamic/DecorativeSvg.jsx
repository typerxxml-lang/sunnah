// Custom Islamic SVG icons — no emojis, all hand-drawn paths

export function AppLogo({ className = '', size = 24 }) {
  return (
    <svg viewBox="0 0 100 100" width={size} height={size} className={className} fill="none" aria-hidden="true">
      <defs>
        <linearGradient id="app-logo-bg" x1="10" y1="8" x2="90" y2="94" gradientUnits="userSpaceOnUse">
          <stop stopColor="#0F766E" /><stop offset="1" stopColor="#064E3B" />
        </linearGradient>
        <linearGradient id="app-logo-page" x1="27" y1="43" x2="75" y2="77" gradientUnits="userSpaceOnUse">
          <stop stopColor="#FFFFFF" /><stop offset="1" stopColor="#D1FAE5" />
        </linearGradient>
      </defs>
      <rect x="3" y="3" width="94" height="94" rx="29" fill="url(#app-logo-bg)" />
      <rect x="8" y="8" width="84" height="84" rx="25" stroke="#D1FAE5" strokeOpacity=".28" strokeWidth="1.5" />
      <circle cx="50" cy="40" r="20" fill="#FDE68A" fillOpacity=".16" />
      <path d="M60.8 23.6A16.7 16.7 0 1 0 76.2 48.2 18.8 18.8 0 1 1 60.8 23.6Z" fill="#FDE68A" />
      <path d="M50 17.5 53.1 25.2 61.2 25.6 54.9 30.9 56.9 38.7 50 34.2 43.1 38.7 45.1 30.9 38.8 25.6 46.9 25.2Z" fill="#FEF3C7" />
      <path d="M50 48.5C41.2 42.7 31.2 43.4 23 47.3V73.6C32.3 69.6 41.8 70.8 50 77.1C58.2 70.8 67.7 69.6 77 73.6V47.3C68.8 43.4 58.8 42.7 50 48.5Z" fill="url(#app-logo-page)" />
      <path d="M50 49V76.2" stroke="#047857" strokeWidth="2.1" strokeLinecap="round" />
      <path d="M29 53.5C35.2 51.5 41.1 52.4 45.8 55.1M29 60C35.2 58 41.1 58.9 45.8 61.6M71 53.5C64.8 51.5 58.9 52.4 54.2 55.1M71 60C64.8 58 58.9 58.9 54.2 61.6" stroke="#059669" strokeWidth="1.8" strokeLinecap="round" />
      <path d="M20.5 78.5C29.6 74.9 40.8 76.8 50 83C59.2 76.8 70.4 74.9 79.5 78.5" stroke="#A7F3D0" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}

export function IslamicStar({ className = '', size = 24 }) {
  return (
    <svg viewBox="0 0 100 100" width={size} height={size} className={className} fill="none" aria-hidden="true">
      <rect x="22" y="22" width="56" height="56" rx="6" stroke="currentColor" strokeWidth="3" />
      <rect x="22" y="22" width="56" height="56" rx="6" stroke="currentColor" strokeWidth="3" transform="rotate(45 50 50)" />
      <circle cx="50" cy="50" r="8" fill="currentColor" />
    </svg>
  );
}

export function MosqueIcon({ className = '', size = 24 }) {
  return (
    <svg viewBox="0 0 100 100" width={size} height={size} className={className} fill="none" aria-hidden="true">
      <path d="M50 12 C44 20, 44 28, 50 34 C56 28, 56 20, 50 12 Z" fill="currentColor" opacity="0.8" />
      <path d="M50 34 C50 34, 35 38, 30 50 L70 50 C65 38, 50 34, 50 34" stroke="currentColor" strokeWidth="3" fill="none" />
      <rect x="28" y="50" width="44" height="34" rx="4" stroke="currentColor" strokeWidth="3" fill="none" />
      <path d="M44 84 L44 66 C44 60, 56 60, 56 66 L56 84" stroke="currentColor" strokeWidth="3" fill="none" />
      <rect x="14" y="40" width="8" height="44" rx="2" stroke="currentColor" strokeWidth="2.5" fill="none" />
      <rect x="78" y="40" width="8" height="44" rx="2" stroke="currentColor" strokeWidth="2.5" fill="none" />
      <path d="M18 40 L18 34 M18 34 C16 34, 15 32, 15 30 C15 28, 18 26, 18 26 C18 26, 21 28, 21 30 C21 32, 20 34, 18 34" fill="currentColor" opacity="0.6" />
      <path d="M82 40 L82 34 M82 34 C80 34, 79 32, 79 30 C79 28, 82 26, 82 26 C82 26, 85 28, 85 30 C85 32, 84 34, 82 34" fill="currentColor" opacity="0.6" />
    </svg>
  );
}

export function CrescentIcon({ className = '', size = 24 }) {
  return (
    <svg viewBox="0 0 100 100" width={size} height={size} className={className} fill="none" aria-hidden="true">
      <path d="M68 50 A30 30 0 1 1 38 20 A22 22 0 1 0 68 50 Z" fill="currentColor" />
    </svg>
  );
}

export function BookIcon({ className = '', size = 24 }) {
  return (
    <svg viewBox="0 0 100 100" width={size} height={size} className={className} fill="none" aria-hidden="true">
      <path d="M50 25 C42 20, 28 20, 18 24 L18 78 C28 74, 42 74, 50 79" stroke="currentColor" strokeWidth="3" fill="none" />
      <path d="M50 25 C58 20, 72 20, 82 24 L82 78 C72 74, 58 74, 50 79" stroke="currentColor" strokeWidth="3" fill="none" />
      <line x1="50" y1="25" x2="50" y2="79" stroke="currentColor" strokeWidth="2" />
      <line x1="26" y1="36" x2="42" y2="34" stroke="currentColor" strokeWidth="1.5" opacity="0.5" />
      <line x1="26" y1="44" x2="42" y2="42" stroke="currentColor" strokeWidth="1.5" opacity="0.5" />
      <line x1="26" y1="52" x2="42" y2="50" stroke="currentColor" strokeWidth="1.5" opacity="0.5" />
      <line x1="58" y1="34" x2="74" y2="36" stroke="currentColor" strokeWidth="1.5" opacity="0.5" />
      <line x1="58" y1="42" x2="74" y2="44" stroke="currentColor" strokeWidth="1.5" opacity="0.5" />
      <line x1="58" y1="50" x2="74" y2="52" stroke="currentColor" strokeWidth="1.5" opacity="0.5" />
    </svg>
  );
}

export function BeadsIcon({ className = '', size = 24 }) {
  return (
    <svg viewBox="0 0 100 100" width={size} height={size} className={className} fill="none" aria-hidden="true">
      <circle cx="50" cy="50" r="32" stroke="currentColor" strokeWidth="2" opacity="0.3" />
      <circle cx="50" cy="18" r="4" fill="currentColor" />
      <circle cx="78" cy="38" r="4" fill="currentColor" />
      <circle cx="72" cy="72" r="4" fill="currentColor" />
      <circle cx="38" cy="80" r="4" fill="currentColor" />
      <circle cx="18" cy="60" r="4" fill="currentColor" />
      <circle cx="22" cy="30" r="4" fill="currentColor" />
      <circle cx="50" cy="50" r="6" fill="currentColor" opacity="0.7" />
      <path d="M50 14 L50 10" stroke="currentColor" strokeWidth="2" />
      <path d="M44 10 L56 10" stroke="currentColor" strokeWidth="2" />
    </svg>
  );
}

export function LightIcon({ className = '', size = 24 }) {
  return (
    <svg viewBox="0 0 100 100" width={size} height={size} className={className} fill="none" aria-hidden="true">
      <circle cx="50" cy="50" r="16" fill="currentColor" opacity="0.15" />
      <circle cx="50" cy="50" r="10" fill="currentColor" />
      <line x1="50" y1="10" x2="50" y2="24" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
      <line x1="50" y1="76" x2="50" y2="90" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
      <line x1="10" y1="50" x2="24" y2="50" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
      <line x1="76" y1="50" x2="90" y2="50" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
      <line x1="22" y1="22" x2="32" y2="32" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
      <line x1="68" y1="68" x2="78" y2="78" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
      <line x1="78" y1="22" x2="68" y2="32" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
      <line x1="32" y1="68" x2="22" y2="78" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
    </svg>
  );
}

export function ArchIcon({ className = '', size = 24 }) {
  return (
    <svg viewBox="0 0 100 100" width={size} height={size} className={className} fill="none" aria-hidden="true">
      <path d="M20 88 L20 48 C20 30, 35 18, 50 18 C65 18, 80 30, 80 48 L80 88" stroke="currentColor" strokeWidth="3" fill="none" />
      <path d="M30 88 L30 50 C30 38, 40 28, 50 28 C60 28, 70 38, 70 50 L70 88" stroke="currentColor" strokeWidth="2" fill="none" opacity="0.4" />
    </svg>
  );
}