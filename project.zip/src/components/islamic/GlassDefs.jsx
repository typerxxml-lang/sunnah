export default function GlassDefs() {
  return (
    <svg
      id="glass-defs"
      width="0"
      height="0"
      style={{ position: 'absolute' }}
      aria-hidden="true"
    />
  );
}