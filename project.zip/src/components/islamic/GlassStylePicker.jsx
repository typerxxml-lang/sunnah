import { Droplets, Layers, Wind } from 'lucide-react';
import { t } from '@/lib/i18n';

const STYLES = [
  { id: 'liquid', icon: Droplets },
  { id: 'material', icon: Layers },
  { id: 'blur', icon: Wind },
];

export default function GlassStylePicker({ glassStyle, onChange, lang = 'ar' }) {
  return (
    <div className="grid grid-cols-3 gap-2">
      {STYLES.map(({ id, icon: Icon }) => (
        <button
          key={id}
          onClick={() => onChange(id)}
          aria-pressed={glassStyle === id}
          className={`p-3 flex flex-col items-center gap-2 transition-all active:scale-95 ${glassStyle === id ? 'bg-primary/20 text-foreground border-2 border-primary' : 'bg-foreground/5 text-muted-foreground border-2 border-transparent'}`}
          style={{ borderRadius: 18 }}
        >
          <Icon size={20} />
          <span className="text-[11px]">{t(lang, 'glass', id)}</span>
        </button>
      ))}
    </div>
  );
}