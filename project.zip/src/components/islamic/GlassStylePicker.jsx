import { Droplets, Layers, Wind } from 'lucide-react';
import { t } from '@/lib/i18n';

const STYLES = [
  { id: 'liquid', icon: Droplets, plusOnly: true },
  { id: 'material', icon: Layers },
  { id: 'blur', icon: Wind },
];

/** الزجاج السائل لـ PLUS فقط؛ Material You والضبابي متاحان للجميع */
export default function GlassStylePicker({ glassStyle, onChange, lang = 'ar', isPlusActive = true, onOpenPlus, disabled = false }) {
  return (
    <div className={`grid grid-cols-3 gap-2 ${disabled ? 'opacity-50 pointer-events-none' : ''}`}>
      {STYLES.map(({ id, icon: Icon, plusOnly }) => {
        const locked = plusOnly && !isPlusActive;
        return (
          <button
            key={id}
            onClick={() => (locked ? onOpenPlus?.() : onChange(id))}
            aria-pressed={glassStyle === id}
            disabled={disabled}
            className={`relative p-3 flex flex-col items-center gap-2 transition-all active:scale-95 ${glassStyle === id ? 'bg-primary/20 text-foreground border-2 border-primary' : 'bg-foreground/5 text-muted-foreground border-2 border-transparent'}`}
            style={{ borderRadius: 18 }}
          >
            <Icon size={20} />
            <span className="text-[11px]">{t(lang, 'glass', id)}</span>
            {locked && <span className="absolute top-1 left-1 text-[9px] bg-amber-500/20 text-amber-600 dark:text-amber-400 px-1.5 py-0.5 rounded-full">PLUS</span>}
          </button>
        );
      })}
    </div>
  );
}
