import { useState } from 'react';
import { CalendarDays } from 'lucide-react';
import GlassWidget from './GlassWidget';
import { hijri, hijriMonth, gregLabel } from '@/lib/hijri';
import { toArabicDigits } from '@/lib/time';

const MONTHS = ['يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'];

export default function DateConverterWidget() {
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const d = new Date(date);
  const h = hijri(d);
  const hLabel = `${toArabicDigits(h.day)} ${hijriMonth(d)} ${toArabicDigits(h.year)} هـ`;
  const gLabel = `${toArabicDigits(d.getDate())} ${MONTHS[d.getMonth()]} ${toArabicDigits(d.getFullYear())} م`;

  return (
    <GlassWidget title="تحويل التاريخ" Icon={CalendarDays} accent="text-indigo-500" full>
      <input
        type="date" value={date} onChange={(e) => setDate(e.target.value)}
        className="w-full rounded-2xl bg-foreground/5 px-3 py-2 text-sm text-foreground outline-none focus:bg-foreground/10 transition-colors"
      />
      <div className="mt-3 grid grid-cols-2 gap-2 text-center">
        <div className="rounded-2xl bg-indigo-500/10 px-2 py-2">
          <p className="text-[10px] text-muted-foreground">الهجري</p>
          <p className="font-heading text-sm font-bold text-indigo-600 dark:text-indigo-400 leading-snug">{hLabel}</p>
        </div>
        <div className="rounded-2xl bg-foreground/5 px-2 py-2">
          <p className="text-[10px] text-muted-foreground">الميلادي</p>
          <p className="font-heading text-sm font-bold text-foreground leading-snug">{gLabel}</p>
        </div>
      </div>
    </GlassWidget>
  );
}