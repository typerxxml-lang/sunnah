import { useEffect, useState } from 'react';
import { Flame } from 'lucide-react';
import GlassWidget from './GlassWidget';
import { loadJSON, saveJSON } from '@/lib/storage';
import { toArabicDigits } from '@/lib/time';

const DAY = 86400000;
const dayNum = (d = new Date()) => Math.floor((d.getTime() - d.getTimezoneOffset() * 60000) / DAY);

export default function StreakWidget() {
  const [streak, setStreak] = useState(1);

  useEffect(() => {
    const data = loadJSON('iq-streak', { last: null, count: 0 });
    const today = dayNum();
    let next = data;
    if (data.last === today) next = data;
    else if (data.last === today - 1) next = { last: today, count: data.count + 1 };
    else next = { last: today, count: 1 };
    saveJSON('iq-streak', next);
    setStreak(next.count);
  }, []);

  return (
    <GlassWidget title="أيام المواظبة" Icon={Flame} accent="text-orange-500">
      <p className="font-heading text-4xl font-bold text-center text-orange-500 anim-pulse">{toArabicDigits(streak)}</p>
      <p className="text-[11px] text-muted-foreground text-center mt-1">
        {streak > 1 ? 'يوماً متتالياً، واصل' : 'ابدأ رحلتك اليوم'}
      </p>
    </GlassWidget>
  );
}