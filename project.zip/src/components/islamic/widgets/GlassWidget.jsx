import { useGlassEffect } from '@/hooks/useGlassEffect';

/** حاوية ودجت Liquid Glass موحّدة (Squircle عالٍ، بلا إطار) */
export default function GlassWidget({ title, Icon, accent = 'text-primary', children, className = '', onClick, full = false }) {
  const ref = useGlassEffect(44, 26, 50);
  return (
    <div
      ref={ref}
      onClick={onClick}
      className={`glass p-4 anim-pop ${full ? 'col-span-2' : ''} ${onClick ? 'cursor-pointer active:scale-[0.98] transition-transform' : ''} ${className}`}
    >
      {title && (
        <div className="flex items-center gap-1.5 mb-2">
          {Icon && <Icon size={16} className={accent} />}
          <h4 className="font-heading text-xs font-bold text-muted-foreground">{title}</h4>
        </div>
      )}
      {children}
    </div>
  );
}