import { useState } from 'react';
import { CircleHelp, Check, X } from 'lucide-react';
import GlassWidget from './GlassWidget';
import { quiz } from '@/data/quiz';
import { loadJSON, saveJSON } from '@/lib/storage';
import { dayOfYear, todayKey, toArabicDigits } from '@/lib/time';

export default function QuizWidget() {
  const n = dayOfYear();
  const item = quiz[n % quiz.length];
  const options = [...item.w];
  options.splice(n % 3, 0, item.a);

  const key = 'iq-quiz-' + todayKey();
  const [picked, setPicked] = useState(() => loadJSON(key, null));
  const [score, setScore] = useState(() => loadJSON('iq-quiz-score', 0));

  const pick = (opt) => {
    if (picked) return;
    setPicked(opt);
    saveJSON(key, opt);
    const right = opt === item.a;
    if (right) { setScore(score + 1); saveJSON('iq-quiz-score', score + 1); }
    if (navigator.vibrate) navigator.vibrate(right ? 15 : [10, 40, 10]);
  };

  return (
    <GlassWidget title="سؤال اليوم" Icon={CircleHelp} accent="text-indigo-500" full>
      <p className="font-heading text-sm font-bold text-foreground leading-relaxed">{item.q}</p>
      <div className="grid gap-2 mt-3">
        {options.map((opt) => {
          const right = picked && opt === item.a;
          const wrong = picked === opt && opt !== item.a;
          return (
            <button
              key={opt}
              onClick={() => pick(opt)}
              disabled={!!picked}
              className={`flex items-center justify-between rounded-2xl px-3 py-2 text-sm text-right transition-colors active:scale-[0.98] ${right ? 'bg-emerald-500/20 text-emerald-700 dark:text-emerald-300' : wrong ? 'bg-rose-500/20 text-rose-600 dark:text-rose-300' : 'bg-foreground/5 text-foreground'}`}
            >
              <span>{opt}</span>
              {right && <Check size={16} />}
              {wrong && <X size={16} />}
            </button>
          );
        })}
      </div>
      <p className="text-[10px] text-muted-foreground mt-2">إجاباتك الصحيحة: {toArabicDigits(score)} • سؤال جديد كل يوم</p>
    </GlassWidget>
  );
}