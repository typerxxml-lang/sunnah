import { useState } from 'react';
import { Target } from 'lucide-react';
import GlassWidget from './GlassWidget';
import { loadString, saveString } from '@/lib/storage';
import { todayKey } from '@/lib/time';

const SUGGEST = ['برّ الوالدين', 'قراءة جزء من القرآن', 'صدقة ولو قليلة', 'صلة الرحم', 'كفّ الأذى عن الناس'];

export default function IntentionWidget() {
  const key = 'iq-intention-' + todayKey();
  const [text, setText] = useState(() => loadString(key, ''));
  const save = (v) => { setText(v); saveString(key, v); };

  return (
    <GlassWidget title="نيّة اليوم" Icon={Target} accent="text-emerald-600" full>
      <textarea
        rows={2}
        value={text}
        onChange={(e) => save(e.target.value)}
        placeholder="اكتب نيّتك الصالحة لهذا اليوم..."
        className="w-full resize-none rounded-2xl bg-foreground/5 px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:bg-foreground/10 transition-colors"
      />
      <div className="flex flex-wrap gap-1.5 mt-2">
        {SUGGEST.map((s) => (
          <button
            key={s}
            onClick={() => save(`أنوي ${s}`)}
            className="px-2.5 py-1 rounded-full bg-emerald-500/10 text-[10px] text-emerald-700 dark:text-emerald-300 active:scale-90 transition-transform"
          >
            {s}
          </button>
        ))}
      </div>
      <p className="text-[10px] text-muted-foreground mt-2">«إنما الأعمال بالنيات» — متفق عليه</p>
    </GlassWidget>
  );
}