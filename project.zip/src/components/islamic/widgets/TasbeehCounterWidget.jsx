import { useState } from 'react';
import { Fingerprint, RotateCcw } from 'lucide-react';
import GlassWidget from './GlassWidget';
import { loadJSON, saveJSON } from '@/lib/storage';
import { toArabicDigits } from '@/lib/time';

const ADHKAR = [
  { text: 'سبحان الله', target: 33 },
  { text: 'الحمد لله', target: 33 },
  { text: 'الله أكبر', target: 34 },
  { text: 'لا إله إلا الله', target: 100 },
  { text: 'أستغفر الله', target: 100 },
  { text: 'اللهم صلّ على محمد', target: 100 },
];

const key = () => `iq-tasbeeh-${new Date().toDateString()}`;

export default function TasbeehCounterWidget() {
  const [idx, setIdx] = useState(() => loadJSON('iq-tasbeeh-idx', 0));
  const [count, setCount] = useState(() => loadJSON(key(), 0));
  const dhikr = ADHKAR[idx % ADHKAR.length];

  const tap = () => {
    setCount((c) => {
      const n = c + 1;
      saveJSON(key(), n);
      if (navigator.vibrate) navigator.vibrate(n % dhikr.target === 0 ? 30 : 8);
      return n;
    });
  };
  const reset = () => { setCount(0); saveJSON(key(), 0); };
  const cycle = () => { const n = (idx + 1) % ADHKAR.length; setIdx(n); saveJSON('iq-tasbeeh-idx', n); setCount(0); saveJSON(key(), 0); };
  const done = count >= dhikr.target;

  return (
    <GlassWidget title="المسبحة الرقمية" Icon={Fingerprint} accent="text-emerald-600" full>
      <div className="flex items-center justify-between gap-3">
        <button onClick={cycle} className="flex-1 rounded-2xl bg-foreground/5 px-2 py-1.5 text-center active:scale-95 transition-transform">
          <p className="font-heading text-sm font-bold text-foreground">{dhikr.text}</p>
          <p className="text-[10px] text-muted-foreground">الهدف {toArabicDigits(dhikr.target)}</p>
        </button>
        <button onClick={reset} className="p-2 rounded-full hover:bg-foreground/10 active:scale-90 transition-all" aria-label="تصفير">
          <RotateCcw size={16} className="text-muted-foreground" />
        </button>
      </div>
      <button onClick={tap} className="w-full mt-3 select-none">
        <div className={`relative mx-auto rounded-full flex items-center justify-center transition-all active:scale-95 ${done ? 'bg-emerald-500/20' : 'bg-emerald-600/10'}`} style={{ width: 120, height: 120 }}>
          <div className={`absolute inset-0 rounded-full border-2 ${done ? 'border-emerald-500' : 'border-emerald-600/20'}`} />
          <div className="text-center">
            <p className={`font-heading text-4xl font-bold leading-none ${done ? 'text-emerald-600 dark:text-emerald-400' : 'text-foreground'}`}>{toArabicDigits(count)}</p>
            <p className="text-[10px] text-muted-foreground mt-1">{done ? 'أتممت الذكر' : 'اضغط للتسبيح'}</p>
          </div>
        </div>
      </button>
    </GlassWidget>
  );
}