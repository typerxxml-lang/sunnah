import { useState } from 'react';
import { HandHeart, RefreshCw, Share2 } from 'lucide-react';
import GlassWidget from './GlassWidget';
import { quranDuas } from '@/data/quranDuas';
import { dayOfYear } from '@/lib/time';
import { shareContent } from '@/lib/share';

export default function QuranicDuaWidget() {
  const [i, setI] = useState(() => dayOfYear() % quranDuas.length);
  const dua = quranDuas[i];

  return (
    <GlassWidget title="دعاء من القرآن" Icon={HandHeart} accent="text-sky-500" full>
      <p className="font-quran text-lg text-foreground leading-loose text-center">﴿{dua.text}﴾</p>
      <div className="flex items-center justify-between mt-2">
        <span className="text-[11px] text-muted-foreground">{dua.ref}</span>
        <div className="flex">
          <button onClick={() => shareContent('دعاء من القرآن', `${dua.text} (${dua.ref})`)} className="p-1.5 rounded-full hover:bg-foreground/10" aria-label="مشاركة">
            <Share2 size={15} className="text-muted-foreground" />
          </button>
          <button onClick={() => setI((i + 1) % quranDuas.length)} className="p-1.5 rounded-full hover:bg-foreground/10 active:rotate-180 transition-transform" aria-label="دعاء آخر">
            <RefreshCw size={15} className="text-muted-foreground" />
          </button>
        </div>
      </div>
    </GlassWidget>
  );
}