import { useState } from 'react';
import { ListChecks, Check } from 'lucide-react';
import GlassWidget from './GlassWidget';
import { dailyDeeds } from '@/data/deeds';
import { loadJSON, saveJSON } from '@/lib/storage';
import { todayKey, toArabicDigits } from '@/lib/time';

export default function DeedsWidget() {
  const key = 'iq-deeds-' + todayKey();
  const [done, setDone] = useState(() => loadJSON(key, []));

  const toggle = (i) => {
    const next = done.includes(i) ? done.filter((x) => x !== i) : [...done, i];
    setDone(next);
    saveJSON(key, next);
    window.dispatchEvent(new Event('iq-deeds'));
    if (navigator.vibrate) navigator.vibrate(8);
  };

  const pct = Math.round((done.length / dailyDeeds.length) * 100);

  return (
    <GlassWidget title="أعمال اليوم" Icon={ListChecks} full>
      <div className="flex items-center justify-between mb-1.5 text-[11px]">
        <span className="text-muted-foreground">{toArabicDigits(done.length)} من {toArabicDigits(dailyDeeds.length)}</span>
        <span className="font-bold text-emerald-600 dark:text-emerald-400">{toArabicDigits(pct)}٪</span>
      </div>
      <div className="h-1.5 rounded-full bg-foreground/10 overflow-hidden mb-3">
        <div className="h-full rounded-full bg-emerald-500 transition-all duration-500" style={{ width: pct + '%' }} />
      </div>
      <div className="grid grid-cols-2 gap-2">
        {dailyDeeds.map((d, i) => {
          const on = done.includes(i);
          return (
            <button
              key={d}
              onClick={() => toggle(i)}
              className={`flex items-center gap-1.5 rounded-2xl px-2.5 py-2 text-xs text-right transition-colors active:scale-95 ${on ? 'bg-emerald-500/20 text-emerald-700 dark:text-emerald-300' : 'bg-foreground/5 text-foreground'}`}
            >
              <span className={`w-4 h-4 shrink-0 rounded-full flex items-center justify-center ${on ? 'bg-emerald-500 text-white' : 'bg-foreground/10'}`}>
                {on && <Check size={11} />}
              </span>
              {d}
            </button>
          );
        })}
      </div>
    </GlassWidget>
  );
}