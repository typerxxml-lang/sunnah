import { useMemo } from 'react';
import { PartyPopper } from 'lucide-react';
import GlassWidget from './GlassWidget';
import { upcoming, inDays, gregLabel } from '@/lib/hijri';

const OCCASIONS = [
  { name: 'رأس السنة الهجرية', m: 1, d: 1 },
  { name: 'يوم عاشوراء', m: 1, d: 10 },
  { name: 'بداية شهر رمضان', m: 9, d: 1 },
  { name: 'العشر الأواخر من رمضان', m: 9, d: 21 },
  { name: 'عيد الفطر', m: 10, d: 1 },
  { name: 'العشر من ذي الحجة', m: 12, d: 1 },
  { name: 'يوم عرفة', m: 12, d: 9 },
  { name: 'عيد الأضحى', m: 12, d: 10 },
];

export default function OccasionsWidget() {
  const list = useMemo(() => upcoming(OCCASIONS).slice(0, 3), []);

  return (
    <GlassWidget title="المناسبات القادمة" Icon={PartyPopper} accent="text-amber-500" full>
      <div className="space-y-2">
        {list.map((o) => (
          <div key={o.name} className="flex items-center justify-between gap-2 rounded-2xl bg-foreground/5 px-3 py-2">
            <div className="min-w-0">
              <p className="font-heading text-sm font-bold text-foreground truncate">{o.name}</p>
              <p className="text-[10px] text-muted-foreground">{gregLabel(o.date, true)}</p>
            </div>
            <span className="shrink-0 text-xs font-bold text-amber-600 dark:text-amber-400">{inDays(o.days)}</span>
          </div>
        ))}
      </div>
    </GlassWidget>
  );
}