import { Compass } from 'lucide-react';
import GlassWidget from './GlassWidget';
import { useState, useEffect } from 'react';

export default function QiblaWidget() {
  const [angle, setAngle] = useState(null);

  useEffect(() => {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude, longitude } = pos.coords;
        // اتجاه القبلة من أي مكان: نحو مكة (21.4225° N, 39.8262° E)
        const kaabaLat = 21.4225;
        const kaabaLng = 39.8262;
        const φ1 = (latitude * Math.PI) / 180;
        const φ2 = (kaabaLat * Math.PI) / 180;
        const Δλ = ((kaabaLng - longitude) * Math.PI) / 180;
        const y = Math.sin(Δλ);
        const x = Math.cos(φ1) * Math.tan(φ2) - Math.sin(φ1) * Math.cos(Δλ);
        let θ = Math.atan2(y, x) * (180 / Math.PI);
        θ = (θ + 360) % 360;
        setAngle(Math.round(θ));
      },
      () => setAngle(null),
      { timeout: 5000 }
    );
  }, []);

  return (
    <GlassWidget title="اتجاه القبلة" Icon={Compass} accent="text-emerald-600 dark:text-emerald-400">
      <div className="flex flex-col items-center justify-center gap-1 min-h-[3.5rem]">
        {angle !== null ? (
          <>
            <Compass
              size={28}
              className="text-emerald-600 dark:text-emerald-400"
              style={{ transform: `rotate(${angle}deg)`, transition: 'transform 0.6s' }}
            />
            <p className="font-heading text-lg font-bold text-emerald-600 dark:text-emerald-400">
              {angle}°
            </p>
            <p className="text-[10px] text-muted-foreground">من الشمال</p>
          </>
        ) : (
          <p className="text-[10px] text-muted-foreground text-center">
            فعّل الموقع لمعرفة الاتجاه
          </p>
        )}
      </div>
    </GlassWidget>
  );
}