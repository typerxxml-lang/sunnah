import { useState } from 'react';
import { Droplets, ChevronRight, ChevronLeft } from 'lucide-react';
import GlassWidget from './GlassWidget';
import { toArabicDigits } from '@/lib/time';

const STEPS = [
  'النية في القلب، ثم التسمية: «بسم الله»',
  'غسل الكفين ثلاث مرات',
  'المضمضة والاستنشاق والاستنثار ثلاثاً',
  'غسل الوجه ثلاث مرات',
  'غسل اليدين إلى المرفقين ثلاثاً، اليمنى ثم اليسرى',
  'مسح الرأس مرة واحدة من مقدمه إلى قفاه ثم إرجاعهما، ومسح الأذنين',
  'غسل الرجلين إلى الكعبين ثلاثاً، اليمنى ثم اليسرى',
  'الدعاء بعده: «أشهد أن لا إله إلا الله وحده لا شريك له، وأشهد أن محمداً عبده ورسوله»',
];

export default function WuduGuideWidget() {
  const [step, setStep] = useState(0);
  const btn = 'p-2 rounded-full bg-foreground/5 hover:bg-foreground/10 active:scale-90 transition-all disabled:opacity-30';

  return (
    <GlassWidget title="صفة الوضوء" Icon={Droplets} accent="text-sky-500" full>
      <div className="flex items-center gap-3">
        <button onClick={() => setStep(step - 1)} disabled={step === 0} className={btn} aria-label="السابق">
          <ChevronRight size={16} className="text-foreground" />
        </button>
        <div className="flex-1 text-center min-h-[56px] flex flex-col justify-center">
          <p className="text-[10px] text-sky-600 dark:text-sky-400 font-bold">الخطوة {toArabicDigits(step + 1)} من {toArabicDigits(STEPS.length)}</p>
          <p className="font-heading text-sm text-foreground leading-relaxed mt-0.5">{STEPS[step]}</p>
        </div>
        <button onClick={() => setStep(step + 1)} disabled={step === STEPS.length - 1} className={btn} aria-label="التالي">
          <ChevronLeft size={16} className="text-foreground" />
        </button>
      </div>
      <div className="flex justify-center gap-1 mt-3">
        {STEPS.map((_, i) => (
          <span key={i} className={`h-1.5 rounded-full transition-all ${i === step ? 'w-4 bg-sky-500' : 'w-1.5 bg-foreground/15'}`} />
        ))}
      </div>
    </GlassWidget>
  );
}