import { HandHelping } from 'lucide-react';
import GlassWidget from './GlassWidget';
import { dailyDuas } from '@/data/tips';
import { dayOfYear } from '@/lib/time';

export default function DuaWidget() {
  const dua = dailyDuas[dayOfYear() % dailyDuas.length];

  return (
    <GlassWidget title="دعاء اليوم" Icon={HandHelping} accent="text-sky-500" full>
      <p className="font-quran text-base text-foreground leading-loose min-h-[3.5rem]">
        {dua.text}
      </p>
      {dua.virtue && (
        <p className="text-[10px] text-sky-600 dark:text-sky-400 mt-2">
          ✦ {dua.virtue}
        </p>
      )}
    </GlassWidget>
  );
}