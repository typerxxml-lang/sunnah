import { Sparkles } from 'lucide-react';
import GlassWidget from './GlassWidget';
import { dayOfYear, toArabicDigits } from '@/lib/time';

const FRIDAY_SUNAN = [
  'قراءة سورة الكهف',
  'الإكثار من الصلاة على النبي ﷺ',
  'الاغتسال والتطيب ولبس أحسن الثياب',
  'التبكير إلى صلاة الجمعة',
  'تحري ساعة الإجابة آخر ساعة بعد العصر',
];

const leftLabel = (n) => (n === 1 ? 'غداً يوم الجمعة' : n === 2 ? 'يومان على الجمعة' : 'أيام على الجمعة');

export default function FridayWidget() {
  const left = (5 - new Date().getDay() + 7) % 7;

  return (
    <GlassWidget title="يوم الجمعة" Icon={Sparkles} accent="text-amber-500">
      {left === 0 ? (
        <>
          <p className="font-heading text-base font-bold text-amber-600 dark:text-amber-400">جمعة مباركة</p>
          <ul className="mt-1 space-y-0.5">
            {FRIDAY_SUNAN.slice(0, 3).map((s) => (
              <li key={s} className="text-[10px] text-foreground/80 leading-snug">• {s}</li>
            ))}
          </ul>
        </>
      ) : (
        <>
          <p className="font-heading text-3xl font-bold text-amber-500 leading-none">{toArabicDigits(left)}</p>
          <p className="text-[11px] text-muted-foreground mt-1">{leftLabel(left)}</p>
          <p className="text-[10px] text-foreground/80 mt-1.5 leading-snug">{FRIDAY_SUNAN[dayOfYear() % FRIDAY_SUNAN.length]}</p>
        </>
      )}
    </GlassWidget>
  );
}