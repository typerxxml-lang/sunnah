import { MoonStar } from 'lucide-react';
import GlassWidget from './GlassWidget';
import { hijri, fastReason, addDays, inDays, gregLabel } from '@/lib/hijri';

function nextFast(from) {
  for (let i = 1; i <= 30; i++) {
    const d = addDays(from, i);
    const reason = fastReason(hijri(d), d);
    if (reason) return { d, i, reason };
  }
  return null;
}

export default function FastingWidget() {
  const now = new Date();
  const today = fastReason(hijri(now), now);
  const next = nextFast(now);

  return (
    <GlassWidget title="الصيام القادم" Icon={MoonStar} accent="text-indigo-500">
      {today && <p className="text-[10px] font-bold text-indigo-500 mb-1">اليوم: {today}</p>}
      {next ? (
        <>
          <p className="font-heading text-sm font-bold text-foreground leading-snug">{next.reason}</p>
          <p className="text-[11px] text-muted-foreground mt-1">{inDays(next.i)} • {gregLabel(next.d, true)}</p>
        </>
      ) : (
        <p className="text-[11px] text-muted-foreground">لا يوجد صيام قريب</p>
      )}
    </GlassWidget>
  );
}