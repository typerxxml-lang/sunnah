import { useState } from 'react';
import { Heart } from 'lucide-react';
import GlassWidget from './GlassWidget';
import { loadJSON, saveJSON } from '@/lib/storage';
import { todayKey, toArabicDigits } from '@/lib/time';
import { salawat } from '@/data/motivation';

export default function SalawatWidget() {
  const key = 'iq-salawat-' + todayKey();
  const [count, setCount] = useState(() => loadJSON(key, 0));
  const [pulse, setPulse] = useState(false);

  const tap = () => {
    const n = count + 1;
    setCount(n);
    saveJSON(key, n);
    setPulse(true);
    setTimeout(() => setPulse(false), 220);
    if (navigator.vibrate) navigator.vibrate(8);
  };

  return (
    <GlassWidget title="صلِّ على النبي ﷺ" Icon={Heart} accent="text-rose-500" onClick={tap}>
      <p className="font-quran text-sm text-foreground/90 leading-relaxed min-h-[3rem]">
        {salawat[count % salawat.length]}
      </p>
      <div className="flex items-end justify-between mt-2">
        <span className={`font-heading text-3xl font-bold text-rose-500 transition-transform ${pulse ? 'scale-125' : 'scale-100'}`}>
          {toArabicDigits(count)}
        </span>
        <span className="text-[10px] text-muted-foreground">اضغط للعد اليوم</span>
      </div>
    </GlassWidget>
  );
}