import TipWidget from '@/components/islamic/widgets/TipWidget';
import DuaWidget from '@/components/islamic/widgets/DuaWidget';
import HijriDateWidget from '@/components/islamic/widgets/HijriDateWidget';
import FastingWidget from '@/components/islamic/widgets/FastingWidget';
import PrayerTrackerWidget from '@/components/islamic/widgets/PrayerTrackerWidget';
import RawatibWidget from '@/components/islamic/widgets/RawatibWidget';
import IntentionWidget from '@/components/islamic/widgets/IntentionWidget';
import QuranPlayerWidget from '@/components/islamic/widgets/QuranPlayerWidget';
import KhatmaWidget from '@/components/islamic/widgets/KhatmaWidget';
import SalawatWidget from '@/components/islamic/widgets/SalawatWidget';
import StreakWidget from '@/components/islamic/widgets/StreakWidget';
import DeedsWidget from '@/components/islamic/widgets/DeedsWidget';
import WeeklyProgressWidget from '@/components/islamic/widgets/WeeklyProgressWidget';
import QiblaWidget from '@/components/islamic/widgets/QiblaWidget';
import NameOfAllahWidget from '@/components/islamic/widgets/NameOfAllahWidget';
import FridayWidget from '@/components/islamic/widgets/FridayWidget';
import NightThirdWidget from '@/components/islamic/widgets/NightThirdWidget';
import OccasionsWidget from '@/components/islamic/widgets/OccasionsWidget';
import ZakatWidget from '@/components/islamic/widgets/ZakatWidget';
import TasbeehCounterWidget from '@/components/islamic/widgets/TasbeehCounterWidget';
import DateConverterWidget from '@/components/islamic/widgets/DateConverterWidget';
import SahabaStoryWidget from '@/components/islamic/widgets/SahabaStoryWidget';
import QuranicDuaWidget from '@/components/islamic/widgets/QuranicDuaWidget';
import SadaqahWidget from '@/components/islamic/widgets/SadaqahWidget';
import WuduGuideWidget from '@/components/islamic/widgets/WuduGuideWidget';
import HijriAgeWidget from '@/components/islamic/widgets/HijriAgeWidget';
import DailyAyahWidget from '@/components/islamic/widgets/DailyAyahWidget';
import DailyHadithWidget from '@/components/islamic/widgets/DailyHadithWidget';
import QuizWidget from '@/components/islamic/widgets/QuizWidget';
import MotivationWidget from '@/components/islamic/widgets/MotivationWidget';

const widget = (id, title, Component, full = false, props = () => ({})) => ({ id, title, Component, full, props });
export const WIDGETS = [
  widget('tip', 'نصيحة اليوم', TipWidget, true),
  widget('dua', 'دعاء اليوم', DuaWidget, true),
  widget('hijri-date', 'التاريخ الهجري', HijriDateWidget),
  widget('fasting', 'الصيام القادم', FastingWidget),
  widget('prayer-tracker', 'متتبّع الصلوات', PrayerTrackerWidget, true),
  widget('rawatib', 'السنن الرواتب', RawatibWidget, true),
  widget('intention', 'نيّة اليوم', IntentionWidget, true),
  widget('quran-player', 'استمع للقرآن الكريم', QuranPlayerWidget, true),
  widget('khatma', 'وردي اليوم', KhatmaWidget, true, ({ settings }) => ({ goal: settings.dailyGoalPages })),
  widget('salawat', 'الصلاة على النبي ﷺ', SalawatWidget),
  widget('streak', 'أيام المواظبة', StreakWidget),
  widget('deeds', 'أعمال اليوم', DeedsWidget, true),
  widget('weekly-progress', 'إنجازك هذا الأسبوع', WeeklyProgressWidget, true),
  widget('qibla', 'اتجاه القبلة', QiblaWidget),
  widget('name-of-allah', 'اسم الله اليوم', NameOfAllahWidget),
  widget('friday', 'يوم الجمعة', FridayWidget),
  widget('night-third', 'الثلث الأخير', NightThirdWidget, false, ({ settings }) => ({ timeFormat: settings.timeFormat })),
  widget('occasions', 'المناسبات القادمة', OccasionsWidget, true),
  widget('zakat', 'حاسبة الزكاة', ZakatWidget, true),
  widget('tasbeeh', 'المسبحة الرقمية', TasbeehCounterWidget, true),
  widget('date-converter', 'تحويل التاريخ', DateConverterWidget, true),
  widget('sahaba-story', 'قصة صحابي اليوم', SahabaStoryWidget, true),
  widget('quranic-dua', 'دعاء من القرآن', QuranicDuaWidget, true),
  widget('sadaqah', 'متتبّع الصدقة', SadaqahWidget, true),
  widget('wudu-guide', 'صفة الوضوء', WuduGuideWidget, true),
  widget('hijri-age', 'عمرك بالهجري', HijriAgeWidget, true),
  widget('daily-ayah', 'آية اليوم', DailyAyahWidget, true, ({ onNavigate }) => ({ onOpen: () => onNavigate('quran') })),
  widget('daily-hadith', 'حديث اليوم', DailyHadithWidget, true, ({ onNavigate }) => ({ onOpen: () => onNavigate('hadiths') })),
  widget('quiz', 'سؤال اليوم', QuizWidget, true),
  widget('motivation', 'تحفيز اليوم', MotivationWidget, true),
];