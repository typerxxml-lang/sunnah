import { useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Check, GripVertical } from 'lucide-react';
import { WIDGETS } from '@/components/islamic/widgets/widgetRegistry';
import WidgetTile from '@/components/islamic/widgets/WidgetTile';
import { useWidgetLayout } from '@/hooks/useWidgetLayout';
import { useWidgetDrag } from '@/hooks/useWidgetDrag';

const IDS = WIDGETS.map(item => item.id);
export default function WidgetGrid({ settings, onNavigate, hiddenWidgets = [] }) {
  const [editing, setEditing] = useState(false);
  const gridRef = useRef(null);
  const { order, move } = useWidgetLayout(IDS);
  const { drag, handlers, cancel } = useWidgetDrag(gridRef, move);
  const title = id => WIDGETS.find(item => item.id === id)?.title;
  const keyboardMove = (e, id) => {
    if (e.key === 'Escape') { cancel(); return; }
    const direction = { ArrowUp: -1, ArrowRight: -1, ArrowDown: 1, ArrowLeft: 1 }[e.key];
    if (!direction) return;
    e.preventDefault();
    const target = order[order.indexOf(id) + direction];
    if (target) move(id, target);
  };
  return (
    <section className="space-y-3" aria-label="ودجات الصفحة الرئيسية">
      <div className="flex items-center justify-between gap-2">
        <p className="text-xs text-muted-foreground">{editing ? 'اسحب من المقبض؛ يُحفظ الترتيب تلقائياً' : 'الودجات'}</p>
        <button type="button" onClick={() => { cancel(); setEditing(!editing); }} className="rounded-xl bg-primary/10 text-primary px-3 py-2 text-sm flex items-center gap-1.5">
          {editing ? <Check size={16} /> : <GripVertical size={16} />}{editing ? 'تم' : 'ترتيب الودجات'}
        </button>
      </div>
      <div ref={gridRef} className="grid grid-cols-2 gap-3">
        {order.filter(id => !hiddenWidgets.includes(id)).map(id => {
          const item = WIDGETS.find(widget => widget.id === id), Component = item.Component;
          return <WidgetTile key={id} item={item} editing={editing} dragging={drag?.id === id} target={drag?.target === id && drag?.id !== id}
            handlers={handlers(id)} onKeyDown={e => keyboardMove(e, id)}><Component {...item.props({ settings, onNavigate })} /></WidgetTile>;
        })}
      </div>
      <p className="sr-only" aria-live="polite">{drag ? `نقل ${title(drag.id)} إلى موضع ${title(drag.target)}` : 'ترتيب الودجات محفوظ'}</p>
      {drag && createPortal(<div className="fixed z-[60] pointer-events-none rounded-2xl bg-card text-primary border border-primary px-4 py-3 shadow-lg flex items-center gap-2 max-w-[70vw]"
        style={{ left: Math.min(window.innerWidth - 200, Math.max(8, drag.x + 12)), top: Math.max(8, Math.min(window.innerHeight - 70, drag.y - 48)) }}><GripVertical size={18} />{title(drag.id)}</div>, document.body)}
    </section>
  );
}