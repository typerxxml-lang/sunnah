import { Lightbulb } from 'lucide-react';
import GlassWidget from './GlassWidget';
import { dailyTips } from '@/data/tips';
import { dayOfYear } from '@/lib/time';

export default function TipWidget() {
  const tip = dailyTips[dayOfYear() % dailyTips.length];

  return (
    <GlassWidget title="نصيحة اليوم" Icon={Lightbulb} accent="text-amber-500" full>
      <p className="font-heading text-sm text-foreground leading-relaxed min-h-[3rem]">
        {tip.text}
      </p>
      <p className="text-[10px] text-muted-foreground mt-2">— {tip.source}</p>
    </GlassWidget>
  );
}