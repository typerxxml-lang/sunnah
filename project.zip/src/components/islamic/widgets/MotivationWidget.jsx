import { Flame } from 'lucide-react';
import GlassWidget from './GlassWidget';
import { motivations } from '@/data/motivation';
import { dayOfYear } from '@/lib/time';

export default function MotivationWidget() {
  const m = motivations[dayOfYear() % motivations.length];
  return (
    <GlassWidget title="تحفيز اليوم" Icon={Flame} accent="text-orange-500" full>
      <p className="font-quran text-lg text-foreground leading-loose">«{m.text}»</p>
      <p className="text-[11px] text-muted-foreground mt-1">{m.source}</p>
    </GlassWidget>
  );
}