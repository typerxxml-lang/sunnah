import { GripVertical } from 'lucide-react';

export default function WidgetTile({ item, editing, dragging, target, handlers, onKeyDown, children }) {
  return (
    <div data-widget-id={item.id}
      className={`widget-tile relative min-w-0 ${item.full ? 'col-span-2' : ''} ${dragging ? 'opacity-50' : ''} ${target ? 'outline outline-2 outline-primary rounded-[3rem]' : ''}`}>
      {editing && <div className="flex justify-end mb-1">
        <button type="button" {...handlers} onKeyDown={onKeyDown}
          className="touch-none select-none cursor-grab active:cursor-grabbing rounded-xl bg-card text-primary border border-border p-2 focus-visible:ring-2 focus-visible:ring-ring"
          aria-label={`سحب ${item.title}؛ استخدم أسهم لوحة المفاتيح لنقلها`}>
          <GripVertical size={20} />
        </button>
      </div>}
      {children}
    </div>
  );
}