import { useState } from 'react';
import { HeartHandshake, Plus } from 'lucide-react';
import GlassWidget from './GlassWidget';
import { loadJSON, saveJSON } from '@/lib/storage';
import { todayKey, toArabicDigits } from '@/lib/time';

export default function SadaqahWidget() {
  const [logs, setLogs] = useState(() => loadJSON('iq-sadaqah', []));
  const [amount, setAmount] = useState('');

  const add = () => {
    const v = parseFloat(amount);
    if (!v) return;
    const entry = { date: todayKey(), amount: v };
    const next = [entry, ...logs].slice(0, 30);
    setLogs(next); saveJSON('iq-sadaqah', next); setAmount('');
  };
  const total = logs.reduce((s, l) => s + l.amount, 0);
  const weekCount = logs.filter((l) => l.date === todayKey()).length;

  return (
    <GlassWidget title="متتبّع الصدقة" Icon={HeartHandshake} accent="text-rose-500" full>
      <div className="flex items-center gap-2">
        <input
          type="number" inputMode="decimal" min="0" placeholder="مبلغ الصدقة"
          value={amount} onChange={(e) => setAmount(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && add()}
          className="flex-1 rounded-2xl bg-foreground/5 px-3 py-2 text-sm text-foreground outline-none focus:bg-foreground/10 transition-colors"
        />
        <button onClick={add} className="p-2.5 rounded-full bg-rose-500 text-white active:scale-90 transition-transform" aria-label="إضافة">
          <Plus size={18} />
        </button>
      </div>
      <div className="mt-3 grid grid-cols-2 gap-2 text-center">
        <div className="rounded-2xl bg-rose-500/10 px-2 py-2">
          <p className="font-heading text-xl font-bold text-rose-600 dark:text-rose-400">{toArabicDigits(total.toLocaleString('ar-SA', { maximumFractionDigits: 0 }))}</p>
          <p className="text-[10px] text-muted-foreground">إجمالي صدقاتك</p>
        </div>
        <div className="rounded-2xl bg-foreground/5 px-2 py-2">
          <p className="font-heading text-xl font-bold text-foreground">{toArabicDigits(weekCount)}</p>
          <p className="text-[10px] text-muted-foreground">صدقات اليوم</p>
        </div>
      </div>
      <p className="text-[10px] text-muted-foreground mt-2">قال النبي ﷺ: «الصدقة تطفئ الخطيئة كما يطفئ الماء النار»</p>
    </GlassWidget>
  );
}