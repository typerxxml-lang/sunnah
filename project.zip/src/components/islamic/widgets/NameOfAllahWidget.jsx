import { Sparkles } from 'lucide-react';
import GlassWidget from './GlassWidget';
import { asmaUlHusna } from '@/data/motivation';
import { dayOfYear } from '@/lib/time';

export default function NameOfAllahWidget() {
  const [name, meaning] = asmaUlHusna[dayOfYear() % asmaUlHusna.length];
  return (
    <GlassWidget title="اسم الله لليوم" Icon={Sparkles} accent="text-violet-500">
      <p className="font-quran text-3xl text-center text-gold-gradient">{name}</p>
      <p className="text-[11px] text-muted-foreground text-center mt-1 leading-relaxed">{meaning}</p>
    </GlassWidget>
  );
}