import { useState } from 'react';
import { Home as HouseIcon } from 'lucide-react';
import GlassWidget from './GlassWidget';
import { loadJSON, saveJSON } from '@/lib/storage';
import { todayKey, toArabicDigits } from '@/lib/time';

const RAWATIB = [
  { id: 'fajr', label: 'قبل الفجر', rakat: 2 },
  { id: 'dhuhr1', label: 'قبل الظهر', rakat: 4 },
  { id: 'dhuhr2', label: 'بعد الظهر', rakat: 2 },
  { id: 'maghrib', label: 'بعد المغرب', rakat: 2 },
  { id: 'isha', label: 'بعد العشاء', rakat: 2 },
];

export default function RawatibWidget() {
  const key = 'iq-rawatib-' + todayKey();
  const [done, setDone] = useState(() => loadJSON(key, []));
  const rakat = RAWATIB.filter((r) => done.includes(r.id)).reduce((s, r) => s + r.rakat, 0);

  const toggle = (id) => {
    const next = done.includes(id) ? done.filter((x) => x !== id) : [...done, id];
    setDone(next);
    saveJSON(key, next);
  };

  return (
    <GlassWidget title="السنن الرواتب" Icon={HouseIcon} accent="text-teal-500" full>
      <div className="flex items-center gap-3 mb-3">
        <div className="flex-1 h-2 rounded-full bg-foreground/10 overflow-hidden">
          <div className="h-full rounded-full bg-teal-500 transition-all duration-500" style={{ width: `${(rakat / 12) * 100}%` }} />
        </div>
        <span className="text-xs font-bold text-teal-600 dark:text-teal-400">{toArabicDigits(rakat)} / ١٢ ركعة</span>
      </div>
      <div className="flex flex-wrap gap-1.5">
        {RAWATIB.map((r) => (
          <button
            key={r.id}
            onClick={() => toggle(r.id)}
            className={`px-3 py-1.5 rounded-full text-[11px] transition-all active:scale-90 ${done.includes(r.id) ? 'bg-teal-500 text-white font-bold' : 'bg-foreground/5 text-muted-foreground'}`}
          >
            {r.label} ({toArabicDigits(r.rakat)})
          </button>
        ))}
      </div>
      <p className="text-[10px] text-muted-foreground mt-2 leading-relaxed">«من صلّى اثنتي عشرة ركعة في يوم وليلة بُني له بهنّ بيت في الجنة» — رواه مسلم</p>
    </GlassWidget>
  );
}