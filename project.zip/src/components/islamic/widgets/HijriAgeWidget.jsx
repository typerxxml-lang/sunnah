import { useState } from 'react';
import { Hourglass } from 'lucide-react';
import GlassWidget from './GlassWidget';
import { hijri } from '@/lib/hijri';
import { loadString, saveString } from '@/lib/storage';
import { toArabicDigits } from '@/lib/time';

const before = (m1, d1, m2, d2) => m1 < m2 || (m1 === m2 && d1 < d2);

function ages(birth) {
  const b = new Date(birth);
  const now = new Date();
  if (isNaN(b) || b >= now) return null;
  const hb = hijri(b);
  const hn = hijri(now);
  return {
    hijri: hn.year - hb.year - (before(hn.month, hn.day, hb.month, hb.day) ? 1 : 0),
    greg: now.getFullYear() - b.getFullYear() - (before(now.getMonth(), now.getDate(), b.getMonth(), b.getDate()) ? 1 : 0),
    days: Math.floor((now - b) / 86400000),
  };
}

export default function HijriAgeWidget() {
  const [birth, setBirth] = useState(() => loadString('iq-birthdate', ''));
  const a = birth ? ages(birth) : null;

  return (
    <GlassWidget title="عمرك بالهجري" Icon={Hourglass} accent="text-violet-500" full>
      <input
        type="date"
        value={birth}
        onChange={(e) => { setBirth(e.target.value); saveString('iq-birthdate', e.target.value); }}
        className="w-full rounded-2xl bg-foreground/5 px-3 py-2 text-sm text-foreground outline-none focus:bg-foreground/10 transition-colors"
        aria-label="تاريخ الميلاد"
      />
      {a ? (
        <div className="grid grid-cols-3 gap-2 mt-3 text-center">
          <Stat value={a.hijri} label="سنة هجرية" strong />
          <Stat value={a.greg} label="سنة ميلادية" />
          <Stat value={a.days.toLocaleString('ar-SA')} label="يوماً عشتها" />
        </div>
      ) : (
        <p className="text-[11px] text-muted-foreground mt-2 text-center">أدخل تاريخ ميلادك لمعرفة عمرك بالتقويم الهجري</p>
      )}
    </GlassWidget>
  );
}

function Stat({ value, label, strong }) {
  return (
    <div className={`rounded-2xl px-1 py-2 ${strong ? 'bg-violet-500/10' : 'bg-foreground/5'}`}>
      <p className={`font-heading text-lg font-bold ${strong ? 'text-violet-600 dark:text-violet-400' : 'text-foreground'}`}>{toArabicDigits(value)}</p>
      <p className="text-[10px] text-muted-foreground">{label}</p>
    </div>
  );
}