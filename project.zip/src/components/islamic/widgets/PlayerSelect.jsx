import { ChevronDown } from 'lucide-react';

export default function PlayerSelect({ value, onChange, options, label }) {
  return (
    <div className="relative">
      <select
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        aria-label={label}
        className="w-full appearance-none rounded-2xl bg-foreground/5 py-2 pr-3 pl-8 text-sm text-foreground outline-none focus:bg-foreground/10 transition-colors"
      >
        {options.map(([v, l]) => (
          <option key={v} value={v} className="bg-background text-foreground">{l}</option>
        ))}
      </select>
      <ChevronDown size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
    </div>
  );
}