import { CalendarDays } from 'lucide-react';
import GlassWidget from './GlassWidget';
import { hijri, hijriMonth, gregLabel } from '@/lib/hijri';
import { toArabicDigits } from '@/lib/time';

export default function HijriDateWidget() {
  const now = new Date();
  const h = hijri(now);

  return (
    <GlassWidget title="التاريخ الهجري" Icon={CalendarDays}>
      <div className="text-center">
        <p className="font-heading text-4xl font-bold text-emerald-600 dark:text-emerald-400 leading-none">
          {toArabicDigits(h.day)}
        </p>
        <p className="font-heading text-sm font-bold text-foreground mt-1.5">
          {hijriMonth(now)} {toArabicDigits(h.year)}هـ
        </p>
        <p className="text-[10px] text-muted-foreground mt-1">{gregLabel(now, true)}</p>
      </div>
    </GlassWidget>
  );
}