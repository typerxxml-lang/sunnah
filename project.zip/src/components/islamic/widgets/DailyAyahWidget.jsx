import { BookOpen } from 'lucide-react';
import GlassWidget from './GlassWidget';
import { quranVerses } from '@/data/quran';
import { dayOfYear } from '@/lib/time';

export default function DailyAyahWidget({ onOpen }) {
  const v = quranVerses[(dayOfYear() * 7) % quranVerses.length];
  return (
    <GlassWidget title="آية اليوم" Icon={BookOpen} accent="text-amber-500" onClick={onOpen} full>
      <p className="font-quran text-xl text-center text-foreground leading-loose" dir="rtl">{v.text}</p>
      <p className="text-[11px] text-center text-muted-foreground mt-2">{v.surah} • الآية {v.ayahNumber}</p>
      <p className="text-xs text-muted-foreground/90 text-center mt-1 line-clamp-2">{v.meaning}</p>
    </GlassWidget>
  );
}