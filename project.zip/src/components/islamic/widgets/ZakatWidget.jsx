import { useState } from 'react';
import { Calculator } from 'lucide-react';
import GlassWidget from './GlassWidget';
import { loadString, saveString } from '@/lib/storage';

const fmt = (n) => n.toLocaleString('ar-SA', { maximumFractionDigits: 2 });

function Field({ label, value, onChange }) {
  return (
    <label className="block">
      <span className="text-[10px] text-muted-foreground">{label}</span>
      <input
        type="number" inputMode="decimal" min="0" placeholder="٠"
        value={value} onChange={(e) => onChange(e.target.value)}
        className="mt-1 w-full rounded-2xl bg-foreground/5 px-3 py-2 text-sm text-foreground outline-none focus:bg-foreground/10 transition-colors"
      />
    </label>
  );
}

export default function ZakatWidget() {
  const [amount, setAmount] = useState(() => loadString('iq-zakat-amount', ''));
  const [gold, setGold] = useState(() => loadString('iq-zakat-gold', ''));
  const save = (key, set) => (v) => { set(v); saveString(key, v); };

  const value = parseFloat(amount) || 0;
  const nisab = (parseFloat(gold) || 0) * 85;

  return (
    <GlassWidget title="حاسبة الزكاة" Icon={Calculator} accent="text-amber-500" full>
      <div className="grid grid-cols-2 gap-2">
        <Field label="المال المدّخر" value={amount} onChange={save('iq-zakat-amount', setAmount)} />
        <Field label="سعر غرام الذهب (عيار ٢٤)" value={gold} onChange={save('iq-zakat-gold', setGold)} />
      </div>
      <div className="mt-3 rounded-2xl bg-amber-500/10 px-3 py-2.5 text-center">
        {!value || !nisab ? (
          <p className="text-xs text-muted-foreground">أدخل المبلغ وسعر الذهب لحساب الزكاة</p>
        ) : value < nisab ? (
          <p className="text-xs text-foreground">لم يبلغ مالك النصاب ({fmt(nisab)}) فلا زكاة عليه</p>
        ) : (
          <>
            <p className="text-[11px] text-muted-foreground">الزكاة الواجبة (٢٫٥٪)</p>
            <p className="font-heading text-2xl font-bold text-amber-600 dark:text-amber-400">{fmt(value * 0.025)}</p>
          </>
        )}
      </div>
      <p className="text-[10px] text-muted-foreground mt-2">النصاب قيمة ٨٥ غراماً من الذهب، وتجب الزكاة إذا حال عليه الحول الهجري.</p>
    </GlassWidget>
  );
}