import { Moon } from 'lucide-react';
import GlassWidget from './GlassWidget';
import { usePrayerTimes } from '@/hooks/usePrayerTimes';
import { formatHM } from '@/lib/time';

const toMin = (s) => { const [h, m] = s.split(':').map(Number); return h * 60 + m; };
const toHM = (m) => { const x = ((Math.round(m) % 1440) + 1440) % 1440; return `${Math.floor(x / 60)}:${String(x % 60).padStart(2, '0')}`; };

export default function NightThirdWidget({ timeFormat }) {
  const { times } = usePrayerTimes();

  if (!times) {
    return (
      <GlassWidget title="الثلث الأخير" Icon={Moon} accent="text-indigo-500">
        <p className="text-[11px] text-muted-foreground leading-relaxed">يظهر بعد تحديد مواقيت الصلاة</p>
      </GlassWidget>
    );
  }

  const maghrib = toMin(times.Maghrib);
  const fajr = toMin(times.Fajr) + 1440;
  const night = fajr - maghrib;
  const third = maghrib + (night * 2) / 3;
  const mid = maghrib + night / 2;
  const d = new Date();
  let now = d.getHours() * 60 + d.getMinutes();
  if (now < maghrib) now += 1440;
  const inThird = now >= third && now < fajr;

  return (
    <GlassWidget title="الثلث الأخير" Icon={Moon} accent="text-indigo-500">
      {inThird && <p className="text-[10px] font-bold text-indigo-500 mb-1">أنت الآن في الثلث الأخير</p>}
      <p className="font-heading text-2xl font-bold text-foreground leading-tight">{formatHM(toHM(third), timeFormat)}</p>
      <p className="text-[11px] text-muted-foreground">بداية الثلث الأخير من الليل</p>
      <p className="text-[10px] text-muted-foreground mt-1">منتصف الليل: {formatHM(toHM(mid), timeFormat)}</p>
    </GlassWidget>
  );
}