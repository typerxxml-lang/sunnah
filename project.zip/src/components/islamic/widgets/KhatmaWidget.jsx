import { useState } from 'react';
import { BookOpenCheck, Plus, Minus } from 'lucide-react';
import GlassWidget from './GlassWidget';
import { loadJSON, saveJSON } from '@/lib/storage';
import { todayKey, toArabicDigits } from '@/lib/time';

const TOTAL_PAGES = 604;

export default function KhatmaWidget({ goal = 5 }) {
  const dayKey = 'iq-pages-' + todayKey();
  const [today, setToday] = useState(() => loadJSON(dayKey, 0));
  const [total, setTotal] = useState(() => loadJSON('iq-pages-total', 0));

  const change = (delta) => {
    const nt = Math.max(0, today + delta);
    const diff = nt - today;
    const ntotal = Math.max(0, Math.min(TOTAL_PAGES * 99, total + diff));
    setToday(nt); setTotal(ntotal);
    saveJSON(dayKey, nt); saveJSON('iq-pages-total', ntotal);
  };

  const juz = Math.floor((total % TOTAL_PAGES) / 20.13);
  const khatmat = Math.floor(total / TOTAL_PAGES);
  const pct = Math.min(100, Math.round((today / Math.max(1, goal)) * 100));

  return (
    <GlassWidget title="وردي اليوم" Icon={BookOpenCheck} full>
      <div className="flex items-center gap-4">
        <div className="relative w-16 h-16 shrink-0">
          <svg viewBox="0 0 36 36" className="w-full h-full -rotate-90">
            <circle cx="18" cy="18" r="15" fill="none" stroke="rgba(128,128,128,0.2)" strokeWidth="3.5" />
            <circle cx="18" cy="18" r="15" fill="none" stroke="currentColor" strokeWidth="3.5" strokeLinecap="round"
              className="text-emerald-600 dark:text-emerald-400"
              strokeDasharray={2 * Math.PI * 15}
              strokeDashoffset={2 * Math.PI * 15 * (1 - pct / 100)}
              style={{ transition: 'stroke-dashoffset .6s cubic-bezier(.22,1,.36,1)' }} />
          </svg>
          <span className="absolute inset-0 flex items-center justify-center text-xs font-bold text-foreground">{toArabicDigits(pct)}٪</span>
        </div>

        <div className="flex-1 min-w-0">
          <p className="font-heading text-lg font-bold text-foreground">
            {toArabicDigits(today)} <span className="text-xs font-normal text-muted-foreground">من {toArabicDigits(goal)} صفحات</span>
          </p>
          <p className="text-[11px] text-muted-foreground mt-0.5">
            أنت في الجزء {toArabicDigits(juz + 1)} • الختمات: {toArabicDigits(khatmat)}
          </p>
        </div>

        <div className="flex flex-col gap-1.5">
          <button onClick={() => change(1)} className="w-9 h-9 rounded-full bg-emerald-600 dark:bg-emerald-500 text-white flex items-center justify-center active:scale-90 transition-transform" aria-label="زيادة صفحة">
            <Plus size={16} />
          </button>
          <button onClick={() => change(-1)} className="w-9 h-9 rounded-full bg-foreground/10 text-foreground flex items-center justify-center active:scale-90 transition-transform" aria-label="إنقاص صفحة">
            <Minus size={16} />
          </button>
        </div>
      </div>
    </GlassWidget>
  );
}