import { useEffect, useState } from 'react';
import { TrendingUp } from 'lucide-react';
import GlassWidget from './GlassWidget';
import { dailyDeeds } from '@/data/deeds';
import { loadJSON } from '@/lib/storage';
import { todayKey, toArabicDigits } from '@/lib/time';
import { addDays } from '@/lib/hijri';

const DAY = new Intl.DateTimeFormat('ar-SA', { weekday: 'short' });

function week() {
  return Array.from({ length: 7 }, (_, i) => {
    const d = addDays(new Date(), i - 6);
    return { label: DAY.format(d), value: loadJSON('iq-deeds-' + todayKey(d), []).length, today: i === 6 };
  });
}

export default function WeeklyProgressWidget() {
  const [data, setData] = useState(week);

  useEffect(() => {
    const refresh = () => setData(week());
    window.addEventListener('iq-deeds', refresh);
    return () => window.removeEventListener('iq-deeds', refresh);
  }, []);

  const total = data.reduce((sum, d) => sum + d.value, 0);

  return (
    <GlassWidget title="إنجازك هذا الأسبوع" Icon={TrendingUp} full>
      <div className="flex items-stretch justify-between gap-2 h-28">
        {data.map((d, i) => (
          <div key={i} className="flex-1 flex flex-col items-center gap-1">
            <span className="text-[9px] text-muted-foreground">{toArabicDigits(d.value)}</span>
            <div className="flex-1 w-full flex items-end justify-center">
              <div
                className={`w-full max-w-[22px] rounded-full transition-all duration-700 ${d.today ? 'bg-emerald-500' : 'bg-emerald-500/35'}`}
                style={{ height: `${Math.max(6, (d.value / dailyDeeds.length) * 100)}%` }}
              />
            </div>
            <span className={`text-[9px] whitespace-nowrap ${d.today ? 'font-bold text-emerald-600 dark:text-emerald-400' : 'text-muted-foreground'}`}>{d.label}</span>
          </div>
        ))}
      </div>
      <p className="text-[10px] text-muted-foreground mt-2">مجموع أعمالك الصالحة خلال ٧ أيام: {toArabicDigits(total)}</p>
    </GlassWidget>
  );
}