import { useEffect, useRef, useState } from 'react';
import { Headphones, Play, Pause, SkipBack, SkipForward, Loader2 } from 'lucide-react';
import GlassWidget from './GlassWidget';
import PlayerSelect from './PlayerSelect';
import { SURAHS } from '@/data/surahs';
import { RECITERS, surahAudio } from '@/data/reciters';
import { loadJSON, saveJSON } from '@/lib/storage';

const SURAH_OPTIONS = SURAHS.map((s) => [s.number, `${s.number}. ${s.name}`]);
const RECITER_OPTIONS = RECITERS.map((r, i) => [i, r.name]);

export default function QuranPlayerWidget() {
  const audio = useRef(null);
  const want = useRef(false);
  const [sel, setSel] = useState(() => loadJSON('iq-player', { surah: 1, reciter: 0 }));
  const [playing, setPlaying] = useState(false);
  const [loading, setLoading] = useState(false);
  const [pos, setPos] = useState(0);
  const reciter = RECITERS[sel.reciter] || RECITERS[0];
  const src = surahAudio(reciter, sel.surah);

  const update = (patch) => { const next = { ...sel, ...patch }; setSel(next); saveJSON('iq-player', next); };
  const go = (d) => update({ surah: ((sel.surah - 1 + d + 114) % 114) + 1 });

  useEffect(() => {
    setPos(0);
    if (want.current) audio.current.play().catch(() => setLoading(false));
  }, [src]);

  const toggle = () => {
    const a = audio.current;
    if (a.paused) { want.current = true; setLoading(true); a.play().catch(() => setLoading(false)); }
    else { want.current = false; a.pause(); }
  };
  const seek = (e) => { const a = audio.current; if (a.duration) a.currentTime = (e.target.value / 1000) * a.duration; };
  const btn = 'p-2.5 rounded-full text-foreground hover:bg-foreground/10 active:scale-90 transition-all';

  return (
    <GlassWidget title="استمع للقرآن الكريم" Icon={Headphones} full>
      <audio
        ref={audio} src={src} preload="none"
        onPlay={() => setPlaying(true)} onPause={() => { setPlaying(false); setLoading(false); }}
        onWaiting={() => setLoading(true)} onPlaying={() => setLoading(false)}
        onError={() => { setLoading(false); setPlaying(false); }}
        onTimeUpdate={(e) => e.target.duration && setPos((e.target.currentTime / e.target.duration) * 1000)}
        onEnded={() => go(1)}
      />
      <div className="grid grid-cols-2 gap-2">
        <PlayerSelect label="السورة" value={sel.surah} onChange={(v) => update({ surah: v })} options={SURAH_OPTIONS} />
        <PlayerSelect label="القارئ" value={sel.reciter} onChange={(v) => update({ reciter: v })} options={RECITER_OPTIONS} />
      </div>
      <input type="range" min="0" max="1000" value={pos} onChange={seek} dir="ltr" className="w-full mt-4" aria-label="موضع التلاوة" />
      <div dir="ltr" className="flex items-center justify-center gap-6 mt-3">
        <button onClick={() => go(-1)} className={btn} aria-label="السورة السابقة"><SkipBack size={20} /></button>
        <button onClick={toggle} className="w-14 h-14 rounded-full bg-emerald-600 dark:bg-emerald-500 text-white flex items-center justify-center shadow-lg active:scale-90 transition-transform" aria-label={playing ? 'إيقاف' : 'تشغيل'}>
          {loading ? <Loader2 size={22} className="animate-spin" /> : playing ? <Pause size={22} /> : <Play size={22} className="ml-0.5" />}
        </button>
        <button onClick={() => go(1)} className={btn} aria-label="السورة التالية"><SkipForward size={20} /></button>
      </div>
      <p className="text-center text-[11px] text-muted-foreground mt-2">سورة {SURAHS[sel.surah - 1].name} • {reciter.name}</p>
    </GlassWidget>
  );
}