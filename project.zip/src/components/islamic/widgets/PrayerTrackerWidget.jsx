import { useState } from 'react';
import { CheckCircle2, Circle, ListChecks } from 'lucide-react';
import GlassWidget from './GlassWidget';
import { loadJSON, saveJSON } from '@/lib/storage';
import { todayKey, toArabicDigits } from '@/lib/time';

const PRAYERS = ['الفجر', 'الظهر', 'العصر', 'المغرب', 'العشاء'];

export default function PrayerTrackerWidget() {
  const key = 'iq-prayed-' + todayKey();
  const [done, setDone] = useState(() => loadJSON(key, []));

  const toggle = (p) => {
    const next = done.includes(p) ? done.filter((x) => x !== p) : [...done, p];
    setDone(next);
    saveJSON(key, next);
    if (navigator.vibrate) navigator.vibrate(8);
  };

  return (
    <GlassWidget title="متتبّع الصلوات" Icon={ListChecks} full>
      <div className="flex items-center justify-between mb-3">
        <p className="text-xs text-muted-foreground">صلواتك اليوم</p>
        <p className="font-heading text-lg font-bold text-emerald-600 dark:text-emerald-400">{toArabicDigits(done.length)} / ٥</p>
      </div>
      <div className="grid grid-cols-5 gap-1.5">
        {PRAYERS.map((p) => {
          const on = done.includes(p);
          return (
            <button
              key={p}
              onClick={() => toggle(p)}
              className={`flex flex-col items-center gap-1 py-2 rounded-2xl transition-all active:scale-90 ${on ? 'bg-emerald-500/15' : 'bg-foreground/5'}`}
            >
              {on ? <CheckCircle2 size={20} className="text-emerald-600 dark:text-emerald-400" /> : <Circle size={20} className="text-muted-foreground/50" />}
              <span className={`text-[10px] ${on ? 'font-bold text-emerald-700 dark:text-emerald-300' : 'text-muted-foreground'}`}>{p}</span>
            </button>
          );
        })}
      </div>
      {done.length === 5 && (
        <p className="text-[11px] text-center text-emerald-600 dark:text-emerald-400 mt-2">ما شاء الله! أتممت صلواتك اليوم، تقبّل الله منك</p>
      )}
    </GlassWidget>
  );
}