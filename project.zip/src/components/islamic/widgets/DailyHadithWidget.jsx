import { Quote } from 'lucide-react';
import GlassWidget from './GlassWidget';
import { hadiths } from '@/data/hadiths';
import { dayOfYear } from '@/lib/time';

export default function DailyHadithWidget({ onOpen }) {
  const h = hadiths[(dayOfYear() * 3) % hadiths.length];
  return (
    <GlassWidget title="حديث اليوم" Icon={Quote} accent="text-sky-500" onClick={onOpen} full>
      <h5 className="font-heading text-sm font-bold text-foreground mb-1">{h.title}</h5>
      <p className="font-heading text-sm text-foreground/85 leading-relaxed line-clamp-3">{h.text}</p>
      <p className="text-[10px] text-muted-foreground mt-2">{h.narrator} • {h.reference}</p>
    </GlassWidget>
  );
}