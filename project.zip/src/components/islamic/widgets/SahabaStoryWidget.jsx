import { Users } from 'lucide-react';
import GlassWidget from './GlassWidget';
import { sahaba } from '@/data/sahaba';
import { dayOfYear } from '@/lib/time';

export default function SahabaStoryWidget() {
  const s = sahaba[dayOfYear() % sahaba.length];

  return (
    <GlassWidget title="قصة صحابي اليوم" Icon={Users} accent="text-amber-500" full>
      <div className="flex items-baseline gap-2">
        <h4 className="font-heading text-base font-bold text-foreground">{s.name}</h4>
        <span className="text-[10px] text-amber-600 dark:text-amber-400">{s.title}</span>
      </div>
      <p className="text-xs text-foreground/80 mt-1.5 leading-relaxed line-clamp-4">{s.text}</p>
    </GlassWidget>
  );
}