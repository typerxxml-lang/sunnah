import { Share2 } from 'lucide-react';
import { shareContent } from '@/lib/share';

export default function QuranCard({ verse }) {
  return (
    <div className="glass-blur p-5 anim-fade-up">
      <div className="flex items-center justify-between mb-3">
        <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-full">
          {verse.surah} • الآية {verse.ayahNumber}
        </span>
        <div className="flex items-center gap-2">
          {verse.topic && (
            <span className="text-xs text-muted-foreground">{verse.topic}</span>
          )}
          <button
            onClick={() => shareContent(`${verse.surah} - الآية ${verse.ayahNumber}`, verse.text)}
            className="p-1.5 rounded-full hover:bg-foreground/10 transition-colors"
            aria-label="مشاركة"
          >
            <Share2 size={16} className="text-muted-foreground" />
          </button>
        </div>
      </div>

      <p className="font-quran text-2xl text-center text-foreground leading-loose mb-4" dir="rtl">
        {verse.text}
      </p>

      <div className="bg-foreground/5 rounded-3xl p-3">
        <p className="text-sm text-muted-foreground leading-relaxed">
          {verse.meaning}
        </p>
        {verse.meaningSource && <p className="mt-2 text-[10px] text-muted-foreground">{verse.meaningSource}</p>}
      </div>
    </div>
  );
}