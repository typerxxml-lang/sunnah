import { Search, Moon, Sun } from 'lucide-react';
import { InstallAppButton } from './InstallGuide';
import { useGlassEffect } from '@/hooks/useGlassEffect';
import { useSquircleClip } from '@/hooks/useSquircleClip';
import { AppLogo } from './DecorativeSvg';
import PlusBadge from './PlusBadge';

export default function Header({ theme, onToggleTheme, onSearch, user, isPlusActive, onInstallClick }) {
  const glassRef = useGlassEffect(32, 22, 52);
  useSquircleClip(glassRef);

  return (
    <header className="fixed top-3 left-3 right-3 z-30 max-w-3xl mx-auto anim-pop">
      <div ref={glassRef} className="glass bar flex items-center justify-between px-4 py-3">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="shrink-0">
            <AppLogo size={30} className="text-primary" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <h1 className="font-heading text-sm sm:text-base font-bold text-foreground truncate leading-tight">
                نافعاً
              </h1>
              {isPlusActive && <PlusBadge size={12} />}
            </div>
            <p className="text-[10px] text-muted-foreground truncate">Nafiahan · السنة والقرآن</p>
          </div>
        </div>

        <div className="flex items-center gap-1 shrink-0">
          <InstallAppButton onClick={onInstallClick} compact />
          <button
            onClick={onSearch}
            className="p-2.5 rounded-full hover:bg-foreground/10 active:scale-90 transition-all"
            aria-label="بحث"
          >
            <Search size={19} className="text-foreground" />
          </button>
          <button
            onClick={onToggleTheme}
            className="p-2.5 rounded-full hover:bg-foreground/10 active:scale-90 transition-all"
            aria-label="تبديل الوضع"
          >
            {theme === 'dark'
              ? <Sun size={19} className="text-amber-400" />
              : <Moon size={19} className="text-foreground" />}
          </button>
        </div>
      </div>
    </header>
  );
}