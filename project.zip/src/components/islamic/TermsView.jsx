import { TERMS } from '@/data/terms';

export default function TermsView() {
  return (
    <div>
      <h2 className="font-heading text-xl font-bold text-foreground mb-4">الشروط والأحكام</h2>

      <div className="space-y-3">
        {TERMS.map((t) => (
          <Section key={t.title} title={t.title}>{t.text}</Section>
        ))}

        <p className="text-xs text-muted-foreground text-center mt-4">
          آخر تحديث: أكتوبر 2026
        </p>
      </div>
    </div>
  );
}

function Section({ title, children }) {
  return (
    <div className="glass-blur p-5" style={{ borderRadius: 28 }}>
      <h3 className="font-heading text-base font-bold text-foreground mb-2">{title}</h3>
      <p className="text-sm text-muted-foreground leading-relaxed">{children}</p>
    </div>
  );
}