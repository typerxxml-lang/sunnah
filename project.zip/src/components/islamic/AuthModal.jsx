import { useState } from 'react';
import { useGlassEffect } from '@/hooks/useGlassEffect';
import NafiahanLogo from './NafiahanLogo';
import { InstallAppButton } from './InstallGuide';
import TermsConsent from './TermsConsent';
import DeveloperNote from './DeveloperNote';
import { termsAccepted } from '@/lib/terms';
import { LogIn, MessageCircle } from 'lucide-react';

export default function AuthModal({ onLogin, onGuest, onInstallClick }) {
  const [name, setName] = useState('');
  const [showTerms] = useState(() => !termsAccepted());
  const [agreed, setAgreed] = useState(termsAccepted);
  const glassRef = useGlassEffect(32, 26, 46);

  const submit = () => {
    if (agreed && name.trim()) onLogin(name.trim());
  };

  const primary = 'py-3 flex items-center justify-center gap-2 font-bold transition disabled:opacity-40';

  return (
    <div className="fixed inset-0 z-50 flex p-4 bg-black/50 overflow-y-auto overflow-x-hidden">
      <div ref={glassRef} className="glass max-w-md w-full p-6 text-center m-auto relative">
        <DeveloperNote className="absolute top-4 left-4 z-10" size={40} />
        <div className="flex justify-center mb-3">
          <div className="relative">
            <div className="absolute inset-0 blur-2xl bg-emerald-500/30 rounded-full" />
            <NafiahanLogo size={58} className="relative drop-shadow-xl" />
          </div>
        </div>

        <h2 className="font-heading text-2xl font-bold text-foreground">نافعاً</h2>
        <p className="text-[11px] font-semibold tracking-widest text-primary mt-0.5 mb-1">NAFIAHAN</p>
        <p className="text-sm text-muted-foreground mt-1 mb-4">
          سجّل دخولك لحفظ تفضيلاتك ومفضلاتك على هذا الجهاز
        </p>

        <div className="mb-4 rounded-2xl border border-primary/20 bg-primary/[0.06] p-3 text-right">
          <p className="text-sm font-bold text-foreground whitespace-pre-line leading-relaxed">للتواصل واتساب 0578488914</p>
          <p className="mt-1 text-xs leading-relaxed text-muted-foreground">ناخذ اقتراحاتكم وشكاويكم جميعها</p>
          <p className="mt-1 text-xs leading-relaxed text-muted-foreground">وميزة الـPLUS مو شرط تاخذها بفلوس لكن للي يستحق</p>
          <p className="mt-1 text-xs leading-relaxed text-muted-foreground">لما تكمل 7 ايام كاملاً في التطبيق نعطيك بلس مجاناً</p>
          <a href="https://wa.me/966578488914" target="_blank" rel="noreferrer" className="mt-3 inline-flex items-center gap-1.5 rounded-full bg-emerald-600/10 px-3 py-1.5 text-xs font-bold text-emerald-700 dark:text-emerald-300">
            <MessageCircle size={14} /> تواصل عبر واتساب
          </a>
        </div>

        {showTerms && (
          <div className="mb-4">
            <TermsConsent checked={agreed} onChange={setAgreed} />
          </div>
        )}

        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && submit()}
          placeholder="اكتب اسمك للدخول..."
          className="w-full px-4 py-3 bg-foreground/5 text-foreground placeholder:text-muted-foreground outline-none focus:bg-foreground/10 transition-colors text-center"
          style={{ borderRadius: 22 }}
        />

        <button
          onClick={submit}
          disabled={!agreed || !name.trim()}
          className={`w-full mt-3 ${primary} bg-emerald-600 dark:bg-emerald-500 text-white hover:brightness-110`}
          style={{ borderRadius: 22 }}
        >
          <LogIn size={17} />
          تسجيل الدخول
        </button>

        <button
          onClick={onGuest}
          disabled={!agreed}
          className="w-full mt-2 py-3 text-sm text-muted-foreground hover:text-foreground transition disabled:opacity-40"
        >
          تصفح كضيف بدون اسم
        </button>

        <div className="mt-3 border-t border-foreground/10 pt-3">
          <p className="mb-2 text-xs text-muted-foreground">تقدر تثبّت نافعاً على جوالك أو جهازك وتفتحه مثل أي تطبيق.</p>
          <InstallAppButton onClick={onInstallClick} />
        </div>
      </div>
    </div>
  );
}