import { useState } from 'react';
import { useGlassEffect } from '@/hooks/useGlassEffect';
import { IslamicStar } from './DecorativeSvg';
import TermsConsent from './TermsConsent';
import DeveloperNote from './DeveloperNote';
import { termsAccepted } from '@/lib/terms';
import { LogIn } from 'lucide-react';

export default function AuthModal({ onLogin, onGuest }) {
  const [name, setName] = useState('');
  const [showTerms] = useState(() => !termsAccepted());
  const [agreed, setAgreed] = useState(termsAccepted);
  const glassRef = useGlassEffect(32, 26, 46);

  const submit = () => {
    if (agreed && name.trim()) onLogin(name.trim());
  };

  const primary = 'py-3 flex items-center justify-center gap-2 font-bold transition disabled:opacity-40';

  return (
    <div className="fixed inset-0 z-50 flex p-4 bg-black/50 overflow-y-auto overflow-x-hidden">
      <div ref={glassRef} className="glass max-w-md w-full p-6 text-center m-auto relative">
        <DeveloperNote className="absolute top-4 left-4 z-10" size={40} />
        <div className="flex justify-center mb-3">
          <div className="relative">
            <div className="absolute inset-0 blur-2xl bg-emerald-500/30 rounded-full" />
            <IslamicStar size={52} className="relative text-emerald-600 dark:text-emerald-400" />
          </div>
        </div>

        <h2 className="font-heading text-2xl font-bold text-foreground">أهلاً وسهلاً</h2>
        <p className="text-sm text-muted-foreground mt-1 mb-4">
          سجّل دخولك لحفظ تفضيلاتك ومفضلاتك على هذا الجهاز
        </p>

        {showTerms && (
          <div className="mb-4">
            <TermsConsent checked={agreed} onChange={setAgreed} />
          </div>
        )}

        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && submit()}
          placeholder="اكتب اسمك للدخول..."
          className="w-full px-4 py-3 bg-foreground/5 text-foreground placeholder:text-muted-foreground outline-none focus:bg-foreground/10 transition-colors text-center"
          style={{ borderRadius: 22 }}
        />

        <button
          onClick={submit}
          disabled={!agreed || !name.trim()}
          className={`w-full mt-3 ${primary} bg-emerald-600 dark:bg-emerald-500 text-white hover:brightness-110`}
          style={{ borderRadius: 22 }}
        >
          <LogIn size={17} />
          تسجيل الدخول
        </button>

        <button
          onClick={onGuest}
          disabled={!agreed}
          className="w-full mt-2 py-3 text-sm text-muted-foreground hover:text-foreground transition disabled:opacity-40"
        >
          تصفح كضيف بدون اسم
        </button>
      </div>
    </div>
  );
}