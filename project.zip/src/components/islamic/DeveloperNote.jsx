import { useState } from 'react';
import { createPortal } from 'react-dom';
import { X } from 'lucide-react';
import { useGlassEffect } from '@/hooks/useGlassEffect';

// رقم واتساب المطور (يُستخدم للرابط فقط، والنص المعروض كما كتبه المطور)
const WA_LINK = 'https://wa.me/966578488914';

/** زر زجاجي دائري فيه i يفتح ملاحظة من المطور */
// className يُطبَّق على غلاف الزر (للموضع)؛ لأن .glass يفرض position: relative.
export default function DeveloperNote({ className = '', size = 44 }) {
  const [open, setOpen] = useState(false);
  const btnRef = useGlassEffect(22, 16, 34);

  return (
    <>
      <div className={className}>
        <button
          ref={btnRef}
          type="button"
          onClick={() => setOpen(true)}
          aria-label="ملاحظة من المطور"
          className="glass flex items-center justify-center shrink-0 active:scale-90 transition-transform"
          style={{ width: size, height: size, borderRadius: '50%', cornerShape: 'round' }}
        >
          <span className="font-serif italic font-bold text-lg leading-none text-foreground select-none">i</span>
        </button>
      </div>

      {open && createPortal(
        <div
          className="fixed inset-0 z-[80] flex p-4 bg-black/55 overflow-y-auto overflow-x-hidden"
          role="dialog"
          aria-modal="true"
          aria-label="ملاحظة من المطور"
          dir="rtl"
          onClick={() => setOpen(false)}
        >
          <NoteCard onClose={() => setOpen(false)}>
            <div className="text-right space-y-3 pt-6 text-foreground leading-relaxed">
              <p className="font-heading text-lg font-bold">ملاحظة من المطور عبدالله السويلم 😎</p>
              <p className="text-sm">الموقع تجريبي ومو جاهز بشكل كامل</p>
              <p className="text-sm">جاهز ولا هنقرستيشن ههههه امزح امزح</p>
              <p className="text-sm">
                الزبدة طورت ذا الموقع من 2023 وللحين اطوره ف اذا في مشاكل كلموني واتس{' '}
                <a href={WA_LINK} target="_blank" rel="noopener noreferrer" dir="ltr" className="text-primary font-bold underline">0578488914</a>{' '}
                وتراه مش رقمي الاساسي يعني اللي يدق محد بيرد عليه
              </p>
              <p className="text-sm">وبس والله.. اي مشكلة اي اقتراح قلي اياه وابشربها وانا ولد السويلم 🫡</p>
              <p className="text-sm font-bold">وترا اول 10 اشخاص يكلموني واتس لهم PLUS مجاني</p>
              <p className="text-sm">مشروع جيتهاااااااااااااب لان ماعندي فلوس حق دومين</p>
              <p className="text-sm">وسلمولي</p>
            </div>
          </NoteCard>
        </div>,
        document.body
      )}
    </>
  );
}

function NoteCard({ onClose, children }) {
  const ref = useGlassEffect(32, 26, 46);
  return (
    <div ref={ref} className="glass max-w-md w-full p-6 m-auto relative" style={{ background: 'hsl(var(--card) / 0.85)' }} onClick={(e) => e.stopPropagation()}>
      <button
        type="button"
        onClick={onClose}
        aria-label="إغلاق"
        className="absolute top-4 left-4 rounded-full p-2 text-muted-foreground hover:bg-foreground/10"
      >
        <X size={20} />
      </button>
      {children}
    </div>
  );
}
