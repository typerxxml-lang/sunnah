import { useState, useEffect } from 'react';
import { useGlassEffect } from '@/hooks/useGlassEffect';
import { loadJSON, saveJSON } from '@/lib/storage';
import { RotateCcw, Check } from 'lucide-react';

const DHIKR_PRESETS = [
  { text: 'سُبْحَانَ الله', target: 33 },
  { text: 'الْحَمْدُ لِلَّه', target: 33 },
  { text: 'اللَّهُ أَكْبَر', target: 34 },
  { text: 'لَا إِلَهَ إِلَّا اللَّه', target: 100 },
  { text: 'أَسْتَغْفِرُ اللَّه', target: 100 },
  { text: 'سُبْحَانَ اللَّهِ وَبِحَمْدِه', target: 100 },
  { text: 'لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّه', target: 100 },
];

export default function TasbeehCounter() {
  const [count, setCount] = useState(() => loadJSON('iq-tasbeeh-count', 0));
  const [selectedIdx, setSelectedIdx] = useState(() => loadJSON('iq-tasbeeh-idx', 0));
  const [completed, setCompleted] = useState(false);
  const glassRef = useGlassEffect(42, 28, 48);

  const current = DHIKR_PRESETS[selectedIdx];
  const progress = Math.min(count / current.target, 1);
  const circumference = 2 * Math.PI * 90;

  useEffect(() => {
    saveJSON('iq-tasbeeh-count', count);
  }, [count]);

  useEffect(() => {
    saveJSON('iq-tasbeeh-idx', selectedIdx);
  }, [selectedIdx]);

  const increment = () => {
    if (count >= current.target) return;
    const newCount = count + 1;
    setCount(newCount);
    if (newCount >= current.target) {
      setCompleted(true);
      if (navigator.vibrate) navigator.vibrate([10, 50, 10]);
    } else if (navigator.vibrate) navigator.vibrate(10);
  };

  const reset = () => {
    setCount(0);
    setCompleted(false);
  };

  const selectDhikr = (idx) => {
    setSelectedIdx(idx);
    setCount(0);
    setCompleted(false);
  };

  return (
    <div className="space-y-4">
      <div>
        <h2 className="font-heading text-xl font-bold text-foreground mb-1">المسبحة الإلكترونية</h2>
        <p className="text-sm text-muted-foreground">اذكر الله وسبّح بحمده</p>
      </div>

      {/* Dhikr selector */}
      <div className="flex gap-2 overflow-x-auto pb-3 -mx-4 px-4 scrollbar-hide">
        {DHIKR_PRESETS.map((d, i) => (
          <button
            key={i}
            onClick={() => selectDhikr(i)}
            className={`shrink-0 px-4 py-2.5 text-sm font-medium transition-all whitespace-nowrap font-quran ${
              selectedIdx === i
                ? 'bg-emerald-600 dark:bg-emerald-500 text-white'
                : 'glass-blur text-muted-foreground hover:text-foreground'
            }`}
            style={{ borderRadius: 20 }}
          >
            {d.text}
          </button>
        ))}
      </div>

      {/* Counter card */}
      <div ref={glassRef} className="glass p-6 text-center">
        <p className="font-quran text-2xl text-foreground mb-1">{current.text}</p>
        <p className="text-xs text-muted-foreground mb-4">الهدف: {current.target} مرة</p>

        {/* Progress ring */}
        <div className="relative w-48 h-48 mx-auto mb-5">
          <svg className="w-full h-full -rotate-90" viewBox="0 0 200 200">
            <circle cx="100" cy="100" r="90" fill="none" stroke="rgba(128,128,128,0.15)" strokeWidth="6" />
            <circle
              cx="100" cy="100" r="90" fill="none"
              stroke="currentColor"
              strokeWidth="6"
              strokeLinecap="round"
              className="text-emerald-600 dark:text-emerald-400"
              strokeDasharray={circumference}
              strokeDashoffset={circumference * (1 - progress)}
              style={{ transition: 'stroke-dashoffset 0.3s ease' }}
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className="font-heading text-5xl font-bold text-foreground">{count}</span>
            <span className="text-xs text-muted-foreground mt-1">من {current.target}</span>
          </div>
        </div>

        {/* Tap button */}
        <button
          onClick={increment}
          disabled={count >= current.target}
          className="glass-blur w-full py-6 font-heading text-lg font-bold text-emerald-600 dark:text-emerald-400 active:scale-95 transition-transform select-none disabled:opacity-50"
          style={{ borderRadius: 28 }}
        >
          اضغط للتسبيح
        </button>

        <button
          onClick={reset}
          className="w-full mt-2 py-2.5 flex items-center justify-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
        >
          <RotateCcw size={16} />
          <span>إعادة العد</span>
        </button>
      </div>

      {completed && (
        <div className="glass-blur p-4 text-center" style={{ borderRadius: 28 }}>
          <div className="flex items-center justify-center gap-2 mb-2">
            <Check size={20} className="text-emerald-600 dark:text-emerald-400" />
            <p className="font-heading text-base text-emerald-600 dark:text-emerald-400">
              أكملت التسبيح، تقبّل الله منك
            </p>
          </div>
          <button
            onClick={reset}
            className="mt-1 text-sm text-emerald-600 dark:text-emerald-400 underline"
          >
            ابدأ من جديد
          </button>
        </div>
      )}
    </div>
  );
}