import { CloudRain, Wind, Moon, Waves, Volume2 } from 'lucide-react';
import { t } from '@/lib/i18n';

const SOUNDS = [
  { id: 'rain', icon: CloudRain },
  { id: 'ac', icon: Wind },
  { id: 'night', icon: Moon },
  { id: 'ocean', icon: Waves },
];

export default function AmbientSoundPlayer({ sound, onChange, lang = 'ar' }) {
  return (
    <div className="grid grid-cols-5 gap-2">
      <button onClick={() => onChange('none')} aria-pressed={sound === 'none'}
        className={`p-3 flex flex-col items-center gap-1.5 transition-all active:scale-95 ${sound === 'none' ? 'bg-foreground/10 text-foreground' : 'bg-foreground/5 text-muted-foreground'}`}
        style={{ borderRadius: 16 }}>
        <Volume2 size={18} />
        <span className="text-[10px]">{t(lang, 'sounds', 'none')}</span>
      </button>
      {SOUNDS.map(({ id, icon: Icon }) => (
        <button key={id} onClick={() => onChange(id)} aria-pressed={sound === id}
          className={`p-3 flex flex-col items-center gap-1.5 transition-all active:scale-95 ${sound === id ? 'bg-primary/20 text-primary border-2 border-primary' : 'bg-foreground/5 text-muted-foreground border-2 border-transparent'}`}
          style={{ borderRadius: 16 }}>
          <Icon size={18} />
          <span className="text-[10px]">{t(lang, 'sounds', id)}</span>
        </button>
      ))}
    </div>
  );
}