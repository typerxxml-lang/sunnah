import { useState, useEffect } from 'react';
import { useGlassEffect } from '@/hooks/useGlassEffect';
import { usePrayerTimes } from '@/hooks/usePrayerTimes';
import { Clock, Loader2, Navigation } from 'lucide-react';
import { formatHM, formatDate } from '@/lib/time';

const PRAYER_NAMES = {
  Fajr: 'الفجر',
  Sunrise: 'الشروق',
  Dhuhr: 'الظهر',
  Asr: 'العصر',
  Maghrib: 'المغرب',
  Isha: 'العشاء',
};

const PRAYER_ORDER = ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];

export default function PrayerTimes({ timeFormat = '12' }) {
  const { times, loading, error } = usePrayerTimes();
  const [now, setNow] = useState(new Date());
  const glassRef = useGlassEffect(48, 26, 44);

  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 60000);
    return () => clearInterval(timer);
  }, []);

  const { currentPrayer, nextPrayer, timeRemaining } = (() => {
    if (!times) return { currentPrayer: null, nextPrayer: null, timeRemaining: null };

    const nowMinutes = now.getHours() * 60 + now.getMinutes();
    const prayerMinutes = {};
    PRAYER_ORDER.forEach(p => {
      const [h, m] = times[p].split(':').map(Number);
      prayerMinutes[p] = h * 60 + m;
    });

    for (let i = 0; i < PRAYER_ORDER.length; i++) {
      const p = PRAYER_ORDER[i];
      const nextP = PRAYER_ORDER[(i + 1) % PRAYER_ORDER.length];
      let nextTime = prayerMinutes[nextP];
      if (nextTime < prayerMinutes[p]) nextTime += 24 * 60;

      if (nowMinutes >= prayerMinutes[p] && nowMinutes < nextTime) {
        const remaining = nextTime - nowMinutes;
        const hours = Math.floor(remaining / 60);
        const mins = remaining % 60;
        return {
          currentPrayer: p,
          nextPrayer: nextP,
          timeRemaining: `${hours > 0 ? hours + ' س ' : ''}${mins} د`,
        };
      }
    }

    // Before Fajr
    const fajrTomorrow = prayerMinutes['Fajr'] + 24 * 60;
    const remaining = fajrTomorrow - nowMinutes;
    const hours = Math.floor(remaining / 60);
    const mins = remaining % 60;
    return {
      currentPrayer: 'Isha',
      nextPrayer: 'Fajr',
      timeRemaining: `${hours > 0 ? hours + ' س ' : ''}${mins} د`,
    };
  })();

  if (loading) {
    return (
      <div ref={glassRef} className="glass p-5 flex items-center justify-center gap-2">
        <Loader2 size={20} className="animate-spin text-emerald-600 dark:text-emerald-400" />
        <span className="text-sm text-muted-foreground">جارٍ تحديد مواقيت الصلاة...</span>
      </div>
    );
  }

  if (error) {
    return (
      <div ref={glassRef} className="glass p-5 text-center">
        <Navigation size={24} className="mx-auto text-muted-foreground mb-2" />
        <p className="text-sm text-muted-foreground">{error}</p>
      </div>
    );
  }

  const timeStr = formatDate(now, timeFormat);

  return (
    <div ref={glassRef} className="glass p-5">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Clock size={20} className="text-emerald-600 dark:text-emerald-400" />
          <h3 className="font-heading text-base font-bold text-foreground">مواقيت الصلاة</h3>
        </div>
        <div className="text-left">
          <p className="text-xs text-muted-foreground">الوقت الآن</p>
          <p className="font-heading text-sm font-bold text-foreground">{timeStr}</p>
        </div>
      </div>

      {currentPrayer && (
        <div className="mb-3">
          <div className="flex items-center justify-between mb-2">
            <span className="badge text-xs text-emerald-700 dark:text-emerald-300 bg-emerald-500/15 border-transparent">
              وقت {PRAYER_NAMES[currentPrayer]}
            </span>
            {nextPrayer && timeRemaining && (
              <span className="text-xs text-muted-foreground">
                الصلاة القادمة: <span className="font-bold text-emerald-600 dark:text-emerald-400">{PRAYER_NAMES[nextPrayer]}</span> بعد {timeRemaining}
              </span>
            )}
          </div>
        </div>
      )}

      <div className="grid grid-cols-5 gap-2">
        {PRAYER_ORDER.map(p => {
          const isCurrent = p === currentPrayer;
          return (
            <div
              key={p}
              className={`text-center py-2.5 px-1 transition-all ${
                isCurrent
                  ? 'bg-emerald-500/20'
                  : 'bg-foreground/5'
              }`}
              style={{ borderRadius: 24 }}
            >
              <p className={`text-[10px] font-medium mb-0.5 ${isCurrent ? 'text-emerald-600 dark:text-emerald-400' : 'text-muted-foreground'}`}>
                {PRAYER_NAMES[p]}
              </p>
              <p className={`text-xs font-bold ${isCurrent ? 'text-emerald-600 dark:text-emerald-400' : 'text-foreground'}`}>
                {formatHM(times[p], timeFormat)}
              </p>
            </div>
          );
        })}
      </div>
    </div>
  );
}