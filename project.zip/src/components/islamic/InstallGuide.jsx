import { useState } from 'react';
import { X, Download, Smartphone, Monitor, Apple, Share, PlusSquare, MoreVertical, ArrowDownToLine, CheckCircle2, Hand, Globe, Sparkles } from 'lucide-react';

const PLATFORMS = [
  { id: 'android', label: 'أندرويد', Icon: Smartphone },
  { id: 'ios', label: 'iPhone / iPad', Icon: Apple },
  { id: 'windows', label: 'Windows', Icon: Monitor },
  { id: 'mac', label: 'Mac', Icon: Monitor },
];

const STEPS = {
  android: [
    { Icon: Globe, title: 'افتح نافعاً في Chrome', detail: 'استخدم متصفح Google Chrome وافتح موقع نافعاً.' },
    { Icon: Download, title: 'اضغط «تثبيت التطبيق»', detail: 'إذا ظهر زر التثبيت داخل الموقع، اضغطه ثم وافق على التثبيت.' },
    { Icon: MoreVertical, title: 'أو من قائمة ⋮', detail: 'اختر «تثبيت التطبيق» أو «إضافة إلى الشاشة الرئيسية»، ثم اضغط تثبيت.' },
  ],
  ios: [
    { Icon: Globe, title: 'افتح الموقع في Safari', detail: 'على iPhone أو iPad افتح نافعاً في متصفح Safari.' },
    { Icon: Share, title: 'اضغط زر المشاركة', detail: 'أيقونة المربع والسهم للأعلى في شريط المتصفح.' },
    { Icon: PlusSquare, title: 'إضافة إلى الشاشة الرئيسية', detail: 'اختر «إضافة إلى الشاشة الرئيسية» ثم اضغط «إضافة».' },
  ],
  windows: [
    { Icon: Globe, title: 'افتح نافعاً في Chrome أو Edge', detail: 'استخدم أحدث إصدار من المتصفح وافتح الموقع.' },
    { Icon: Download, title: 'ابحث عن خيار التثبيت', detail: 'في Chrome: قائمة ⋮ ثم «تثبيت الصفحة كتطبيق». وفي Edge: قائمة التطبيقات ثم «تثبيت هذا الموقع كتطبيق».' },
    { Icon: CheckCircle2, title: 'ثبّت وافتح التطبيق', detail: 'وافق على النافذة التي تظهر، وستجده في قائمة التطبيقات.' },
  ],
  mac: [
    { Icon: Globe, title: 'افتح نافعاً في المتصفح', detail: 'يمكنك استخدام Chrome أو Edge، أو Safari في إصدارات macOS الحديثة.' },
    { Icon: Download, title: 'اختر التثبيت أو الإضافة إلى Dock', detail: 'في Chrome: قائمة ⋮ ثم خيار تثبيت الصفحة كتطبيق. وفي Safari المدعوم: File ثم Add to Dock.' },
    { Icon: CheckCircle2, title: 'افتح نافعاً كالتطبيق', detail: 'ستتمكن من تشغيله من Dock أو قائمة التطبيقات دون البحث عنه كل مرة.' },
  ],
};

function detectPlatform() {
  if (typeof navigator === 'undefined') return 'android';
  const ua = navigator.userAgent || '';
  if (/iPhone|iPad|iPod/i.test(ua)) return 'ios';
  if (/Macintosh|Mac OS X/i.test(ua)) return 'mac';
  if (/Windows/i.test(ua)) return 'windows';
  return 'android';
}

export function InstallAppButton({ onClick, compact = false, className = '' }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label="تثبيت تطبيق نافعاً"
      className={`flex items-center justify-center gap-2 rounded-full border border-primary/25 bg-primary/10 text-primary hover:bg-primary/15 active:scale-[0.98] transition-all ${compact ? 'p-2.5' : 'w-full px-4 py-3 text-sm font-bold'} ${className}`}
    >
      <Download size={compact ? 18 : 17} />
      {!compact && <span>تثبيت التطبيق على جهازك</span>}
    </button>
  );
}

export default function InstallGuide({ open, onClose, installPrompt, onInstall }) {
  const [platform, setPlatform] = useState(detectPlatform);
  if (!open) return null;
  const current = PLATFORMS.find(item => item.id === platform) || PLATFORMS[0];
  const steps = STEPS[platform];

  return (
    <div
      className="fixed inset-0 z-[80] flex items-end sm:items-center justify-center bg-black/60 p-3 sm:p-5 install-modal-enter"
      onMouseDown={event => { if (event.target === event.currentTarget) onClose(); }}
    >
      <section role="dialog" aria-modal="true" aria-labelledby="install-guide-title" className="glass w-full max-w-lg max-h-[92dvh] overflow-y-auto p-5 sm:p-6 relative">
        <button type="button" onClick={onClose} aria-label="إغلاق" className="absolute top-3 left-3 rounded-full p-2 hover:bg-foreground/10 transition-colors">
          <X size={19} />
        </button>
        <div className="text-center pt-2">
          <div className="install-orbit mx-auto mb-3 flex h-16 w-16 items-center justify-center rounded-3xl bg-primary/10 text-primary">
            <Download size={30} className="install-download-bob" />
            <Sparkles size={14} className="install-sparkle" />
          </div>
          <h2 id="install-guide-title" className="font-heading text-2xl font-bold text-foreground">خلّ نافعاً معك دائماً</h2>
          <p className="mt-1 text-sm leading-relaxed text-muted-foreground">ثبّت التطبيق على جهازك للوصول إليه بسرعة من الشاشة الرئيسية أو قائمة التطبيقات.</p>
        </div>

        {installPrompt && (
          <button type="button" onClick={onInstall} className="mt-4 w-full rounded-2xl bg-primary px-4 py-3 text-sm font-bold text-primary-foreground flex items-center justify-center gap-2 hover:brightness-110 active:scale-[0.99] transition-all">
            <Download size={17} /> تثبيت نافعاً الآن
          </button>
        )}

        <div className="mt-5 grid grid-cols-2 gap-2">
          {PLATFORMS.map(({ id, label, Icon }) => (
            <button
              type="button"
              key={id}
              onClick={() => setPlatform(id)}
              className={`flex items-center justify-center gap-2 rounded-2xl px-3 py-3 text-sm font-bold transition-all ${platform === id ? 'bg-primary text-primary-foreground shadow-lg shadow-primary/15' : 'bg-foreground/5 text-muted-foreground hover:bg-foreground/10'}`}
              aria-pressed={platform === id}
            >
              <Icon size={17} /> {label}
            </button>
          ))}
        </div>

        <div className="mt-4 rounded-3xl border border-foreground/10 bg-foreground/[0.025] p-4">
          <div className="mb-4 flex items-center gap-2 text-sm font-bold text-foreground">
            <current.Icon size={18} className="text-primary" />
            طريقة التثبيت على {current.label}
          </div>
          <div className="space-y-3">
            {steps.map(({ Icon, title, detail }, index) => (
              <div key={`${platform}-${title}`} className="install-step-enter flex items-start gap-3" style={{ animationDelay: `${index * 130}ms` }}>
                <div className="install-step-icon relative flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-primary/10 text-primary">
                  <Icon size={20} />
                  <span className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-primary text-[10px] font-bold text-primary-foreground">{index + 1}</span>
                </div>
                <div className="min-w-0 flex-1 pt-0.5">
                  <p className="text-sm font-bold text-foreground">{title}</p>
                  <p className="mt-1 text-xs leading-relaxed text-muted-foreground">{detail}</p>
                </div>
                {index < steps.length - 1 && <ArrowDownToLine size={14} className="hidden text-primary/50 sm:block" />}
              </div>
            ))}
          </div>
          <div className="mt-4 flex items-start gap-2 rounded-2xl bg-primary/5 p-3 text-xs leading-relaxed text-muted-foreground">
            <Hand size={16} className="mt-0.5 shrink-0 text-primary install-hand" />
            <span>التثبيت مجاني. إذا لم يظهر خيار التثبيت، افتح قائمة المتصفح وابحث عن «إضافة إلى الشاشة الرئيسية» أو «تثبيت التطبيق».</span>
          </div>
        </div>
        <button type="button" onClick={onClose} className="mt-4 w-full rounded-2xl bg-foreground/5 py-3 text-sm font-bold text-foreground hover:bg-foreground/10 transition-colors">فهمت</button>
      </section>
    </div>
  );
}
