import { useState } from 'react';
import { PartyPopper, Sparkles, Crown } from 'lucide-react';
import { useLaunchPromo, daysLeftText } from '@/hooks/useLaunchPromo';
import { loadString, saveString } from '@/lib/storage';
import ManagementModal from '@/components/islamic/ManagementModal';

const WELCOME_KEY = 'iq-launch-welcome-seen';
const THANKS_KEY = 'iq-launch-thanks-seen';

// شريط صغير أعلى الرئيسية يوضح أن PLUS مفتوح بمناسبة الافتتاح
export function LaunchBanner({ onOpenPlus }) {
  const { active, daysLeft } = useLaunchPromo();
  if (!active) return null;
  return (
    <button type="button" onClick={onOpenPlus} className="glass bg-amber-500/10 w-full flex items-center gap-3 p-3 mb-4 text-right">
      <PartyPopper size={22} className="text-amber-500 shrink-0" />
      <div className="flex-1">
        <p className="text-sm font-bold text-foreground">🎉 مبروك افتتاح نافعاً! PLUS مفتوح لك مجاناً</p>
        <p className="text-[11px] text-muted-foreground">احتفالاً بالافتتاح · {daysLeftText(daysLeft)}</p>
      </div>
    </button>
  );
}

// رسالة التهنئة (مرة واحدة) أثناء العرض، ورسالة شكر (مرة واحدة) بعد انتهائه
export function LaunchDialogs({ ready }) {
  const { active, daysLeft } = useLaunchPromo();
  const [welcomeSeen, setWelcomeSeen] = useState(() => loadString(WELCOME_KEY, '0') === '1');
  const [thanksSeen, setThanksSeen] = useState(() => loadString(THANKS_KEY, '0') === '1');
  if (!ready) return null;

  if (active && !welcomeSeen) {
    const close = () => { saveString(WELCOME_KEY, '1'); setWelcomeSeen(true); };
    return (
      <ManagementModal title="مبروك الافتتاح 🎉" Icon={PartyPopper} onClose={close}>
        <div className="text-center space-y-3" role="status">
          <Crown size={46} className="text-amber-500 mx-auto" />
          <p className="text-lg font-bold text-foreground">أهلاً بك في نافعاً</p>
          <p className="text-sm text-muted-foreground leading-7">
            يسعدنا أن تكون معنا في يوم الافتتاح. احتفالاً بهذه المناسبة فتحنا لك <b className="text-foreground">PLUS كامل مجاناً</b> لمدة 7 أيام: كل الثيمات والخطوط والأصوات المحيطة وتأثيرات الزجاج، بدون أي كود أو دفع.
          </p>
          <p className="text-sm text-primary font-bold">{daysLeftText(daysLeft)} · نسأل الله أن يجعله نافعاً لنا ولكم 🤍</p>
          <button type="button" onClick={close} className="w-full rounded-2xl bg-primary text-primary-foreground py-3 font-bold">ابدأ الاحتفال</button>
        </div>
      </ManagementModal>
    );
  }

  if (!active && welcomeSeen && !thanksSeen) {
    const close = () => { saveString(THANKS_KEY, '1'); setThanksSeen(true); };
    return (
      <ManagementModal title="شكراً لك" Icon={Sparkles} onClose={close}>
        <div className="text-center space-y-3" role="status">
          <p className="text-sm text-muted-foreground leading-7">
            انتهت أيام احتفال الافتتاح. شكراً لأنك كنت معنا من أول يوم، ونتمنى أن تكون استفدت من مميزات PLUS. التطبيق باقٍ بكل ما فيه من سنن وأذكار، وPLUS يرجع بالمناسبات القادمة بإذن الله.
          </p>
          <button type="button" onClick={close} className="w-full rounded-2xl bg-primary text-primary-foreground py-3 font-bold">جزاك الله خيراً</button>
        </div>
      </ManagementModal>
    );
  }
  return null;
}
