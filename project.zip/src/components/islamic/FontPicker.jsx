import { FONTS } from '@/data/fonts';
import { Check, Lock } from 'lucide-react';

export default function FontPicker({ fontId, isPlusActive, onChange, onOpenPlus, lang = 'ar' }) {
  return (
    <div>
      <div className="grid grid-cols-2 gap-2 max-h-72 overflow-y-auto scrollbar-hide">
        {FONTS.map(font => {
          const locked = !isPlusActive && font.id !== 'amiri';
          const selected = fontId === font.id;
          return (
            <button
              key={font.id}
              onClick={() => locked ? onOpenPlus?.() : onChange(font.id)}
              aria-pressed={selected}
              className={`p-3 text-center transition-all active:scale-95 ${selected ? 'bg-primary/20 text-foreground border-2 border-primary' : 'bg-foreground/5 text-muted-foreground border-2 border-transparent'}`}
              style={{ borderRadius: 18 }}
            >
              <p className="text-base leading-snug" style={{ fontFamily: font.family }}>{font.sample}</p>
              <p className="text-[10px] mt-1">{lang === 'ar' ? font.name : font.nameEn}</p>
              {locked && <Lock size={11} className="inline-block mt-1 text-muted-foreground" />}
              {selected && <Check size={11} className="inline-block mt-1 text-primary" />}
            </button>
          );
        })}
      </div>
      {!isPlusActive && (
        <button onClick={onOpenPlus} className="mt-3 w-full text-xs text-primary text-center">
          فعّل PLUS لفتح كل الخطوط
        </button>
      )}
    </div>
  );
}