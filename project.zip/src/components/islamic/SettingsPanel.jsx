import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Sun, Moon, Bell, BellRing, Eye, ScrollText, User, LogOut, FileText, ChevronLeft, BellOff, Crown, Shield, NotebookPen, Layers } from 'lucide-react';
import { useGlassEffect } from '@/hooks/useGlassEffect';
import { LogIn as SignInIcon } from 'lucide-react';
import ThemePicker from '@/components/islamic/ThemePicker';
import FontPicker from '@/components/islamic/FontPicker';
import GlassStylePicker from '@/components/islamic/GlassStylePicker';
import AmbientSoundPlayer from '@/components/islamic/AmbientSoundPlayer';
import WidgetVisibilityPicker from '@/components/islamic/WidgetVisibilityPicker';
import ProfileEditor from '@/components/islamic/ProfileEditor';
import PlusBadge from '@/components/islamic/PlusBadge';

export default function SettingsPanel({ settings, update, theme, onToggleTheme, user, onLogout, onNavigate, onRequestNotifications, notificationStatus, isPlusActive, adminUnlocked, themeId, onThemeIdChange, onOpenPlus, onOpenAdmin, onOpenNotes, onProfileUpdated }) {
  const glassRef = useGlassEffect(30, 24, 42);
  const notificationsEnabled = notificationStatus === 'granted';
  const lang = settings.language || 'ar';

  return (
    <div className="space-y-4">
      {/* User card */}
      <div ref={glassRef} className="glass p-5">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-primary/15 flex items-center justify-center shrink-0 overflow-hidden">
            {user?.avatar_uri ? <AvatarImage uri={user.avatar_uri} /> : <User size={24} className="text-primary" />}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1.5">
              <p className="font-heading font-bold text-foreground truncate">{user?.name || 'زائر'}</p>
              {isPlusActive && <PlusBadge size={12} />}
            </div>
            <p className="text-xs text-muted-foreground">
              {user?.isReal ? 'عضو مسجّل' : user?.isGuest ? 'وضع الضيف' : 'زائر'}
            </p>
          </div>
          {user && (
            <button onClick={onLogout} className="p-2 rounded-full hover:bg-foreground/10 transition-colors">
              <LogOut size={18} className="text-muted-foreground" />
            </button>
          )}
        </div>
        {user?.isReal ? (
          <div className="mt-4">
            <ProfileEditor user={user} onUpdated={onProfileUpdated} />
          </div>
        ) : (
          <button onClick={onLogout} className="mt-4 w-full py-2.5 flex items-center justify-center gap-2 rounded-2xl bg-primary text-primary-foreground text-sm font-bold active:scale-[0.98] transition-transform">
            <SignInIcon size={16} /> تسجيل الدخول باسمك
          </button>
        )}
      </div>

      {/* PLUS */}
      <SettingCard title="اشتراك PLUS">
        <button onClick={onOpenPlus} className="w-full flex items-center gap-3 p-3 bg-amber-500/10 hover:bg-amber-500/15 transition-colors" style={{ borderRadius: 18 }}>
          <Crown size={20} className="text-amber-500 shrink-0" />
          <div className="flex-1 text-right">
            <p className="text-sm font-bold text-foreground">{isPlusActive ? 'PLUS مفعّل دائماً' : 'فعّل اشتراك PLUS'}</p>
            <p className="text-[10px] text-muted-foreground">{isPlusActive ? 'دائم حتى إلغاء المطور' : 'ثيمات حصرية ومميزات إضافية'}</p>
          </div>
          <ChevronLeft size={16} className="text-muted-foreground" />
        </button>
      </SettingCard>

      {/* Language */}
      <SettingCard title="اللغة / Language">
        <div className="grid grid-cols-2 gap-2">
          {[['ar', 'العربية'], ['en', 'English']].map(([v, label]) => (
            <button key={v} onClick={() => update({ language: v })} className={`py-3 text-sm font-medium transition-all active:scale-95 ${lang === v ? 'bg-primary text-primary-foreground' : 'bg-foreground/5 text-muted-foreground'}`} style={{ borderRadius: 26 }}>{label}</button>
          ))}
        </div>
      </SettingCard>

      {/* Appearance */}
      <SettingCard title="المظهر">
        <Row Icon={theme === 'dark' ? Moon : Sun} label="الوضع الداكن">
          <Toggle on={theme === 'dark'} onToggle={onToggleTheme} />
        </Row>
        <div className="my-3" />
        <div className="mb-2">
          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
            <Layers size={16} /><span>نمط الزجاج</span>
            {!isPlusActive && <Lock onOpenPlus={onOpenPlus} />}
          </div>
          {isPlusActive ? <GlassStylePicker glassStyle={settings.glassStyle} onChange={v => update({ glassStyle: v })} lang={lang} />
            : <LockedBox onOpenPlus={onOpenPlus} text="فعّل PLUS لتغيير نمط الزجاج" />}
        </div>
      </SettingCard>

      {/* Themes */}
      <SettingCard title="الثيمات">
        <ThemePicker theme={theme} themeId={themeId} isPlusActive={isPlusActive} onChange={onThemeIdChange} onOpenPlus={onOpenPlus} />
      </SettingCard>

      {/* Fonts */}
      <SettingCard title="الخطوط">
        <FontPicker fontId={settings.fontFamily} isPlusActive={isPlusActive} onChange={v => update({ fontFamily: v })} onOpenPlus={onOpenPlus} lang={lang} />
        <div className="mt-4 pt-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-muted-foreground">حجم النص</span>
            <span className="text-sm font-bold text-foreground">{Math.round(settings.fontScale * 100)}%</span>
          </div>
          <input type="range" min="0.85" max="1.4" step="0.05" value={settings.fontScale} onChange={e => update({ fontScale: parseFloat(e.target.value) })} className="w-full accent-primary" />
        </div>
      </SettingCard>

      {/* Ambient sounds */}
      <SettingCard title="الأصوات المحيطة">
        <div className="mb-2">
          {!isPlusActive ? <LockedBox onOpenPlus={onOpenPlus} text="فعّل PLUS للاستماع للأصوات المحيطة" />
            : <AmbientSoundPlayer sound={settings.ambientSound} onChange={v => update({ ambientSound: v })} lang={lang} />}
        </div>
      </SettingCard>

      {/* Widget visibility */}
      <SettingCard title="إظهار وإخفاء الودجات">
        <WidgetVisibilityPicker hiddenWidgets={settings.hiddenWidgets} onChange={v => update({ hiddenWidgets: v })} lang={lang} />
      </SettingCard>

      {/* Time format */}
      <SettingCard title="تنسيق الوقت">
        <div className="grid grid-cols-2 gap-2">
          {[['12', '١٢ ساعة (٣:٣٠ م)'], ['24', '٢٤ ساعة (15:30)']].map(([v, label]) => (
            <button key={v} onClick={() => update({ timeFormat: v })} className={`py-3 text-sm font-medium transition-all active:scale-95 ${settings.timeFormat === v ? 'bg-primary text-primary-foreground' : 'bg-foreground/5 text-muted-foreground'}`} style={{ borderRadius: 26 }}>{label}</button>
          ))}
        </div>
      </SettingCard>

      {/* Notifications */}
      <SettingCard title="التنبيهات">
        <Row Icon={notificationsEnabled ? BellRing : BellOff} label="تنبيهات السنن اليومية">
          <button onClick={onRequestNotifications} disabled={notificationsEnabled} className={`px-4 py-1.5 rounded-full text-xs font-medium transition-all ${notificationsEnabled ? 'bg-primary/15 text-primary' : 'bg-primary text-primary-foreground'}`}>{notificationsEnabled ? 'مفعّل' : 'تفعيل'}</button>
        </Row>
        <div className="my-3" />
        <Row Icon={Bell} label="الإشعارات العامة">
          <Toggle on={settings.notifications} onToggle={() => update({ notifications: !settings.notifications })} />
        </Row>
      </SettingCard>

      {/* Display options */}
      <SettingCard title="خيارات العرض">
        <Row Icon={ScrollText} label="إظهار التصنيف الفقهي">
          <Toggle on={settings.showClassification} onToggle={() => update({ showClassification: !settings.showClassification })} />
        </Row>
        <div className="my-3" />
        <Row Icon={Eye} label="إظهار درجة الصحة">
          <Toggle on={settings.showAuthenticity} onToggle={() => update({ showAuthenticity: !settings.showAuthenticity })} />
        </Row>
      </SettingCard>

      {/* Personal spaces */}
      <SettingCard title="مساحاتي">
        <button onClick={onOpenNotes} className="flex items-center justify-between w-full">
          <div className="flex items-center gap-2.5"><NotebookPen size={18} className="text-primary" /><span className="text-sm text-foreground">مساحاتي الخاصة</span></div>
          <ChevronLeft size={16} className="text-muted-foreground" />
        </button>
      </SettingCard>

      {/* Admin */}
      <SettingCard title="الإدارة">
        <button onClick={onOpenAdmin} className="flex items-center justify-between w-full">
          <div className="flex items-center gap-2.5"><Shield size={18} className={adminUnlocked ? 'text-primary' : 'text-muted-foreground'} /><span className="text-sm text-foreground">لوحة المشرف/المطور</span></div>
          <ChevronLeft size={16} className="text-muted-foreground" />
        </button>
      </SettingCard>

      {/* About */}
      <SettingCard title="عن التطبيق">
        <button onClick={() => onNavigate('terms')} className="flex items-center justify-between w-full">
          <div className="flex items-center gap-2.5"><FileText size={18} className="text-muted-foreground" /><span className="text-sm text-foreground">الشروط والأحكام</span></div>
          <ChevronLeft size={16} className="text-muted-foreground" />
        </button>
      </SettingCard>
    </div>
  );
}

function AvatarImage({ uri }) {
  const [url, setUrl] = useState(null);
  useEffect(() => {
    base44.integrations.Core.CreateFileSignedUrl({ file_uri: uri, expires_in: 3600 }).then(r => setUrl(r.signed_url)).catch(() => {});
  }, [uri]);
  return url ? <img src={url} alt="صورة" className="w-full h-full object-cover" /> : <User size={24} className="text-primary" />;
}

function Lock({ onOpenPlus }) { return <button onClick={onOpenPlus} className="text-[10px] bg-amber-500/15 text-amber-600 dark:text-amber-400 px-2 py-0.5 rounded-full">PLUS</button>; }
function LockedBox({ onOpenPlus, text }) { return <button onClick={onOpenPlus} className="w-full p-4 rounded-2xl bg-foreground/5 text-center text-xs text-muted-foreground">{text}</button>; }

function SettingCard({ title, children }) {
  const ref = useGlassEffect(28, 22, 38);
  return (<div ref={ref} className="glass p-5"><h3 className="font-heading text-sm font-bold text-foreground mb-4">{title}</h3>{children}</div>);
}
function Row({ Icon, label, children }) {
  return (<div className="flex items-center justify-between"><div className="flex items-center gap-2.5"><Icon size={18} className="text-muted-foreground" /><span className="text-sm text-foreground">{label}</span></div>{children}</div>);
}
function Toggle({ on, onToggle }) {
  return (<button onClick={onToggle} className={`w-12 h-7 rounded-full p-1 transition-colors duration-300 ${on ? 'bg-primary' : 'bg-foreground/20'}`} aria-pressed={on}><div className={`w-5 h-5 rounded-full bg-white shadow-md transition-transform duration-300 ${on ? 'translate-x-0' : 'translate-x-5'}`} /></button>);
}