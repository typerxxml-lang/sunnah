import { Checkbox } from '@/components/ui/checkbox';
import { TERMS } from '@/data/terms';
import { setTermsAccepted } from '@/lib/terms';

/** صندوق الشروط والبنود مع خانة الموافقة */
export default function TermsConsent({ checked, onChange }) {
  const toggle = (v) => {
    setTermsAccepted(v);
    onChange(v);
  };

  return (
    <div className="text-right">
      <p className="font-heading text-sm font-bold text-foreground mb-2">الشروط والبنود</p>
      <div className="max-h-44 overflow-y-auto rounded-2xl bg-foreground/5 p-3 space-y-2.5">
        {TERMS.map((t) => (
          <div key={t.title}>
            <p className="text-xs font-bold text-foreground">{t.title}</p>
            <p className="text-[11px] text-muted-foreground leading-relaxed">{t.text}</p>
          </div>
        ))}
      </div>
      <label className="flex items-center gap-2 mt-3 cursor-pointer">
        <Checkbox checked={checked} onCheckedChange={(v) => toggle(v === true)} />
        <span className="text-sm text-foreground">أوافق على الشروط والبنود التي قرأتها</span>
      </label>
    </div>
  );
}