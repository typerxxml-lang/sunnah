import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useGlassEffect } from '@/hooks/useGlassEffect';
import { sunan } from '@/data/sunan';
import { hadiths } from '@/data/hadiths';
import { quranVerses } from '@/data/quran';
import { dayOfYear } from '@/lib/time';
import SunnahCard from './SunnahCard';
import PrayerTimes from './PrayerTimes';
import WidgetGrid from '@/components/islamic/widgets/WidgetGrid';
import { ArchIcon, LightIcon } from './DecorativeSvg';
import { Star, ChevronLeft, Share2, Megaphone } from 'lucide-react';
import { shareContent } from '@/lib/share';

export default function HomeView({ onSelectSunnah, isFavorite, onToggleFavorite, favorites, onNavigate, settings }) {
  const heroRef = useGlassEffect(48, 26, 46);
  const dailyRef = useGlassEffect(44, 24, 42);
  const [ownerNotes, setOwnerNotes] = useState([]);

  useEffect(() => {
    base44.entities.CustomContent.filter({ type: 'note', show_on_home: true, active: true }, { sort: '-created_date', limit: 10 })
      .then(({ items }) => setOwnerNotes(items))
      .catch(() => {});
  }, []);

  const dailySunnah = sunan[dayOfYear() % sunan.length];
  const favoriteSunan = favorites.map(id => sunan.find(s => s.id === id)).filter(Boolean).slice(0, 4);

  return (
    <div className="space-y-5 stagger">
      <PrayerTimes timeFormat={settings.timeFormat} />

      {/* Owner notes */}
      {ownerNotes.map(note => (
        <div key={note.id} className="glass p-4 border-r-4 border-amber-500">
          <div className="flex items-center gap-2 mb-2">
            <Megaphone size={16} className="text-amber-500" />
            <span className="text-xs font-bold text-amber-600 dark:text-amber-400">تنويه من الإدارة</span>
          </div>
          <p className="font-heading text-sm font-bold text-foreground">{note.title}</p>
          <p className="text-sm text-foreground/80 mt-1 leading-relaxed whitespace-pre-wrap">{note.text}</p>
        </div>
      ))}

      {/* Hero */}
      <div ref={heroRef} className="glass p-6 text-center">
        <div className="flex justify-center mb-3 anim-pulse"><ArchIcon size={44} className="text-primary" /></div>
        <h2 className="font-heading text-2xl font-bold text-foreground leading-tight">نافعاً</h2>
        <p className="text-sm text-muted-foreground mt-1">Nafiahan · السنّة النبوية والقرآن والأذكار</p>
        <div className="flex justify-center gap-6 mt-5">
          <Stat value={sunan.length} label="سنة نبوية" />
          <div className="w-px bg-foreground/10" />
          <Stat value={hadiths.length} label="حديث شريف" />
          <div className="w-px bg-foreground/10" />
          <Stat value={quranVerses.length} label="آية قرآنية" />
        </div>
      </div>

      {/* سنة اليوم */}
      <div>
        <div className="flex items-center gap-2 mb-2 px-1">
          <LightIcon size={20} className="text-amber-500 dark:text-amber-400" />
          <h3 className="font-heading text-lg font-bold text-foreground">سنة اليوم</h3>
        </div>
        <div ref={dailyRef} onClick={() => onSelectSunnah(dailySunnah)} className="glass p-5 cursor-pointer transition-transform hover:scale-[1.01] active:scale-[0.98]">
          <div className="flex items-start justify-between gap-3">
            <h4 className="font-heading text-lg font-bold text-foreground flex-1 leading-snug">{dailySunnah.title}</h4>
            <div className="flex shrink-0">
              <button onClick={e => { e.stopPropagation(); shareContent(dailySunnah.title, dailySunnah.text); }} className="p-1.5 rounded-full hover:bg-foreground/10" aria-label="مشاركة"><Share2 size={17} className="text-muted-foreground" /></button>
              <button onClick={e => { e.stopPropagation(); onToggleFavorite(dailySunnah.id); }} className="p-1.5 rounded-full hover:bg-foreground/10" aria-label="المفضلة"><Star size={18} className={isFavorite(dailySunnah.id) ? 'fill-amber-400 text-amber-400' : 'text-muted-foreground'} /></button>
            </div>
          </div>
          <p className="font-heading text-base text-foreground/90 mt-2 leading-relaxed line-clamp-3">{dailySunnah.text}</p>
          <p className="text-xs text-muted-foreground mt-3">{dailySunnah.narrator} • {dailySunnah.reference}</p>
        </div>
      </div>

      <WidgetGrid settings={settings} onNavigate={onNavigate} hiddenWidgets={settings.hiddenWidgets} />

      {/* تنقل سريع */}
      <div className="grid grid-cols-3 gap-3">
        <QuickNav label="السنن" onClick={() => onNavigate('sunan')} />
        <QuickNav label="القرآن" onClick={() => onNavigate('quran')} />
        <QuickNav label="الأحاديث" onClick={() => onNavigate('hadiths')} />
      </div>

      {favoriteSunan.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-2 px-1">
            <div className="flex items-center gap-2"><Star size={18} className="fill-amber-400 text-amber-400" /><h3 className="font-heading text-lg font-bold text-foreground">مفضلاتي</h3></div>
            <button onClick={() => onNavigate('sunan')} className="text-xs text-primary flex items-center gap-0.5">عرض الكل <ChevronLeft size={14} /></button>
          </div>
          <div className="space-y-3 stagger">
            {favoriteSunan.map(s => <SunnahCard key={s.id} sunnah={s} onClick={() => onSelectSunnah(s)} isFavorite={true} onToggleFavorite={() => onToggleFavorite(s.id)} />)}
          </div>
        </div>
      )}
    </div>
  );
}

function Stat({ value, label }) {
  return (<div><p className="font-heading text-2xl font-bold text-primary">{value}</p><p className="text-[11px] text-muted-foreground">{label}</p></div>);
}
function QuickNav({ label, onClick }) {
  return (<button onClick={onClick} className="glass-blur py-4 text-center hover:scale-[1.03] active:scale-95 transition-transform"><span className="font-heading text-sm font-bold text-foreground">{label}</span></button>);
}