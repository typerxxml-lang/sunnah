import { Star } from 'lucide-react';

export default function PlusBadge({ size = 14 }) {
  return (
    <span className="inline-flex items-center justify-center rounded-full bg-amber-500/20 p-0.5" title="PLUS">
      <Star size={size} className="fill-amber-400 text-amber-400" />
    </span>
  );
}