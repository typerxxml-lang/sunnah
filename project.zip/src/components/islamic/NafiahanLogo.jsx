export default function NafiahanLogo({ size = 56, className = '' }) {
  return (
    <svg
      viewBox="0 0 100 100"
      width={size}
      height={size}
      className={className}
      role="img"
      aria-label="شعار نافعاً Nafiahan"
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        <linearGradient id="nafiahan-logo-bg" x1="10" y1="8" x2="90" y2="94" gradientUnits="userSpaceOnUse">
          <stop stopColor="#0F766E" />
          <stop offset="1" stopColor="#064E3B" />
        </linearGradient>
        <linearGradient id="nafiahan-logo-page" x1="27" y1="43" x2="75" y2="77" gradientUnits="userSpaceOnUse">
          <stop stopColor="#FFFFFF" />
          <stop offset="1" stopColor="#D1FAE5" />
        </linearGradient>
      </defs>
      <rect x="3" y="3" width="94" height="94" rx="29" fill="url(#nafiahan-logo-bg)" />
      <rect x="8" y="8" width="84" height="84" rx="25" stroke="#D1FAE5" strokeOpacity=".28" strokeWidth="1.5" />
      <circle cx="50" cy="40" r="20" fill="#FDE68A" fillOpacity=".16" />
      <path d="M60.8 23.6A16.7 16.7 0 1 0 76.2 48.2 18.8 18.8 0 1 1 60.8 23.6Z" fill="#FDE68A" />
      <path d="M50 17.5 53.1 25.2 61.2 25.6 54.9 30.9 56.9 38.7 50 34.2 43.1 38.7 45.1 30.9 38.8 25.6 46.9 25.2Z" fill="#FEF3C7" />
      <path d="M50 48.5C41.2 42.7 31.2 43.4 23 47.3V73.6C32.3 69.6 41.8 70.8 50 77.1C58.2 70.8 67.7 69.6 77 73.6V47.3C68.8 43.4 58.8 42.7 50 48.5Z" fill="url(#nafiahan-logo-page)" />
      <path d="M50 49V76.2" stroke="#047857" strokeWidth="2.1" strokeLinecap="round" />
      <path d="M29 53.5C35.2 51.5 41.1 52.4 45.8 55.1M29 60C35.2 58 41.1 58.9 45.8 61.6M71 53.5C64.8 51.5 58.9 52.4 54.2 55.1M71 60C64.8 58 58.9 58.9 54.2 61.6" fill="none" stroke="#059669" strokeWidth="1.8" strokeLinecap="round" />
      <path d="M20.5 78.5C29.6 74.9 40.8 76.8 50 83C59.2 76.8 70.4 74.9 79.5 78.5" fill="none" stroke="#A7F3D0" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}
