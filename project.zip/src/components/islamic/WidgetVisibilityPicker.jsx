import { WIDGETS } from '@/components/islamic/widgets/widgetRegistry';
import { Eye, EyeOff } from 'lucide-react';

export default function WidgetVisibilityPicker({ hiddenWidgets, onChange, lang = 'ar' }) {
  const toggle = (id) => {
    if (hiddenWidgets.includes(id)) onChange(hiddenWidgets.filter(w => w !== id));
    else onChange([...hiddenWidgets, id]);
  };
  return (
    <div className="grid grid-cols-2 gap-2 max-h-72 overflow-y-auto scrollbar-hide">
      {WIDGETS.map(w => {
        const hidden = hiddenWidgets.includes(w.id);
        return (
          <button
            key={w.id}
            onClick={() => toggle(w.id)}
            className={`flex items-center gap-2 p-2.5 transition-all active:scale-95 ${hidden ? 'bg-foreground/5 text-muted-foreground opacity-50' : 'bg-primary/10 text-foreground'}`}
            style={{ borderRadius: 14 }}
          >
            {hidden ? <EyeOff size={16} /> : <Eye size={16} />}
            <span className="text-xs truncate flex-1 text-right">{w.title}</span>
          </button>
        );
      })}
    </div>
  );
}