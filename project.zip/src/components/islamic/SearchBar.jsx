import { useState, useMemo, useEffect, useRef } from 'react';
import { Search, X } from 'lucide-react';
import { useGlassEffect } from '@/hooks/useGlassEffect';
import { sunan } from '@/data/sunan';
import { hadiths } from '@/data/hadiths';
import { quranVerses } from '@/data/quran';
import { getClassificationColor, getAuthenticityColor } from '@/lib/badges';
import { BookIcon, MosqueIcon, BeadsIcon } from './DecorativeSvg';

export default function SearchBar({ onClose, onSelectSunnah }) {
  const [query, setQuery] = useState('');
  const inputRef = useRef(null);
  const glassRef = useGlassEffect(28, 22, 40);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const results = useMemo(() => {
    const q = query.trim();
    if (!q) return null;
    return {
      sunan: sunan.filter(s => s.title.includes(q) || s.text.includes(q)).slice(0, 8),
      hadiths: hadiths.filter(h => h.title.includes(q) || h.text.includes(q)).slice(0, 5),
      quran: quranVerses.filter(v => v.text.includes(q) || v.meaning.includes(q) || v.surah.includes(q)).slice(0, 5),
    };
  }, [query]);

  const total = results ? results.sunan.length + results.hadiths.length + results.quran.length : 0;

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-black/40" onClick={onClose}>
      <div className="px-3 pt-3" onClick={(e) => e.stopPropagation()}>
        <div ref={glassRef} className="glass p-3">
          <div className="flex items-center gap-2">
            <Search size={20} className="text-muted-foreground shrink-0" />
            <input
              ref={inputRef}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="ابحث في السنن والأحاديث والآيات..."
              className="flex-1 bg-transparent outline-none text-foreground placeholder:text-muted-foreground text-base"
            />
            <button onClick={onClose} className="p-1.5 rounded-full hover:bg-foreground/10 shrink-0">
              <X size={18} className="text-muted-foreground" />
            </button>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-3 pb-24 pt-3" onClick={(e) => e.stopPropagation()}>
        {!results && (
          <div className="text-center text-muted-foreground mt-20">
            <Search size={48} className="mx-auto opacity-20 mb-3" />
            <p>اكتب كلمة للبحث في السنن والأحاديث والقرآن</p>
          </div>
        )}

        {results && total === 0 && (
          <div className="text-center text-muted-foreground mt-20">
            <p>لا توجد نتائج لـ &laquo;{query}&raquo;</p>
          </div>
        )}

        {results?.sunan.length > 0 && (
          <Section title="السنن النبوية" Icon={BeadsIcon}>
            {results.sunan.map(s => (
              <div key={s.id} onClick={() => { onSelectSunnah(s); onClose(); }} className="glass-blur p-3 mb-2 cursor-pointer hover:scale-[1.01] transition-transform">
                <p className="font-heading font-bold text-sm text-foreground">{s.title}</p>
                <p className="text-xs text-muted-foreground line-clamp-1 mt-1">{s.text}</p>
                <div className="flex gap-1.5 mt-2">
                  <span className={`badge text-[10px] ${getClassificationColor(s.classification)}`}>{s.classification}</span>
                  <span className={`badge text-[10px] ${getAuthenticityColor(s.authenticity)}`}>{s.authenticity}</span>
                </div>
              </div>
            ))}
          </Section>
        )}

        {results?.hadiths.length > 0 && (
          <Section title="الأحاديث الشريفة" Icon={MosqueIcon}>
            {results.hadiths.map(h => (
              <div key={h.id} className="glass-blur p-3 mb-2">
                <p className="font-heading font-bold text-sm text-foreground">{h.title}</p>
                <p className="text-xs text-muted-foreground line-clamp-2 mt-1">{h.text}</p>
                <p className="text-[10px] text-muted-foreground/70 mt-1">{h.narrator} • {h.reference}</p>
              </div>
            ))}
          </Section>
        )}

        {results?.quran.length > 0 && (
          <Section title="القرآن الكريم" Icon={BookIcon}>
            {results.quran.map(v => (
              <div key={v.id} className="glass-blur p-3 mb-2">
                <p className="text-[10px] text-emerald-600 dark:text-emerald-400 mb-1">{v.surah} • الآية {v.ayahNumber}</p>
                <p className="font-quran text-lg text-center text-foreground">{v.text}</p>
                <p className="text-xs text-muted-foreground line-clamp-2 mt-1">{v.meaning}</p>
              </div>
            ))}
          </Section>
        )}
      </div>
    </div>
  );
}

function Section({ title, Icon, children }) {
  return (
    <div className="mb-4">
      <div className="flex items-center gap-2 mb-2 px-1">
        <Icon size={18} className="text-emerald-600 dark:text-emerald-400" />
        <h3 className="text-sm font-bold text-foreground">{title}</h3>
      </div>
      {children}
    </div>
  );
}