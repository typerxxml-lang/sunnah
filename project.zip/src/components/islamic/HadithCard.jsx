import { Share2 } from 'lucide-react';
import { getAuthenticityColor } from '@/lib/badges';
import { shareContent } from '@/lib/share';

export default function HadithCard({ hadith }) {
  return (
    <div className="glass-blur p-4 anim-fade-up">
      <div className="flex items-center justify-between gap-3 mb-2">
        <h3 className="font-heading text-base font-bold text-foreground">{hadith.title}</h3>
        <div className="flex items-center gap-2 shrink-0">
          <span className={`badge ${getAuthenticityColor(hadith.authenticity)} text-xs`}>
            {hadith.authenticity}
          </span>
          <button
            onClick={() => shareContent(hadith.title, hadith.text)}
            className="p-1.5 rounded-full hover:bg-foreground/10 transition-colors"
            aria-label="مشاركة"
          >
            <Share2 size={16} className="text-muted-foreground" />
          </button>
        </div>
      </div>

      <p className="font-heading text-base text-foreground/90 leading-relaxed">
        {hadith.text}
      </p>

      <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
        <span>الراوي: {hadith.narrator}</span>
        <span className="opacity-50">•</span>
        <span>{hadith.reference}</span>
        {hadith.topic && (
          <>
            <span className="opacity-50">•</span>
            <span>{hadith.topic}</span>
          </>
        )}
      </div>
    </div>
  );
}