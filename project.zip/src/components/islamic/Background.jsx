export default function Background() {
  return (
    <div className="fixed inset-0 -z-10 overflow-hidden bg-base" aria-hidden="true">
      {/* Fine grid */}
      <div className="absolute inset-0 grid-pattern" />

      {/* Colored blobs (the "something" glass refracts) */}
      <div className="blob blob-1" />
      <div className="blob blob-2" />
      <div className="blob blob-3" />

      {/* Thick rings */}
      <div className="background-ring background-ring-1" />
      <div className="background-ring background-ring-2" />
      <div className="background-ring background-ring-3" />

      {/* Geometric Islamic pattern overlay */}
      <svg className="absolute inset-0 w-full h-full opacity-[0.04] dark:opacity-[0.06]" preserveAspectRatio="xMidYMid slice">
        <defs>
          <pattern id="islamic-pat" width="80" height="80" patternUnits="userSpaceOnUse">
            <path d="M40 0 L80 40 L40 80 L0 40 Z" fill="none" stroke="currentColor" strokeWidth="1" />
            <circle cx="40" cy="40" r="20" fill="none" stroke="currentColor" strokeWidth="1" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#islamic-pat)" className="text-primary" />
      </svg>
    </div>
  );
}