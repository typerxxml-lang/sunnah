// قرّاء التلاوات الكاملة (من موقع mp3quran)
export const RECITERS = [
  { name: 'مشاري العفاسي', server: 'https://server8.mp3quran.net/afs/' },
  { name: 'عبد الباسط عبد الصمد', server: 'https://server7.mp3quran.net/basit/' },
  { name: 'محمود خليل الحصري', server: 'https://server13.mp3quran.net/husr/' },
  { name: 'محمد صديق المنشاوي', server: 'https://server10.mp3quran.net/minsh/' },
  { name: 'عبد الرحمن السديس', server: 'https://server11.mp3quran.net/sds/' },
  { name: 'سعود الشريم', server: 'https://server7.mp3quran.net/shur/' },
  { name: 'ماهر المعيقلي', server: 'https://server12.mp3quran.net/maher/' },
  { name: 'ياسر الدوسري', server: 'https://server11.mp3quran.net/yasser/' },
  { name: 'ناصر القطامي', server: 'https://server6.mp3quran.net/qtm/' },
];

export const surahAudio = (reciter, n) => `${reciter.server}${String(n).padStart(3, '0')}.mp3`;