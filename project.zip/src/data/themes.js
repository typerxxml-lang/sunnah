// أكثر من ٢٠ لوحة ألوان PLUS؛ كل ثيم يغيّر primary وaccent.
// تشمل ثيمات ثنائية اللون مطلوبة (أزرق/أبيض، ذهبي/أبيض، بنفسجي/وردي، وردي/أبيض...)
export const THEMES = [
  { id: 'emerald',  name: 'الزمرّد',  nameEn: 'Emerald',  dark: { primary: '160 70% 45%', accent: '40 50% 55%' }, light: { primary: '160 84% 27%', accent: '40 55% 65%' } },
  { id: 'royal',    name: 'الملكي',   nameEn: 'Royal',    dark: { primary: '265 65% 58%', accent: '45 55% 58%' }, light: { primary: '265 60% 40%', accent: '45 60% 55%' } },
  { id: 'sapphire', name: 'الياقوت', nameEn: 'Sapphire', dark: { primary: '215 80% 60%', accent: '190 60% 55%' }, light: { primary: '215 85% 42%', accent: '190 55% 48%' } },
  { id: 'ruby',     name: 'الياقوت الأحمر', nameEn: 'Ruby', dark: { primary: '348 75% 55%', accent: '40 55% 58%' }, light: { primary: '348 78% 38%', accent: '40 60% 58%' } },
  { id: 'amber',    name: 'الكهرمان', nameEn: 'Amber', dark: { primary: '38 82% 55%', accent: '160 50% 45%' }, light: { primary: '38 85% 38%', accent: '160 50% 38%' } },
  { id: 'teal',     name: 'الفيرّوز', nameEn: 'Teal', dark: { primary: '175 70% 45%', accent: '40 55% 58%' }, light: { primary: '175 75% 30%', accent: '40 60% 58%' } },
  { id: 'violet',   name: 'البنفسج', nameEn: 'Violet', dark: { primary: '280 65% 62%', accent: '200 55% 55%' }, light: { primary: '280 60% 42%', accent: '200 55% 48%' } },
  { id: 'rose',     name: 'الوردي',  nameEn: 'Rose', dark: { primary: '330 70% 58%', accent: '160 45% 50%' }, light: { primary: '330 72% 40%', accent: '160 45% 38%' } },
  { id: 'forest',   name: 'الغابة',  nameEn: 'Forest', dark: { primary: '145 55% 42%', accent: '40 50% 55%' }, light: { primary: '145 60% 28%', accent: '40 55% 58%' } },
  { id: 'ocean',    name: 'المحيط',  nameEn: 'Ocean', dark: { primary: '200 75% 52%', accent: '160 45% 50%' }, light: { primary: '200 80% 36%', accent: '160 45% 40%' } },
  { id: 'sunset',   name: 'الغروب',  nameEn: 'Sunset', dark: { primary: '18 78% 55%', accent: '280 50% 58%' }, light: { primary: '18 82% 40%', accent: '280 50% 50%' } },
  { id: 'gold',     name: 'الذهبي',  nameEn: 'Gold', dark: { primary: '45 70% 50%', accent: '160 50% 42%' }, light: { primary: '45 75% 35%', accent: '160 50% 35%' } },
  { id: 'indigo',   name: 'النيلي',  nameEn: 'Indigo', dark: { primary: '235 65% 60%', accent: '40 55% 58%' }, light: { primary: '235 70% 42%', accent: '40 60% 55%' } },
  { id: 'crimson',  name: 'القرمزي', nameEn: 'Crimson', dark: { primary: '355 72% 52%', accent: '40 55% 58%' }, light: { primary: '355 76% 36%', accent: '40 60% 55%' } },
  { id: 'olive',    name: 'الزيتون', nameEn: 'Olive', dark: { primary: '82 50% 45%', accent: '40 55% 58%' }, light: { primary: '82 55% 30%', accent: '40 60% 55%' } },
  { id: 'cyan',     name: 'السماوي', nameEn: 'Cyan', dark: { primary: '190 75% 52%', accent: '280 50% 58%' }, light: { primary: '190 80% 36%', accent: '280 50% 48%' } },
  { id: 'plum',     name: 'الخوخي',  nameEn: 'Plum', dark: { primary: '300 55% 55%', accent: '160 45% 50%' }, light: { primary: '300 58% 38%', accent: '160 45% 38%' } },
  { id: 'slate',    name: 'الرمادي', nameEn: 'Slate', dark: { primary: '210 35% 55%', accent: '160 45% 48%' }, light: { primary: '210 40% 35%', accent: '160 45% 38%' } },
  { id: 'coral',    name: 'المرجاني', nameEn: 'Coral', dark: { primary: '8 75% 55%', accent: '160 45% 48%' }, light: { primary: '8 80% 40%', accent: '160 45% 38%' } },
  { id: 'mint',     name: 'النعناع', nameEn: 'Mint', dark: { primary: '155 60% 48%', accent: '40 55% 58%' }, light: { primary: '155 65% 32%', accent: '40 60% 55%' } },
  { id: 'bronze',   name: 'البرونزي', nameEn: 'Bronze', dark: { primary: '28 55% 48%', accent: '160 40% 45%' }, light: { primary: '28 60% 33%', accent: '160 40% 35%' } },
  { id: 'ice',      name: 'الجليدي', nameEn: 'Ice', dark: { primary: '195 55% 60%', accent: '220 50% 58%' }, light: { primary: '195 60% 40%', accent: '220 50% 48%' } },
  { id: 'lavender', name: 'الخزامى', nameEn: 'Lavender', dark: { primary: '250 55% 65%', accent: '40 55% 58%' }, light: { primary: '250 58% 45%', accent: '40 60% 55%' } },
  { id: 'desert',   name: 'الصحراء', nameEn: 'Desert', dark: { primary: '32 60% 48%', accent: '160 40% 45%' }, light: { primary: '32 65% 33%', accent: '160 40% 35%' } },
  // === ثيمات ثنائية اللون ===
  { id: 'blue-mono', name: 'أزرق نقي', nameEn: 'Blue Mono', duo: true, dark: { primary: '215 85% 55%', accent: '215 85% 55%' }, light: { primary: '215 90% 40%', accent: '215 90% 40%' } },
  { id: 'gold-mono', name: 'ذهبي نقي', nameEn: 'Gold Mono', duo: true, dark: { primary: '45 80% 50%', accent: '45 80% 50%' }, light: { primary: '45 85% 35%', accent: '45 85% 35%' } },
  { id: 'purple-pink', name: 'بنفسجي ووردي', nameEn: 'Purple & Pink', duo: true, dark: { primary: '280 70% 60%', accent: '330 75% 65%' }, light: { primary: '280 65% 42%', accent: '330 70% 45%' } },
  { id: 'pink-mono', name: 'وردي نقي', nameEn: 'Pink Mono', duo: true, dark: { primary: '330 80% 60%', accent: '330 80% 60%' }, light: { primary: '330 82% 42%', accent: '330 82% 42%' } },
  { id: 'green-mono', name: 'أخضر نقي', nameEn: 'Green Mono', duo: true, dark: { primary: '160 80% 45%', accent: '160 80% 45%' }, light: { primary: '160 85% 30%', accent: '160 85% 30%' } },
  { id: 'red-mono', name: 'أحمر نقي', nameEn: 'Red Mono', duo: true, dark: { primary: '0 80% 55%', accent: '0 80% 55%' }, light: { primary: '0 85% 40%', accent: '0 85% 40%' } },
  { id: 'orange-mono', name: 'برتقالي نقي', nameEn: 'Orange Mono', duo: true, dark: { primary: '25 85% 55%', accent: '25 85% 55%' }, light: { primary: '25 90% 40%', accent: '25 90% 40%' } },
  { id: 'teal-mono', name: 'فيروزي نقي', nameEn: 'Teal Mono', duo: true, dark: { primary: '175 80% 45%', accent: '175 80% 45%' }, light: { primary: '175 85% 30%', accent: '175 85% 30%' } },
];

export const DEFAULT_THEME_ID = 'emerald';

export function getTheme(id) {
  return THEMES.find(t => t.id === id) || THEMES[0];
}