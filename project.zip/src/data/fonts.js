// أكثر من ١٠ خطوط عربية وإنجليزية
export const FONTS = [
  // خطوط عربية
  { id: 'amiri', name: 'أميري', nameEn: 'Amiri', lang: 'ar', family: "'Amiri', serif", sample: 'بسم الله الرحمن الرحيم' },
  { id: 'cairo', name: 'القاهرة', nameEn: 'Cairo', lang: 'ar', family: "'Cairo', sans-serif", sample: 'بسم الله الرحمن الرحيم' },
  { id: 'tajawal', name: 'تجوال', nameEn: 'Tajawal', lang: 'ar', family: "'Tajawal', sans-serif", sample: 'بسم الله الرحمن الرحيم' },
  { id: 'naskh', name: 'نسخ', nameEn: 'Noto Naskh', lang: 'ar', family: "'Noto Naskh Arabic', serif", sample: 'بسم الله الرحمن الرحيم' },
  { id: 'scheherazade', name: 'شهرزاد', nameEn: 'Scheherazade', lang: 'ar', family: "'Scheherazade New', serif", sample: 'بسم الله الرحمن الرحيم' },
  { id: 'reemkufi', name: 'ريم كوفي', nameEn: 'Reem Kufi', lang: 'ar', family: "'Reem Kufi', sans-serif", sample: 'بسم الله الرحمن الرحيم' },
  { id: 'elmessiri', name: 'المسيري', nameEn: 'El Messiri', lang: 'ar', family: "'El Messiri', sans-serif", sample: 'بسم الله الرحمن الرحيم' },
  { id: 'markazi', name: 'مركزي', nameEn: 'Markazi Text', lang: 'ar', family: "'Markazi Text', serif", sample: 'بسم الله الرحمن الرحيم' },
  { id: 'lateef', name: 'لطيف', nameEn: 'Lateef', lang: 'ar', family: "'Lateef', serif", sample: 'بسم الله الرحمن الرحيم' },
  { id: 'arefruqaa', name: 'عارف رقعة', nameEn: 'Aref Ruqaa', lang: 'ar', family: "'Aref Ruqaa', serif", sample: 'بسم الله الرحمن الرحيم' },
  // خطوط إنجليزية
  { id: 'inter', name: 'إنتر', nameEn: 'Inter', lang: 'en', family: "'Inter', sans-serif", sample: 'In the name of Allah' },
  { id: 'poppins', name: 'بوبينز', nameEn: 'Poppins', lang: 'en', family: "'Poppins', sans-serif", sample: 'In the name of Allah' },
  { id: 'roboto', name: 'روبوتو', nameEn: 'Roboto', lang: 'en', family: "'Roboto', sans-serif", sample: 'In the name of Allah' },
  { id: 'montserrat', name: 'مونتسيرات', nameEn: 'Montserrat', lang: 'en', family: "'Montserrat', sans-serif", sample: 'In the name of Allah' },
  { id: 'lora', name: 'لورا', nameEn: 'Lora', lang: 'en', family: "'Lora', serif", sample: 'In the name of Allah' },
  { id: 'playfair', name: 'بلايفير', nameEn: 'Playfair', lang: 'en', family: "'Playfair Display', serif", sample: 'In the name of Allah' },
];

export const DEFAULT_FONT_ID = 'amiri';

export function getFont(id) {
  return FONTS.find(f => f.id === id) || FONTS[0];
}