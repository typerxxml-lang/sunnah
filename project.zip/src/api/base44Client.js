// طبقة حفظ محلية تحل محل Base44: نفس الواجهة، لكن كل البيانات تُحفظ في متصفح الجهاز (localStorage).
const P = 'iq-db-';
const read = (k, fb) => { try { const r = localStorage.getItem(k); return r === null ? fb : JSON.parse(r); } catch { return fb; } };
const write = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} };

const uid = () => (crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36) + Math.random().toString(36).slice(2, 10));

function deviceId() {
  let id = read('iq-device-id', null);
  if (!id) { id = uid(); write('iq-device-id', id); }
  return id;
}

// ===== مطابقة الاستعلامات (تدعم المساواة و $exists و $gt) =====
function matches(rec, query = {}) {
  return Object.entries(query).every(([key, cond]) => {
    const val = rec[key];
    if (cond && typeof cond === 'object' && !Array.isArray(cond)) {
      if ('$exists' in cond) { const has = val !== undefined && val !== null; if (has !== !!cond.$exists) return false; }
      if ('$gt' in cond && !(val > cond.$gt)) return false;
      if ('$lt' in cond && !(val < cond.$lt)) return false;
      if ('$ne' in cond && val === cond.$ne) return false;
      return true;
    }
    return val === cond;
  });
}

function sortItems(items, sort) {
  if (!sort) return items;
  const desc = sort.startsWith('-');
  const key = desc ? sort.slice(1) : sort;
  return [...items].sort((a, b) => {
    const x = a[key], y = b[key];
    if (x === y) return 0;
    if (x === undefined) return 1;
    if (y === undefined) return -1;
    return (x > y ? 1 : -1) * (desc ? -1 : 1);
  });
}

function entity(name) {
  const key = P + name;
  const all = () => read(key, []);
  const save = (items) => write(key, items);
  const page = (items, opts = {}) => {
    const sorted = sortItems(items, opts.sort);
    const limit = opts.limit || 100;
    return { items: sorted.slice(0, limit), has_more: sorted.length > limit, next_cursor: null };
  };
  return {
    async filter(query = {}, opts = {}) { return page(all().filter((r) => matches(r, query)), opts); },
    async list(opts = {}) { return page(all(), opts); },
    async count(query = {}) { return all().filter((r) => matches(r, query)).length; },
    async get(id) { return all().find((r) => r.id === id) || null; },
    async create(data) {
      const now = new Date().toISOString();
      const rec = { ...data, id: uid(), created_date: now, updated_date: now };
      save([...all(), rec]);
      return rec;
    },
    async update(id, patch) {
      let out = null;
      save(all().map((r) => (r.id === id ? (out = { ...r, ...patch, updated_date: new Date().toISOString() }) : r)));
      return out;
    },
    async delete(id) { save(all().filter((r) => r.id !== id)); return { success: true }; },
  };
}

// ===== المستخدم المحلي =====
function localUser() {
  const stored = read('iq-user', null);
  const profile = read('iq-profile', {});
  return {
    id: deviceId(),
    email: '',
    full_name: stored?.name || '',
    display_name: profile.display_name || stored?.name || '',
    avatar_uri: profile.avatar_uri || stored?.avatar_uri || null,
    banned: false,
    role: 'admin',
  };
}

const userEntity = {
  async list() { return { items: [localUser()], has_more: false, next_cursor: null }; },
  async update(id, patch) { write('iq-profile', { ...read('iq-profile', {}), ...patch }); return localUser(); },
};

// ===== رفع الملفات: تُصغَّر الصورة وتُحفظ محلياً =====
function fileToDataUrl(file, max = 320) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = reject;
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => resolve(reader.result);
      img.onload = () => {
        const scale = Math.min(1, max / Math.max(img.width, img.height));
        const c = document.createElement('canvas');
        c.width = Math.round(img.width * scale); c.height = Math.round(img.height * scale);
        c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
        resolve(c.toDataURL('image/jpeg', 0.85));
      };
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
  });
}

export const base44 = {
  app: { getPublicSettings: async () => ({}) },
  auth: {
    isAuthenticated: async () => true,
    me: async () => localUser(),
    updateMe: async (patch) => { write('iq-profile', { ...read('iq-profile', {}), ...patch }); return localUser(); },
    logout: () => {},
    redirectToLogin: () => {},
  },
  entities: new Proxy({}, {
    get: (cache, name) => {
      if (typeof name !== 'string') return undefined;
      if (name === 'User') return userEntity;
      return (cache[name] ||= entity(name));
    },
  }),
  integrations: {
    Core: {
      async UploadPrivateFile({ file }) {
        const id = 'local:' + uid();
        write(P + 'file-' + id, await fileToDataUrl(file));
        return { file_uri: id };
      },
      async CreateFileSignedUrl({ file_uri }) {
        const url = read(P + 'file-' + file_uri, null);
        if (!url) throw new Error('الملف غير موجود');
        return { signed_url: url };
      },
    },
  },
};
