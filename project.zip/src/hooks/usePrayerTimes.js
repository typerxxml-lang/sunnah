import { useEffect, useState } from 'react';
import { todayKey } from '@/lib/time';

// طلب واحد مشترك لكل المكونات خلال اليوم نفسه
let cache = null;
let cacheDay = '';

function fetchTimes() {
  const day = todayKey();
  if (cache && cacheDay === day) return cache;
  cacheDay = day;
  cache = new Promise((resolve, reject) => {
    if (!navigator.geolocation) return reject(new Error('الموقع غير مدعوم على هذا الجهاز'));
    navigator.geolocation.getCurrentPosition(
      async ({ coords }) => {
        try {
          const res = await fetch(
            `https://api.aladhan.com/v1/timings?latitude=${coords.latitude}&longitude=${coords.longitude}&method=4`
          );
          const data = await res.json();
          resolve(data.data.timings);
        } catch {
          reject(new Error('تعذّر جلب مواقيت الصلاة'));
        }
      },
      () => reject(new Error('يرجى السماح بالوصول للموقع لعرض مواقيت الصلاة')),
      { timeout: 10000, enableHighAccuracy: false }
    );
  });
  cache.catch(() => { cache = null; });
  return cache;
}

export function usePrayerTimes() {
  const [state, setState] = useState({ times: null, loading: true, error: null });

  useEffect(() => {
    let alive = true;
    fetchTimes().then(
      (times) => alive && setState({ times, loading: false, error: null }),
      (e) => alive && setState({ times: null, loading: false, error: e.message })
    );
    return () => { alive = false; };
  }, []);

  return state;
}