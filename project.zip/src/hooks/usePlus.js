import { useState, useEffect, useCallback } from 'react';
import { loadJSON, loadString, saveJSON, saveString } from '@/lib/storage';
import { base44 } from '@/api/base44Client';
import { getAdminToken, loginAdmin, setAdminToken } from '@/lib/adminApi';

const ADMIN_KEY = 'iq-admin-unlocked';
const EVENT = 'iq-plus-change';
const FIRST_USE_KEY = 'iq-first-use-at';
const FREE_PLUS_AWARDED_KEY = 'iq-plus-7day-awarded';
const FREE_PLUS_AWARD_LOCK_KEY = 'iq-plus-7day-awarding';
const FREE_PLUS_LOCK_MAX_AGE_MS = 2 * 60 * 1000;
const SEVEN_DAYS_MS = 7 * 24 * 60 * 60 * 1000;

function getOrCreateFirstUseAt() {
  const stored = Number(loadString(FIRST_USE_KEY, '0'));
  if (Number.isFinite(stored) && stored > 0) return stored;
  const firstUseAt = Date.now();
  saveString(FIRST_USE_KEY, String(firstUseAt));
  return firstUseAt;
}
function persist(key, value) {
  saveJSON(key, value);
  window.dispatchEvent(new Event(EVENT));
}

// PLUS يُحفظ محلياً على الجهاز، ومكافأة 7 أيام تُمنح بعد مرور سبعة أيام كاملة من أول زيارة.
export function usePlus() {
  const [plusRecord, setPlusRecord] = useState(() => loadJSON('iq-plus-record', null));
  const [adminUnlocked, setAdminUnlocked] = useState(() => !!getAdminToken());
  const [loading, setLoading] = useState(true);
  const [firstUseAt] = useState(getOrCreateFirstUseAt);

  const refreshPlus = useCallback(async () => {
    try {
      const me = await base44.auth.me();
      if (!me?.id) { setPlusRecord(null); saveString('iq-plus-active', '0'); return; }
      const { items } = await base44.entities.UserPlus.filter({ user_id: me.id, active: true }, { limit: 1 });
      let activeRecord = items[0] || null;
      const alreadyAwarded = loadString(FREE_PLUS_AWARDED_KEY, '0') === '1';
      const awardLockAt = Number(loadString(FREE_PLUS_AWARD_LOCK_KEY, '0'));
      const awardInProgress = Number.isFinite(awardLockAt) && awardLockAt > 0 && Date.now() - awardLockAt < FREE_PLUS_LOCK_MAX_AGE_MS;
      if (awardLockAt > 0 && !awardInProgress) saveString(FREE_PLUS_AWARD_LOCK_KEY, '0');
      let justAwarded = false;
      if (!activeRecord && !alreadyAwarded && !awardInProgress && Date.now() - firstUseAt >= SEVEN_DAYS_MS) {
        saveString(FREE_PLUS_AWARD_LOCK_KEY, String(Date.now()));
        try {
          activeRecord = await base44.entities.UserPlus.create({
            user_id: me.id,
            user_email: me.email || '',
            active: true,
            activated_at: new Date().toISOString(),
            source: 'seven-day-local-reward',
            reward_reason: 'إكمال سبعة أيام كاملة في نافعاً',
          });
          saveString(FREE_PLUS_AWARDED_KEY, '1');
          justAwarded = true;
        } finally {
          saveString(FREE_PLUS_AWARD_LOCK_KEY, '0');
        }
      } else if (!activeRecord && awardInProgress) {
        return;
      }
      setPlusRecord(activeRecord);
      saveJSON('iq-plus-record', activeRecord);
      saveString('iq-plus-active', activeRecord ? '1' : '0');
      if (justAwarded) window.dispatchEvent(new Event(EVENT));
    } catch { setPlusRecord(null); }
    finally { setLoading(false); }
  }, [firstUseAt]);

  useEffect(() => {
    refreshPlus();
    const delayUntilReward = Math.max(0, firstUseAt + SEVEN_DAYS_MS - Date.now()) + 100;
    const rewardTimer = window.setTimeout(() => refreshPlus(), delayUntilReward);
    return () => window.clearTimeout(rewardTimer);
  }, [refreshPlus, firstUseAt]);

  useEffect(() => {
    const sync = () => refreshPlus();
    window.addEventListener(EVENT, sync);
    window.addEventListener('storage', sync);
    return () => { window.removeEventListener(EVENT, sync); window.removeEventListener('storage', sync); };
  }, [refreshPlus]);

  useEffect(() => {
    const syncAdmin = () => setAdminUnlocked(!!getAdminToken());
    window.addEventListener('iq-admin-session-change', syncAdmin);
    return () => window.removeEventListener('iq-admin-session-change', syncAdmin);
  }, []);

  const activatePlus = useCallback(async (expiresAt, code) => {
    // expiresAt هنا = صلاحية الكود، وليس مدة PLUS (PLUS دائم)
    const me = await base44.auth.me();
    if (!me?.id) throw new Error('سجّل الدخول أولاً');
    await base44.entities.UserPlus.create({
      user_id: me.id,
      user_email: me.email,
      active: true,
      activated_at: new Date().toISOString(),
      code,
    });
    await refreshPlus();
  }, [refreshPlus]);

  const deactivatePlus = useCallback(async () => {
    if (plusRecord) {
      await base44.entities.UserPlus.delete(plusRecord.id);
      await refreshPlus();
    }
  }, [plusRecord, refreshPlus]);

  const unlockAdmin = useCallback(async password => {
    await loginAdmin(password);
    saveJSON(ADMIN_KEY, false);
    setAdminUnlocked(true);
    window.dispatchEvent(new Event('iq-admin-session-change'));
    return true;
  }, []);

  const lockAdmin = useCallback(() => {
    setAdminToken('');
    saveJSON(ADMIN_KEY, false);
    setAdminUnlocked(false);
    window.dispatchEvent(new Event('iq-admin-session-change'));
  }, []);

  return { plusRecord, isPlusActive: !!plusRecord, loading, activatePlus, deactivatePlus, adminUnlocked, unlockAdmin, lockAdmin, refreshPlus };
}