import { useState, useEffect, useCallback } from 'react';
import { loadJSON, saveJSON } from '@/lib/storage';
import { base44 } from '@/api/base44Client';

const ADMIN_KEY = 'iq-admin-unlocked';
const EVENT = 'iq-plus-change';
function persist(key, value) {
  saveJSON(key, value);
  window.dispatchEvent(new Event(EVENT));
}

// PLUS دائم الآن: يُفحص من الخادم (UserPlus) بدل التخزين المحلي المؤقت.
export function usePlus() {
  const [plusRecord, setPlusRecord] = useState(null);
  const [adminUnlocked, setAdminUnlocked] = useState(() => loadJSON(ADMIN_KEY, false));
  const [loading, setLoading] = useState(true);

  const refreshPlus = useCallback(async () => {
    try {
      const me = await base44.auth.me();
      if (!me?.id) { setPlusRecord(null); return; }
      const { items } = await base44.entities.UserPlus.filter({ user_id: me.id, active: true }, { limit: 1 });
      setPlusRecord(items[0] || null);
    } catch { setPlusRecord(null); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { refreshPlus(); }, [refreshPlus]);

  useEffect(() => {
    const sync = () => refreshPlus();
    window.addEventListener(EVENT, sync);
    window.addEventListener('storage', sync);
    return () => { window.removeEventListener(EVENT, sync); window.removeEventListener('storage', sync); };
  }, [refreshPlus]);

  const activatePlus = useCallback(async (expiresAt, code) => {
    // expiresAt هنا = صلاحية الكود، وليس مدة PLUS (PLUS دائم)
    const me = await base44.auth.me();
    if (!me?.id) throw new Error('سجّل الدخول أولاً');
    await base44.entities.UserPlus.create({
      user_id: me.id,
      user_email: me.email,
      active: true,
      activated_at: new Date().toISOString(),
      code,
    });
    await refreshPlus();
  }, [refreshPlus]);

  const deactivatePlus = useCallback(async () => {
    if (plusRecord) {
      await base44.entities.UserPlus.delete(plusRecord.id);
      await refreshPlus();
    }
  }, [plusRecord, refreshPlus]);

  const unlockAdmin = useCallback(password => {
    if (password !== 'monday33') return false;
    persist(ADMIN_KEY, true);
    setAdminUnlocked(true);
    return true;
  }, []);

  const lockAdmin = useCallback(() => {
    persist(ADMIN_KEY, false);
    setAdminUnlocked(false);
  }, []);

  return { plusRecord, isPlusActive: !!plusRecord, loading, activatePlus, deactivatePlus, adminUnlocked, unlockAdmin, lockAdmin, refreshPlus };
}