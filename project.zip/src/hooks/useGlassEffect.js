import { useEffect, useRef } from 'react';
import { useGlassStyle } from '@/lib/glassStyle';

const NS = 'http://www.w3.org/2000/svg';
let uid = 0;
let defsEl = null;

function getDefs() {
  if (defsEl && defsEl.isConnected) return defsEl;
  defsEl = document.getElementById('glass-defs');
  return defsEl;
}

const isChromium = typeof navigator !== 'undefined'
  ? /Chrome|Chromium|Edg/.test(navigator.userAgent)
  : false;

const SQUIRCLE = typeof CSS !== 'undefined' && !!CSS.supports?.('corner-shape', 'squircle');

// دقة خريطة الانكسار (أقل = أسرع). الخريطة تُمدّد بنعومة فلا يظهر فرق.
const MAP_SIZE = 96;
// خرائط الانكسار تُحفظ وتُشارَك بين العناصر المتشابهة بدل إعادة حسابها
const mapCache = new Map();

const schedule = (fn) => (typeof requestIdleCallback === 'function'
  ? requestIdleCallback(fn, { timeout: 250 })
  : setTimeout(fn, 16));
const cancelSchedule = (id) => (typeof cancelIdleCallback === 'function' ? cancelIdleCallback(id) : clearTimeout(id));

function makeMap(cw, ch, rr, b) {
  const key = `${cw}x${ch}|${rr.toFixed(1)}|${b.toFixed(1)}|${SQUIRCLE ? 1 : 0}`;
  const hit = mapCache.get(key);
  if (hit) return hit;

  const c = document.createElement('canvas');
  c.width = cw;
  c.height = ch;
  const cx = c.getContext('2d');
  const im = cx.createImageData(cw, ch);
  const d = im.data;
  const hx = cw / 2;
  const hy = ch / 2;

  for (let j = 0; j < ch; j++) {
    for (let i = 0; i < cw; i++) {
      const px = i + 0.5 - hx;
      const py = j + 0.5 - hy;
      const qx = Math.abs(px) - (hx - rr);
      const qy = Math.abs(py) - (hy - rr);
      const ox = Math.max(qx, 0);
      const oy = Math.max(qy, 0);
      // زوايا Squircle (قطع ناقص فائق بأس ٤) لتطابق corner-shape: squircle
      const len = SQUIRCLE ? Math.sqrt(Math.sqrt(ox ** 4 + oy ** 4)) : Math.hypot(ox, oy);
      const depth = -(len + Math.min(Math.max(qx, qy), 0) - rr);
      let vx = 0, vy = 0;
      if (depth >= 0 && depth < b) {
        let nx, ny;
        if (qx > 0 && qy > 0) {
          const gx = SQUIRCLE ? ox ** 3 : ox;
          const gy = SQUIRCLE ? oy ** 3 : oy;
          const gl = Math.hypot(gx, gy);
          nx = gx / gl * Math.sign(px);
          ny = gy / gl * Math.sign(py);
        } else if (qx > qy) {
          nx = Math.sign(px); ny = 0;
        } else {
          nx = 0; ny = Math.sign(py);
        }
        const m = Math.pow(1 - depth / b, 1.7);
        vx = -nx * m;
        vy = -ny * m;
      }
      const o = (j * cw + i) * 4;
      d[o] = 128 + vx * 127;
      d[o + 1] = 128 + vy * 127;
      d[o + 2] = 128;
      d[o + 3] = 255;
    }
  }

  cx.putImageData(im, 0, 0);
  const url = c.toDataURL();
  if (mapCache.size > 60) mapCache.clear();
  mapCache.set(key, url);
  return url;
}

/**
 * Applies the real "Liquid Glass" refraction effect to an element.
 * يعمل فقط في نمط الزجاج السائل (PLUS)؛ في Material You والضبابي يُترك CSS العادي.
 * On non-Chromium browsers the CSS fallback (blur + saturate) is used.
 *
 * @param {number} r  - corner radius in px
 * @param {number} bz - border zone thickness in px (how far refraction reaches inward)
 * @param {number} sc - displacement scale
 */
export function useGlassEffect(r = 30, bz = 24, sc = 44, fx = 'blur(2px) saturate(1.7) brightness(1.1)') {
  const ref = useRef(null);
  const style = useGlassStyle();

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (style !== 'liquid' || !isChromium) {
      el.style.backdropFilter = '';
      return;
    }

    const defs = getDefs();
    if (!defs) return;

    const id = 'lg' + uid++;
    const f = document.createElementNS(NS, 'filter');
    f.id = id;
    defs.appendChild(f);

    let q;
    let job;
    let lastW = 0;
    let lastH = 0;

    const build = () => {
      const w = Math.round(el.offsetWidth);
      const h = Math.round(el.offsetHeight);
      if (!w || !h) return;
      if (Math.abs(w - lastW) < 2 && Math.abs(h - lastH) < 2) return;
      lastW = w; lastH = h;

      const k = Math.min(1, MAP_SIZE / Math.max(w, h));
      const cw = Math.max(2, Math.round(w * k));
      const ch = Math.max(2, Math.round(h * k));

      // نطابق انحناء الانكسار مع انحناء العنصر الفعلي في CSS
      const cssR = parseFloat(getComputedStyle(el).borderTopLeftRadius);
      const rr = Math.min(cssR > 0 ? cssR : r, w / 2, h / 2) * k;
      const url = makeMap(cw, ch, rr, bz * k);

      f.setAttribute('x', 0);
      f.setAttribute('y', 0);
      f.setAttribute('width', w);
      f.setAttribute('height', h);
      f.setAttribute('filterUnits', 'userSpaceOnUse');
      f.setAttribute('primitiveUnits', 'userSpaceOnUse');
      f.setAttribute('color-interpolation-filters', 'sRGB');

      f.innerHTML =
        `<feImage href="${url}" x="0" y="0" width="${w}" height="${h}" preserveAspectRatio="none" result="m"/>` +
        `<feDisplacementMap in="SourceGraphic" in2="m" scale="${sc}" xChannelSelector="R" yChannelSelector="G"/>`;

      el.style.backdropFilter = `url(#${id}) ${fx}`;
    };

    // البناء في وقت فراغ المتصفح؛ وحتى ذلك الحين يظهر زجاج CSS العادي فوراً
    job = schedule(build);

    const ro = new ResizeObserver(() => {
      cancelAnimationFrame(q);
      q = requestAnimationFrame(build);
    });
    ro.observe(el);

    return () => {
      ro.disconnect();
      cancelAnimationFrame(q);
      cancelSchedule(job);
      if (f.parentNode) f.parentNode.removeChild(f);
    };
  }, [r, bz, sc, fx, style]);

  return ref;
}
