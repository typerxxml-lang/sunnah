import { useEffect, useRef, useState } from 'react';

function nearestWidget(grid, x, y) {
  let nearest = null, distance = Infinity;
  grid?.querySelectorAll('[data-widget-id]').forEach(element => {
    const r = element.getBoundingClientRect();
    const dx = Math.max(r.left - x, 0, x - r.right);
    const dy = Math.max(r.top - y, 0, y - r.bottom);
    const d = dx * dx + dy * dy;
    if (d < distance) { distance = d; nearest = element.dataset.widgetId; }
  });
  return nearest;
}

export function useWidgetDrag(gridRef, onDrop) {
  const session = useRef(null), frame = useRef(null);
  const [drag, setDrag] = useState(null);
  const stop = () => { session.current = null; cancelAnimationFrame(frame.current); setDrag(null); };
  useEffect(() => () => cancelAnimationFrame(frame.current), []);
  const tick = () => {
    const s = session.current;
    if (!s) return;
    const speed = s.y < 110 ? -14 : s.y > window.innerHeight - 120 ? 14 : 0;
    if (speed) window.scrollBy({ top: speed, behavior: 'instant' });
    const target = nearestWidget(gridRef.current, s.x, s.y);
    if (s.target !== target) { s.target = target; setDrag({ ...s }); }
    frame.current = requestAnimationFrame(tick);
  };
  const handlers = id => ({
    onPointerDown: e => {
      if (!e.isPrimary || e.button !== 0) return;
      e.preventDefault();
      e.currentTarget.focus();
      e.currentTarget.setPointerCapture(e.pointerId);
      session.current = { id, target: id, x: e.clientX, y: e.clientY, pointerId: e.pointerId };
      setDrag({ ...session.current });
      frame.current = requestAnimationFrame(tick);
    },
    onPointerMove: e => {
      const s = session.current;
      if (!s || s.pointerId !== e.pointerId) return;
      s.x = e.clientX; s.y = e.clientY;
      s.target = nearestWidget(gridRef.current, s.x, s.y);
      setDrag({ ...s });
    },
    onPointerUp: e => {
      const s = session.current;
      if (!s || s.pointerId !== e.pointerId) return;
      const target = nearestWidget(gridRef.current, e.clientX, e.clientY);
      stop();
      if (e.currentTarget.hasPointerCapture(e.pointerId)) e.currentTarget.releasePointerCapture(e.pointerId);
      if (target) onDrop(s.id, target);
    },
    onPointerCancel: stop,
    onLostPointerCapture: () => { if (session.current) stop(); },
  });
  return { drag, handlers, cancel: stop };
}