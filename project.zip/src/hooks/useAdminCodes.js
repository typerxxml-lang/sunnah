import { useCallback, useEffect, useState } from 'react';
import { createPlusCode, deletePlusCode, listActiveCodes, plusCodeError } from '@/lib/plusCodes';

export function useAdminCodes(enabled) {
  const [page, setPage] = useState({ items: [], total: 0, has_more: false, next_cursor: null });
  const [loading, setLoading] = useState(false), [pending, setPending] = useState(null), [error, setError] = useState('');
  const refresh = useCallback(async cursor => {
    setLoading(true); setError('');
    try {
      const result = await listActiveCodes(cursor);
      setPage(previous => ({ ...result, items: cursor ? [...previous.items, ...result.items] : result.items, total: result.total ?? previous.total }));
    } catch (failure) {
      setError(plusCodeError(failure, 'تعذّر تحميل الأكواد. حاول تحديث القائمة.'));
    } finally { setLoading(false); }
  }, []);
  useEffect(() => { if (enabled) refresh(); }, [enabled, refresh]);
  const create = async (duration, note) => {
    setPending('create'); setError('');
    try {
      const record = await createPlusCode(duration, note);
      await refresh();
      return record;
    } catch (failure) {
      setError(plusCodeError(failure, 'تعذّر إنشاء الكود. تأكد من تسجيل الدخول وحاول مجدداً.'));
      return null;
    } finally { setPending(null); }
  };
  const remove = async id => {
    setPending(id); setError('');
    try { await deletePlusCode(id); await refresh(); }
    catch (failure) { setError(plusCodeError(failure, 'تعذّر حذف الكود. حاول مجدداً.')); }
    finally { setPending(null); }
  };
  return { page, loading, pending, error, refresh, create, remove };
}