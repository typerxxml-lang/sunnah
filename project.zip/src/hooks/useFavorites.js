import { useState, useCallback } from 'react';
import { loadJSON, saveJSON } from '@/lib/storage';

export function useFavorites() {
  const [favorites, setFavorites] = useState(() => loadJSON('iq-favorites', []));

  const toggle = useCallback((id) => {
    setFavorites(prev => {
      const next = prev.includes(id)
        ? prev.filter(f => f !== id)
        : [...prev, id];
      saveJSON('iq-favorites', next);
      return next;
    });
  }, []);

  const isFavorite = useCallback((id) => favorites.includes(id), [favorites]);

  return { favorites, toggle, isFavorite };
}