import { useState, useEffect } from 'react';
import { PROMO_ENDS_AT, isPromoActive, promoDaysLeft } from '@/lib/launchPromo';

// يحدّث الحالة كل دقيقة، ويقفل العرض لحظة انتهائه بدون إعادة تحميل.
export function useLaunchPromo() {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    if (Date.now() >= PROMO_ENDS_AT) return undefined;
    const id = window.setInterval(() => setNow(Date.now()), 60000);
    const end = window.setTimeout(() => setNow(Date.now()), Math.min(2147483000, Math.max(0, PROMO_ENDS_AT - Date.now()) + 200));
    return () => { window.clearInterval(id); window.clearTimeout(end); };
  }, []);
  return { active: isPromoActive(now), daysLeft: promoDaysLeft(now) };
}

export function daysLeftText(daysLeft) {
  if (daysLeft <= 1) return 'اليوم آخر يوم';
  if (daysLeft === 2) return 'باقي يومان';
  if (daysLeft <= 10) return `باقي ${daysLeft} أيام`;
  return `باقي ${daysLeft} يوماً`;
}
