import { useEffect, useState } from 'react';
import { loadString, saveString } from '@/lib/storage';
import { getTheme } from '@/data/themes';

const THEME_KEY = 'iq-theme';
const THEME_ID_KEY = 'iq-theme-id';

export function useTheme() {
  const [theme, setTheme] = useState(() => loadString(THEME_KEY, 'dark'));
  const [themeId, setThemeId] = useState(() => loadString(THEME_ID_KEY, 'emerald'));

  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    saveString(THEME_KEY, theme);

    // تطبيق ثيم PLUS المخصّص
    const t = getTheme(themeId);
    const palette = theme === 'dark' ? t.dark : t.light;
    root.style.setProperty('--primary', palette.primary);
    root.style.setProperty('--accent', palette.accent);
    // ring يتبع primary عادةً
    root.style.setProperty('--ring', palette.primary);
    saveString(THEME_ID_KEY, themeId);
  }, [theme, themeId]);

  const toggle = () => setTheme(t => (t === 'dark' ? 'light' : 'dark'));

  return { theme, toggle, setTheme, themeId, setThemeId };
}