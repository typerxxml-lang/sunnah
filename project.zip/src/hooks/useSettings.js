import { useState, useCallback } from 'react';
import { loadJSON, saveJSON } from '@/lib/storage';

const DEFAULT_SETTINGS = {
  fontScale: 1,
  fontFamily: 'amiri',
  dailyReminder: true,
  notifications: true,
  showAuthenticity: true,
  showClassification: true,
  timeFormat: '12',
  dailyGoalPages: 5,
  themeId: 'emerald',
  language: 'ar',
  glassStyle: 'liquid',
  powerSaver: false,
  ambientSound: 'none',
  hiddenWidgets: [],
};

export function useSettings() {
  const [settings, setSettings] = useState(() => ({
    ...DEFAULT_SETTINGS,
    ...loadJSON('iq-settings', {}),
  }));

  const update = useCallback((patch) => {
    setSettings(prev => {
      const next = { ...prev, ...patch };
      saveJSON('iq-settings', next);
      return next;
    });
  }, []);

  return { settings, update };
}