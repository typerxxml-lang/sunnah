import { useEffect, useRef, useCallback, startTransition } from 'react';

/**
 * كبسولة الشريط السفلي: الحركة بانتقال CSS نابض (يعمل على معالج الرسوميات)
 * فتبقى سلسة حتى أثناء رسم الصفحة الجديدة، مع سحب بالإصبع وقفز مباشر عند الضغط.
 */
const EXTRA = 'box-shadow 0.35s, background 0.35s';
const JUMP = `transform 0.5s cubic-bezier(0.32, 1.28, 0.52, 1), ${EXTRA}`;
const FOLLOW = `transform 0.14s cubic-bezier(0.22, 1, 0.36, 1), ${EXTRA}`;
const POP = `transform 0.32s cubic-bezier(0.34, 1.56, 0.64, 1), ${EXTRA}`;
const PAD = 6;        // حشوة الشريط
const WIDEN = 10;     // الكبسولة أعرض من الزر
const DRAG_MIN = 6;   // مسافة بدء السحب

const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

export function useDockPill(activeId, onSelect) {
  const dockRef = useRef(null);
  const pillRef = useRef(null);
  const st = useRef({ cur: activeId, x: 0, y: 0, w: 0, v: 0, lx: 0, t: 0, lift: false, down: false, drag: false, sx: 0, ready: false });
  const onSelectRef = useRef(onSelect);
  onSelectRef.current = onSelect;

  const tabs = () => [...(dockRef.current?.querySelectorAll('[data-v]') || [])];
  const markOn = (b) => tabs().forEach((x) => x.classList.toggle('on', x === b));

  const paint = useCallback((transition) => {
    const p = pillRef.current;
    if (!p) return;
    const s = st.current;
    const base = s.lift ? 1.1 : 1;
    const k = Math.min(Math.abs(s.v) / 40, 0.16); // تمدد الكبسولة مع سرعة السحب
    p.style.transition = transition;
    p.style.transform = `translate3d(${s.x}px,${s.y}px,0) scale(${base + k},${base - k * 0.5})`;
  }, []);

  const place = useCallback((transition) => {
    const dock = dockRef.current;
    const p = pillRef.current;
    const b = dock?.querySelector(`[data-v="${st.current.cur}"]`);
    if (!dock || !p || !b) return;
    const s = st.current;
    s.w = Math.min(b.offsetWidth + WIDEN, dock.clientWidth - PAD * 2);
    p.style.width = s.w + 'px';
    p.style.height = b.offsetHeight + 'px';
    s.y = b.offsetTop;
    s.x = clamp(b.offsetLeft + (b.offsetWidth - s.w) / 2, PAD, dock.clientWidth - PAD - s.w);
    paint(transition);
  }, [paint]);

  const sel = useCallback((b) => {
    if (!b) return;
    const s = st.current;
    const id = b.dataset.v;
    s.cur = id;
    s.lift = false;
    s.v = 0;
    markOn(b);
    place(JUMP);
    if (navigator.vibrate) navigator.vibrate(10);
    // الحركة تعمل على معالج الرسوميات، فنبدّل الصفحة فوراً بدون انتظار
    startTransition(() => onSelectRef.current(id));
  }, [place]);

  // مزامنة مع التبويب النشط من الخارج
  useEffect(() => {
    const s = st.current;
    s.cur = activeId;
    const b = dockRef.current?.querySelector(`[data-v="${activeId}"]`);
    if (b) markOn(b);
    place(s.ready ? JUMP : 'none');
    s.ready = true;
  }, [activeId, place]);

  useEffect(() => {
    const dock = dockRef.current;
    const pill = pillRef.current;
    if (!dock || !pill) return;
    const s = st.current;

    const near = (cx) => {
      let best = null; let bd = 1e9;
      tabs().forEach((b) => {
        const r = b.getBoundingClientRect();
        const d = Math.abs(r.left + r.width / 2 - cx);
        if (d < bd) { bd = d; best = b; }
      });
      return best;
    };
    const setPress = (on) => {
      pill.classList.toggle('lift', on);
      dock.classList.toggle('press', on);
    };
    const down = (e) => {
      s.down = true; s.drag = false; s.sx = e.clientX; s.lx = e.clientX; s.v = 0; s.lift = true;
      try { dock.setPointerCapture(e.pointerId); } catch (_) { /* ignore */ }
      setPress(true);
      paint(POP);
    };
    const move = (e) => {
      if (!s.down) return;
      if (!s.drag && Math.abs(e.clientX - s.sx) < DRAG_MIN) return;
      s.drag = true;
      const r = dock.getBoundingClientRect();
      s.x = clamp(e.clientX - r.left - s.w / 2, PAD, r.width - PAD - s.w);
      s.v = e.clientX - s.lx;
      s.lx = e.clientX;
      markOn(near(e.clientX));
      paint(FOLLOW);
      // عند توقف الإصبع تعود الكبسولة لشكلها بنعومة
      clearTimeout(s.t);
      s.t = setTimeout(() => { s.v = 0; if (s.down) paint(POP); }, 90);
    };
    const up = (e) => {
      if (!s.down) return;
      s.down = false;
      setPress(false);
      sel(near(e.clientX));
    };
    const cancel = () => {
      if (!s.down) return;
      s.down = false; s.lift = false; s.v = 0;
      setPress(false);
      markOn(dock.querySelector(`[data-v="${s.cur}"]`));
      place(JUMP);
    };
    const click = (e) => {
      // للكيبورد فقط (Enter/Space) — اللمس تلتقطه pointer events
      if (e.detail !== 0) return;
      const b = e.target.closest('[data-v]');
      if (b) sel(b);
    };

    dock.addEventListener('pointerdown', down);
    dock.addEventListener('pointermove', move);
    dock.addEventListener('pointerup', up);
    dock.addEventListener('pointercancel', cancel);
    dock.addEventListener('click', click);
    const ro = new ResizeObserver(() => place('none'));
    ro.observe(dock);

    return () => {
      dock.removeEventListener('pointerdown', down);
      dock.removeEventListener('pointermove', move);
      dock.removeEventListener('pointerup', up);
      dock.removeEventListener('pointercancel', cancel);
      dock.removeEventListener('click', click);
      clearTimeout(s.t);
      ro.disconnect();
    };
  }, [paint, place, sel]);

  return { dockRef, pillRef };
}