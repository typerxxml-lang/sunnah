import { useCallback, useState } from 'react';
import { loadJSON, saveJSON } from '@/lib/storage';

const KEY = 'iq-widget-order';
export function useWidgetLayout(defaultIds) {
  const [order, setOrder] = useState(() => {
    const saved = loadJSON(KEY, []);
    return [...new Set([...(Array.isArray(saved) ? saved : []), ...defaultIds])].filter(id => defaultIds.includes(id));
  });
  const move = useCallback((id, targetId) => {
    setOrder(previous => {
      const from = previous.indexOf(id), to = previous.indexOf(targetId);
      if (from < 0 || to < 0 || from === to) return previous;
      const next = [...previous];
      next.splice(from, 1);
      next.splice(to, 0, id);
      saveJSON(KEY, next);
      return next;
    });
  }, []);
  return { order, move };
}