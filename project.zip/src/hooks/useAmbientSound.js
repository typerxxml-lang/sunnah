import { useEffect, useRef } from 'react';

function createNoiseBuffer(ctx, type = 'white') {
  const len = ctx.sampleRate * 2;
  const buffer = ctx.createBuffer(1, len, ctx.sampleRate);
  const data = buffer.getChannelData(0);
  if (type === 'brown') {
    let last = 0;
    for (let i = 0; i < len; i++) { last = (last + Math.random() * 2 - 1) * 0.5; data[i] = last; }
  } else {
    for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
  }
  return buffer;
}

export function useAmbientSound(soundType) {
  const ctxRef = useRef(null);
  const nodesRef = useRef([]);

  useEffect(() => {
    nodesRef.current.forEach(n => { try { n.stop?.(); n.disconnect(); } catch {} });
    nodesRef.current = [];
    if (ctxRef.current) { try { ctxRef.current.close(); } catch {} ctxRef.current = null; }

    if (!soundType || soundType === 'none') return;

    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      ctxRef.current = ctx;
      const master = ctx.createGain();
      master.gain.value = 0.1;
      master.connect(ctx.destination);
      const nodes = [master];

      if (soundType === 'rain') {
        const src = ctx.createBufferSource();
        src.buffer = createNoiseBuffer(ctx, 'white'); src.loop = true;
        const filter = ctx.createBiquadFilter();
        filter.type = 'bandpass'; filter.frequency.value = 1200; filter.Q.value = 0.7;
        src.connect(filter).connect(master); src.start();
        nodes.push(src, filter);
      } else if (soundType === 'ac') {
        const src = ctx.createBufferSource();
        src.buffer = createNoiseBuffer(ctx, 'brown'); src.loop = true;
        const filter = ctx.createBiquadFilter();
        filter.type = 'lowpass'; filter.frequency.value = 400;
        src.connect(filter).connect(master); src.start();
        nodes.push(src, filter);
      } else if (soundType === 'night') {
        const osc = ctx.createOscillator();
        osc.type = 'sine'; osc.frequency.value = 4500;
        const gain = ctx.createGain(); gain.gain.value = 0;
        osc.connect(gain).connect(master); osc.start();
        const lfo = ctx.createOscillator(); lfo.frequency.value = 8;
        const lfoGain = ctx.createGain(); lfoGain.gain.value = 0.03;
        lfo.connect(lfoGain).connect(gain.gain); lfo.start();
        nodes.push(osc, gain, lfo, lfoGain);
      } else if (soundType === 'ocean') {
        const src = ctx.createBufferSource();
        src.buffer = createNoiseBuffer(ctx, 'white'); src.loop = true;
        const filter = ctx.createBiquadFilter();
        filter.type = 'lowpass'; filter.frequency.value = 800;
        const lfo = ctx.createOscillator(); lfo.frequency.value = 0.15;
        const lfoGain = ctx.createGain(); lfoGain.gain.value = 0.05;
        const gain = ctx.createGain(); gain.gain.value = 0.05;
        lfo.connect(lfoGain).connect(gain.gain);
        src.connect(filter).connect(gain).connect(master);
        src.start(); lfo.start();
        nodes.push(src, filter, lfo, lfoGain, gain);
      }
      nodesRef.current = nodes;
    } catch {}

    return () => {
      nodesRef.current.forEach(n => { try { n.stop?.(); n.disconnect(); } catch {} });
      nodesRef.current = [];
      if (ctxRef.current) { try { ctxRef.current.close(); } catch {} ctxRef.current = null; }
    };
  }, [soundType]);
}