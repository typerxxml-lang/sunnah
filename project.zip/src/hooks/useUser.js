import { useState, useCallback } from 'react';
import { loadJSON, saveJSON } from '@/lib/storage';
import { base44 } from '@/api/base44Client';

// دخول محلي فقط: الاسم يُحفظ على هذا الجهاز. isReal = دخول باسم (يفتح الإدارة وتفعيل PLUS).
export function useUser() {
  const [user, setUser] = useState(() => loadJSON('iq-user', null));
  const checking = false;

  const login = useCallback((name) => {
    const u = { id: 'local', name, isGuest: false, isReal: true, createdAt: Date.now() };
    setUser(u);
    saveJSON('iq-user', u);
    base44.auth.updateMe({ display_name: name });
  }, []);

  const loginAsGuest = useCallback(() => {
    const u = { name: 'ضيف كريم', isGuest: true, isReal: false, createdAt: Date.now() };
    setUser(u);
    saveJSON('iq-user', u);
  }, []);

  const logout = useCallback(() => {
    setUser(null);
    saveJSON('iq-user', null);
  }, []);

  const updateProfile = useCallback((patch) => {
    setUser(prev => prev ? { ...prev, ...patch } : prev);
    if (user) saveJSON('iq-user', { ...user, ...patch });
  }, [user]);

  return { user, checking, login, loginAsGuest, logout, updateProfile };
}
