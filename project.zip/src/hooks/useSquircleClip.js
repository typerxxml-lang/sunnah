import { useEffect } from 'react';
import { useGlassStyle } from '@/lib/glassStyle';

const SUPPORTED = typeof CSS !== 'undefined' && !!CSS.supports?.('corner-shape', 'squircle');
const K = 0.909; // نقاط تحكم تقارب القطع الناقص الفائق (أس ٤) مثل corner-shape: squircle

function squirclePath(w, h) {
  const r = Math.min(w, h) / 2; // أقصى انحناء
  const k = r * K;
  return `M${r},0H${w - r}C${w - r + k},0 ${w},${r - k} ${w},${r}V${h - r}C${w},${h - r + k} ${w - r + k},${h} ${w - r},${h}H${r}C${r - k},${h} 0,${h - r + k} 0,${h - r}V${r}C0,${r - k} ${r - k},0 ${r},0Z`;
}

/** شكل Squircle حقيقي للمتصفحات التي لا تدعم corner-shape (مثل Safari) */
export function useSquircleClip(ref) {
  const style = useGlassStyle();
  useEffect(() => {
    const el = ref.current;
    if (!el || SUPPORTED) return;
    if (style !== 'liquid') { el.style.clipPath = ''; el.style.webkitClipPath = ''; return; }
    const apply = () => {
      const w = el.offsetWidth;
      const h = el.offsetHeight;
      if (!w || !h) return;
      const clip = `path('${squirclePath(w, h)}')`;
      el.style.clipPath = clip;
      el.style.webkitClipPath = clip;
    };
    apply();
    const ro = new ResizeObserver(apply);
    ro.observe(el);
    return () => ro.disconnect();
  }, [ref, style]);
}