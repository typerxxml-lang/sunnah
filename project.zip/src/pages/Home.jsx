import { useState, useEffect } from 'react';
import { useTheme } from '@/hooks/useTheme';
import { useSettings } from '@/hooks/useSettings';
import { useUser } from '@/hooks/useUser';
import { useFavorites } from '@/hooks/useFavorites';
import { usePlus } from '@/hooks/usePlus';
import { useAmbientSound } from '@/hooks/useAmbientSound';
import { loadJSON, saveJSON } from '@/lib/storage';
import GlassDefs from '@/components/islamic/GlassDefs';
import Background from '@/components/islamic/Background';
import Header from '@/components/islamic/Header';
import BottomNav from '@/components/islamic/BottomNav';
import SearchBar from '@/components/islamic/SearchBar';
import SettingsPanel from '@/components/islamic/SettingsPanel';
import AuthModal from '@/components/islamic/AuthModal';
import AdminPanel from '@/components/islamic/AdminPanel';
import PlusActivation from '@/components/islamic/PlusActivation';
import SpacesView from '@/components/islamic/SpacesView';
import SunnahDetail from '@/components/islamic/SunnahDetail';
import HomeView from '@/components/islamic/HomeView';
import DeveloperNote from '@/components/islamic/DeveloperNote';
import SunanView from '@/components/islamic/SunanView';
import HadithsView from '@/components/islamic/HadithsView';
import QuranView from '@/components/islamic/QuranView';
import AdhkarView from '@/components/islamic/AdhkarView';
import TermsView from '@/components/islamic/TermsView';
import { sunan } from '@/data/sunan';

export default function Home() {
  const { theme, toggle, themeId, setThemeId } = useTheme();
  const { settings, update } = useSettings();
  const { user, checking, login, loginAsGuest, logout, updateProfile } = useUser();
  const { favorites, toggle: toggleFav, isFavorite } = useFavorites();
  const { isPlusActive, adminUnlocked } = usePlus();
  const [activeTab, setActiveTab] = useState('home');
  const [searchOpen, setSearchOpen] = useState(false);
  const [selectedSunnah, setSelectedSunnah] = useState(null);
  const [authOpen, setAuthOpen] = useState(false);
  const [adminOpen, setAdminOpen] = useState(false);
  const [plusOpen, setPlusOpen] = useState(false);
  const [notesOpen, setNotesOpen] = useState(false);
  const [notificationStatus, setNotificationStatus] = useState('default');

  // Language direction
  useEffect(() => {
    document.documentElement.dir = settings.language === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = settings.language;
  }, [settings.language]);

  // Glass style
  useEffect(() => {
    document.documentElement.setAttribute('data-glass-style', settings.glassStyle || 'liquid');
  }, [settings.glassStyle]);

  // Font family
  useEffect(() => {
    document.documentElement.setAttribute('data-font', settings.fontFamily);
    document.documentElement.style.setProperty('--font-scale', String(settings.fontScale));
  }, [settings.fontFamily, settings.fontScale]);

  // Ambient sound (PLUS only)
  useAmbientSound(isPlusActive ? settings.ambientSound : 'none');

  // Restrict themes for non-PLUS
  useEffect(() => {
    if (!isPlusActive && themeId !== 'emerald') setThemeId('emerald');
  }, [isPlusActive, themeId, setThemeId]);

  // Notification permission
  useEffect(() => {
    if ('Notification' in window) setNotificationStatus(Notification.permission);
  }, []);

  // Auth modal
  useEffect(() => {
    if (!checking) setAuthOpen(!user);
  }, [checking, user]);

  // Daily notification
  useEffect(() => {
    if (settings.dailyReminder && 'Notification' in window && Notification.permission === 'granted') {
      const lastShown = loadJSON('iq-last-notification', null);
      const today = new Date().toDateString();
      if (lastShown !== today) {
        const dayOfYear = Math.floor((Date.now() - new Date(new Date().getFullYear(), 0, 0)) / 86400000);
        const dailySunnah = sunan[dayOfYear % sunan.length];
        try { new Notification('سنة اليوم', { body: dailySunnah.title, icon: '/icon.png' }); saveJSON('iq-last-notification', today); } catch {}
      }
    }
  }, [settings.dailyReminder]);

  const requestNotifications = async () => {
    if (!('Notification' in window)) return;
    const result = await Notification.requestPermission();
    setNotificationStatus(result);
  };

  // Banned user
  if (user?.banned) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <div className="glass p-6 text-center max-w-sm">
          <h2 className="font-heading text-xl font-bold text-foreground mb-2">تم حظر حسابك</h2>
          <p className="text-sm text-muted-foreground mb-4">تواصل مع إدارة التطبيق لمعرفة السبب.</p>
          <button onClick={logout} className="rounded-2xl bg-primary text-primary-foreground py-2.5 px-6 text-sm font-bold">تسجيل الخروج</button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-28">
      <GlassDefs />
      <Background />
      <Header theme={theme} onToggleTheme={toggle} onSearch={() => setSearchOpen(true)} user={user} isPlusActive={isPlusActive} />

      <main className="px-4 pt-20 max-w-3xl mx-auto">
        {activeTab === 'home' && (
          <HomeView onSelectSunnah={setSelectedSunnah} isFavorite={isFavorite} onToggleFavorite={toggleFav} favorites={favorites} onNavigate={setActiveTab} settings={settings} />
        )}
        {activeTab === 'sunan' && <SunanView onSelectSunnah={setSelectedSunnah} isFavorite={isFavorite} onToggleFavorite={toggleFav} />}
        {activeTab === 'quran' && <QuranView />}
        {activeTab === 'hadiths' && <HadithsView />}
        {activeTab === 'adhkar' && <AdhkarView />}
        {activeTab === 'terms' && <TermsView />}
        {activeTab === 'settings' && (
          <SettingsPanel
            settings={settings} update={update} theme={theme} onToggleTheme={toggle}
            user={user} onLogout={logout} onNavigate={setActiveTab}
            onRequestNotifications={requestNotifications} notificationStatus={notificationStatus}
            isPlusActive={isPlusActive} adminUnlocked={adminUnlocked}
            themeId={themeId} onThemeIdChange={setThemeId}
            onOpenPlus={() => setPlusOpen(true)} onOpenAdmin={() => setAdminOpen(true)} onOpenNotes={() => setNotesOpen(true)}
            onProfileUpdated={updateProfile}
          />
        )}
      </main>

      {activeTab === 'home' && <DeveloperNote className="fixed left-4 bottom-28 z-30" />}

      <BottomNav activeTab={activeTab} onTabChange={setActiveTab} />

      {searchOpen && <SearchBar onClose={() => setSearchOpen(false)} onSelectSunnah={setSelectedSunnah} />}
      {authOpen && <AuthModal onLogin={name => { login(name); setAuthOpen(false); }} onGuest={() => { loginAsGuest(); setAuthOpen(false); }} />}
      {selectedSunnah && <SunnahDetail sunnah={selectedSunnah} onClose={() => setSelectedSunnah(null)} isFavorite={isFavorite(selectedSunnah.id)} onToggleFavorite={() => toggleFav(selectedSunnah.id)} />}
      {adminOpen && <AdminPanel user={user} onClose={() => setAdminOpen(false)} />}
      {plusOpen && <PlusActivation user={user} onClose={() => setPlusOpen(false)} />}
      {notesOpen && <SpacesView onClose={() => setNotesOpen(false)} />}
    </div>
  );
}